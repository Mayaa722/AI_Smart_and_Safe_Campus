# Comprehensive study guide

# Comprehensive lecture study guide

MLOps\_Lecture01-1stOct2026 (3).pptx

This guide follows the full lecture in ordered chapters. Source ambiguities and additional teaching are labelled.

## Whole-lecture connections and quick reference

Follow the source-checked chapters in lecture order:

- From Software Development to DevOps [p. 1](<run/rendered_slides/337180aaee19/page_0001.png>) [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>) [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>) [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>)
- MLOps: From DevOps and ML to Production AI Systems - SDLC and Process Models [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>) [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>) [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>)
- MLOps: From DevOps and ML to Production AI Systems - Waterfall and Agile [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>) [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>) [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>) [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>)
- MLOps Lecture Section: Agile, DevOps, and Production Systems [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>) [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>) [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>) [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>)
- MLOps: DevOps Foundation / DevOps Lifecycle and Lab Foundations [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>) [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>) [p. 19](<run/rendered_slides/337180aaee19/page_0019.png>) [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>)
- MLOps: Local DevOps Foundations [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>) [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>) [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>) [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>)
- Lecture 01 Synthesis and Bridge to Lecture 02 [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>) [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>) [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>) [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>)
- MLOps Lecture Section: From DevOps to MLOps [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>) [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>) [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>) [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>)
- MLOps: From DevOps and ML to Production AI Systems - Lab Connection, Study Support, Synthesis, and Checkpoint [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>) [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>) [p. 35](<run/rendered_slides/337180aaee19/page_0035.png>) [p. 36](<run/rendered_slides/337180aaee19/page_0036.png>)
- MLOps Lecture 01: Production AI Systems Terminology, Lab Preparation and Bridge [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>) [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>) [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>) [p. 40](<run/rendered_slides/337180aaee19/page_0040.png>)

## From Software Development to DevOps

#### Introduction to the Course Narrative
Delivering software requires disciplined engineering activities that bridge the gap between an initial idea, written code, and a real software product used by people [p. 1](<run/rendered_slides/337180aaee19/page_0001.png>). This lecture establishes the software engineering foundation needed before moving on to machine learning systems, model serving, Retrieval-Augmented Generation (RAG), agents, and LLMOps [p. 1](<run/rendered_slides/337180aaee19/page_0001.png>). The course narrative progresses from the Software Development Life Cycle (SDLC) through Waterfall, Agile, and the DevOps gap, leading to DevOps foundations and its link to MLOps [p. 1](<run/rendered_slides/337180aaee19/page_0001.png>).

#### Working Code vs. Software Product
A common beginner perspective is to assume that writing code that runs locally on a personal machine means the software is finished [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>). This view is incomplete because it ignores users, requirements, testing frameworks, deployment environments, operational responsibilities, and future changes [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>). Transforming source code into a reliable software product requires addressing multiple engineered concerns [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>):
* **User need:** Identifying the real problem the system should solve [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* **Requirements:** Defining the necessary functions and constraints [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* **Architecture and design:** Organizing components, data structures, and interfaces [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* **Testing and verification:** Confirming that the system behaves correctly under expected conditions [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* **Deployment and environment:** Determining where and how users will access the software [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* **Operation and maintenance:** Monitoring, fixing, and evolving the system over time [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).

Source code remains a central artifact, but it is only one component of a complete software system [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).

#### Running Example: UniTasks
To discuss lifecycle concepts concretely without getting lost in domain complexity, the lectures use a simple application called UniTasks [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>). The initial requirement allows students to create, view, complete, and delete personal tasks [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>). This setup immediately raises critical questions [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>):
* Who are the users, and what specific problem do they face [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>)?
* Should the application support user login, deadlines, priorities, reminders, or task sharing [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>)?
* Where is task data stored, and how is it protected [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>)?
* How do developers verify that adding, editing, and deleting tasks functions correctly [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>)?
* How will the application be installed, updated, and supported for its users [p. 3](<run/rendered_slides/337180aaee19/page_0003.png>)?

#### Software Development Life Cycle (SDLC)
The Software Development Life Cycle (SDLC) provides a structured framework for planning, building, testing, delivering, and maintaining software [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>). It outlines the major responsibilities that must be addressed to ensure software is dependable and useful [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>). The six primary phases are [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>):
1. **Requirements / Analysis:** Clarify the problem, target users, functional needs, and constraints [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).
2. **Design:** Define the system architecture, data models, interfaces, and solution structure [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).
3. **Development:** Implement the system code and integrate its components [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).
4. **Testing:** Evaluate whether the software satisfies expectations and requirements [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).
5. **Deployment:** Release the system so intended users can access it [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).
6. **Maintenance:** Fix defects, support users, and evolve the system over time, with maintenance and improvement activities frequently feeding back into new requirements [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).

Most project failures stem from unclear requirements, weak testing, poor deployment preparation, missing operational ownership, or uncontrolled change rather than bad syntax alone [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>). It is important to distinguish what activities must be handled (SDLC activities) from how those activities are organized over time (process models such as Waterfall and Agile) [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).

#### Revision Takeaways
* Source code running locally is not a complete software product [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* Building a product requires addressing user needs, architecture, testing, deployment, and maintenance [p. 2](<run/rendered_slides/337180aaee19/page_0002.png>).
* The SDLC outlines *what* responsibilities must be managed, distinct from *how* process models schedule them [p. 4](<run/rendered_slides/337180aaee19/page_0004.png>).

## MLOps: Software Development Life Cycle (SDLC) and Process Models

### Software Development Life Cycle Study Map

The Software Development Life Cycle (SDLC) defines the essential phases required to build production software systems [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Each phase answers a central question, produces specific artifacts, and addresses practical tasks as illustrated by the UniTasks example project [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).

- Requirements: Answers what the software should do, for whom, and under which constraints [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Produces requirements lists, use cases, and acceptance criteria [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). In UniTasks, this involves adding, completing, and deleting tasks with titles, due dates, and statuses [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).
- Design: Answers how the solution should be organized before implementation begins [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Produces architecture sketches, database schemas, and user interface flows [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). In UniTasks, this involves task tables, screens, component structures, and storage decisions [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).
- Development: Answers how the design will be implemented and integrated [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Produces source code, configurations, and dependencies [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). In UniTasks, this entails building the frontend screen, task logic, persistence layer, and project repository [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).
- Testing: Answers how we know the implemented system behaves correctly [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Produces test cases, defect reports, and test results [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). In UniTasks, this validates that empty tasks cannot be added, complete buttons change states, and delete removes only selected tasks [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).
- Deployment: Answers how users will access the working system in a controlled environment [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Produces release packages, installers, and deployment notes [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). In UniTasks, this means running locally, publishing as a web application, or distributing a packaged version [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).
- Maintenance: Answers how the software will be corrected, supported, and improved after release [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). Produces bug fixes, change requests, and new versions [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>). In UniTasks, this includes adding reminders, fixing login bugs, and updating deadline rules next semester [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).

### SDLC Activities vs. Process Models

It is vital to distinguish between SDLC activities and process models [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>). SDLC activities answer "What must be addressed?" by identifying essential professional responsibilities like understanding needs, designing solutions, implementing, verifying, delivering, and maintaining software [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>). Conversely, process models answer "How is work organized?" by defining sequencing, iteration, documentation, feedback, and release rhythm [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>).

### Process Models Comparison

| Process Model | Sequencing & Rhythm | Main Assumptions | Strengths & Appropriate Uses | Weaknesses & Risks |
| --- | --- | --- | --- | --- |
| Waterfall | Sequential phases where the output of phase n becomes the input to phase n+1 [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>) | Major requirements can be understood before implementation; progress is controlled by documentation and reviews [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>) | Best when requirements are stable, documentation and control are central, and uncertainty is low [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>) | Risky when problems are poorly understood or feedback arrives late; late changes are expensive [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>) |
| Iterative / Agile | Repeated short cycles [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) | Learning, feedback, and changing priorities are expected [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) | Best when learning and adapting to changing priorities are necessary [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) | May reduce upfront architectural clarity if not managed properly [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) |
| DevOps | Continuous delivery and operation [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) | Frequent releases require automation, monitoring, and shared responsibility [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) | Best when continuous and reliable delivery and operation are needed [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) | Requires robust tooling, automation, and organizational culture shift [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>) |

### The Waterfall Model and Artifact-Driven Progression

Waterfall is a sequential process model characterized by the rule that the output of phase n serves as the input to phase n+1 [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>). Teams complete a phase, review its output, and use it to start the next phase [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>). This model relies heavily on early clarity and disciplined documentation [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>). 

When applied to the UniTask project, Waterfall operates as an artifact-driven model where each phase produces a concrete deliverable [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>):
1. Requirements document: Specifies users, task fields, login needs, due dates, and acceptance criteria [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>).
2. Design document: Defines screens, components, database tables, and data flows [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>).
3. Implementation build: Creates the user interface, task logic, storage, and configuration [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>).
4. Test report: Executes functional and edge-case tests while recording defects and fixes [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>).
5. Deployment package: Prepares the runnable application and release instructions [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>).
6. Maintenance log: Tracks bug fixes, enhancement requests, and new versions [p. 8](<run/rendered_slides/337180aaee19/page_0008.png>).

Revision Takeaways:
- SDLC phases define essential software responsibilities and deliverables [p. 5](<run/rendered_slides/337180aaee19/page_0005.png>).
- Activities describe "what" is done, whereas process models describe "how" work is organized [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>).
- Waterfall enforces strict sequential progression and heavy documentation, making it ideal for stable requirements but risky under high uncertainty [p. 7](<run/rendered_slides/337180aaee19/page_0007.png>).

## Software Development Lifecycles: Waterfall and Agile

#### When Waterfall Can Be Useful

The Waterfall model is a planned, sequential development approach. While it has distinct limitations in modern uncertain environments, it is not inherently bad and can be highly effective under specific conditions [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). 

##### Appropriate Conditions and Advantages
Waterfall is useful when:
* The problem domain is well understood and requirements are stable, meaning they are unlikely to change significantly [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>).
* Strong documentation is explicitly required to record requirements and design decisions for reference [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>).
* Formal approval is necessary before progressing to subsequent phases [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>).
* Sequential work supports predictable planning, budgeting, scheduling, and contractual control [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>).
* Clear milestones allow progress to be tracked through phase completion and reviewed artifacts [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>).

From an educational standpoint, Waterfall makes lifecycle responsibilities visible [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). Students can clearly visualize requirements, design, implementation, testing, deployment, and maintenance as distinct concerns rather than mixing everything into coding [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). 

*Important:* A model is only useful when its assumptions fit the project [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). Problems arise when Waterfall is applied to uncertain, rapidly changing work without early feedback [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>).

#### The Main Risk: Late Feedback

The primary danger of a sequential model is that the later a misunderstanding is discovered, the more earlier work must be revised [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>). 

##### Change Propagation Scenario
Consider a scenario where implementation and testing have already started, and users request "shared group tasks" so multiple students can collaborate [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>). In a sequential model, this late requirement change triggers expensive change propagation:
1. **Requirement misunderstood:** Personal tasks must become collaborative tasks [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).
2. **Design no longer matches:** The database schema must be updated to incorporate users, groups, and permissions [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).
3. **Implementation rework:** Task logic, user interface screens, and application programming interface (API) behavior must all be modified [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).
4. **Testing must be repeated:** New test cases are required to cover sharing, access control, and concurrency conflicts [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).
5. **Release is delayed:** Deployment is postponed because earlier phase outputs no longer fit the new demands [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).

This compounding risk motivates iterative and Agile approaches to obtain feedback earlier, learn faster, and minimize the cost of misunderstandings [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).

#### From Late Feedback to Iterative Delivery

Agile approaches respond to uncertainty by delivering smaller increments and learning from frequent feedback [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). 

##### Core Shift in Emphasis
* **Waterfall emphasis:** Plans a large portion of work early, completes phases sequentially, and receives major user feedback relatively late [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>).
* **Agile emphasis:** Works in short cycles, delivers usable increments, involves stakeholders frequently, and adapts plans as the team learns [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>).

The Agile delivery loop consists of repeating short cycles through six phases: Plan -> Design -> Build -> Test -> Review -> Improve [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). 

*Study Statement:* Agile does not eliminate planning, design, or testing [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). Instead, it changes their rhythm by performing these activities repeatedly in smaller cycles, using feedback to guide each subsequent increment [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>).

#### Agile Values in Academic Language

The Agile Manifesto defines core values that guide how teams make trade-offs during software development [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>):
* **Individuals and interactions over processes and tools:** Communication and collaboration are emphasized because software problems are often ambiguous and require shared understanding [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>).
* **Working software over comprehensive documentation:** Documentation remains useful, but software that actually works for users is the strongest evidence of progress [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>).
* **Customer collaboration over contract negotiation:** Stakeholders should actively help the team learn whether the system solves the real problem, rather than merely approving documents [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>).
* **Responding to change over following a plan:** Planning is necessary, but plans must adapt when new evidence shows requirements or priorities have shifted [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>).

*Important Interpretation:* The word "over" does not mean the items on the right are worthless; it means the items on the left receive higher priority when trade-offs occur [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>).

| Model / Approach | Differences | Assumptions | Strengths | Weaknesses | Appropriate Uses |
| --- | --- | --- | --- | --- | --- |
| **Waterfall** | Sequential phases executed one after another with formal milestones [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). | Requirements are stable and well understood upfront [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). | Strong documentation, predictable budgeting, clear milestones [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). | Expensive rework and delayed releases when requirements change late [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>). | Well-understood domains with strict contractual or regulatory constraints [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>). |
| **Agile** | Iterative short cycles delivering usable increments with continuous feedback [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). | Requirements are subject to uncertainty and evolve through learning [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). | Early feedback, rapid adaptation to change, reduced cost of misunderstanding [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). | Less upfront predictability, requires high stakeholder involvement [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>), [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>). | Ambiguous domains, rapidly changing environments, and user-facing applications [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>), [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>). |

#### Revision Takeaways
* Waterfall relies on sequential planning and is effective when requirements are stable, but suffers from expensive change propagation when late feedback occurs [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>), [p. 10](<run/rendered_slides/337180aaee19/page_0010.png>).
* Agile uses short cycles (plan, design, build, test, review, improve) to deliver increments and adapt to uncertainty [p. 11](<run/rendered_slides/337180aaee19/page_0011.png>).
* Agile prioritizes individuals, working software, customer collaboration, and change response over rigid processes, documentation, contracts, and plans [p. 12](<run/rendered_slides/337180aaee19/page_0012.png>).

## Agile Iteration, the Delivery Gap, and DevOps Foundations

#### Agile Applied to UniTasks

Agile methodologies replace rigid, single-release schedules with iterative delivery, where teams release useful increments and adapt based on direct user feedback [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>). This evolutionary process is illustrated through the UniTasks application example across four sequential iterations [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>):

* **Iteration 1 (Basic task list):** Focuses on adding, displaying, and completing simple tasks to test whether the main user workflow is functional [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>).
* **Iteration 2 (Due dates and priority):** Introduces due dates and priority levels to evaluate whether these fields align with actual student planning habits [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>).
* **Iteration 3 (Reminders):** Adds notifications to determine user preference across email, mobile, or in-app reminder channels [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>).
* **Iteration 4 (Sharing):** Introduces group tasks in response to user requests for collaboration on team assignments [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>).

By releasing small increments, Agile fundamentally changes the risk profile of software development: teams discover misunderstandings and misalignments while the product is still small enough to change easily [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>).

#### From Agile to DevOps

While Agile successfully closes the feedback loop between stakeholders and developers, production software requires reliable deployment, operation, and support that development-focused iterations alone cannot solve [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>). 

A persistent delivery and operation gap (represented visually as a "wall" separating development and operations) leads to typical failure symptoms before DevOps practices are introduced [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>):

* Applications run successfully in local development environments but fail when deployed elsewhere [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>).
* Release procedures remain manual, undocumented, or overly dependent on a single individual [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>).
* Operations teams receive software late and are forced to guess critical configuration details [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>).
* Monitoring, system rollback, and technical support are treated as reactive afterthoughts applied only after failures occur [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>).

Agile helps teams build the right increment, whereas DevOps helps teams deliver and operate those increments reliably by bridging the gap between development, delivery, operation, and monitoring [p. 14](<run/rendered_slides/337180aaee19/page_0014.png>).

#### Why DevOps Becomes Necessary

Frequent changes are only valuable if an organization possesses the capability to release, operate, and monitor software reliably [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>). When Agile practices push teams to deliver new increments every one or two weeks, manual deployments and weak operational coordination transform into severe system bottlenecks [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>). This operational pressure gives rise to the foundational DevOps question: *How can we move from code changes to reliable running software repeatedly, safely, and with feedback from operation?* [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>)

Recapping the structural progression of software engineering challenges covered thus far [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>):
1. Code is not enough [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>).
2. The Software Development Life Cycle (SDLC) identifies responsibilities [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>).
3. Waterfall organizes work sequentially [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>).
4. Agile introduces critical feedback cycles [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>).
5. The separation between development and operations (Dev/Ops) remains unaddressed [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>).

#### Defining DevOps Academically

DevOps is not a single tool or cloud product, but rather a socio-technical approach to delivering and operating software reliably [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>). Its definition spans three core pillars [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>):

* **Culture:** Shared responsibility, active collaboration, and open communication between software builders and system operators [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>).
* **Practices:** Repeatable engineering workflows including version control, automated testing, controlled releases, and continuous operational feedback [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>).
* **Tools:** Technology stacks—such as Git, CI workflows, containers, package managers, monitoring tools, and deployment scripts—that support the underlying practices [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>).

A common misconception is equating DevOps solely with tool usage (e.g., "DevOps equals using Docker or Jenkins") [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>). Tools are effective only when they actively foster collaboration, automation, reliability, and feedback [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>).

#### Revision Takeaways

* Agile minimizes requirement risk through iterative increments and early user feedback [p. 13](<run/rendered_slides/337180aaee19/page_0013.png>).
* Frequent Agile release cycles expose manual operational bottlenecks, creating the necessity for DevOps [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>).
* DevOps is a socio-technical integration of culture, practices, and supportive tools rather than a standalone software product [p. 16](<run/rendered_slides/337180aaee19/page_0016.png>).

## DevOps Foundations, Lifecycle, and Lab Practice

### DevOps Foundations and the Development-Operations Tension

DevOps emerged to reconcile a fundamental organizational gap: development and operations historically optimized for conflicting goals [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>). 

* **Development Perspective:** Driven by the main pressure of **change**. Developers aim to deliver new features and bug fixes quickly, respond to user feedback and changing requirements, experiment with improvements, refactor code, and prefer faster release cycles with shorter waiting times [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>). Developers are typically rewarded for adding or improving functionality [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>).
* **Operations Perspective:** Driven by the main pressure of **stability**. Operations teams strive to keep systems available, secure, and stable for users, avoid unexpected failures caused by uncontrolled changes, maintain deployment environments, and prefer predictable releases, rollback plans, and monitoring [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>). Operations teams are judged by uptime, reliability, and incident reduction [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>).

DevOps does not eliminate either goal; instead, it makes change safer and stability more compatible with continuous delivery [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>).

### Core DevOps Principles: CALMS

Beyond individual tools, DevOps is explained by an academic framework known as **CALMS** [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>):

* **Culture (C):** Teams share responsibility for delivery and operation rather than handing work over a wall, fostering shared responsibility [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).
* **Automation (A):** Repetitive and error-prone tasks are scripted or automated to improve repeatability [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).
* **Lean (L):** Work is delivered in smaller batches to reduce waste, waiting time, and risk [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).
* **Measurement (M):** Teams use data about builds, tests, releases, incidents, and performance as evidence to improve [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).
* **Sharing (S):** Knowledge, feedback, logs, documentation, and lessons learned are made visible across teams [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).

Tools like Git and Docker are practical expressions of these principles rather than substitutes for them [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).

### The DevOps Lifecycle

The DevOps lifecycle connects development work with operational feedback in a continuous loop [p. 19](<run/rendered_slides/337180aaee19/page_0019.png>). The process is split into two primary sides:

* **Development Side:** Consists of **Plan** (define goals, issues, backlog, and release scope), **Code** (implement changes in version-controlled files), **Build** (package the application and dependencies), and **Test** (verify behavior with automated or manual checks) to produce a candidate version of the software [p. 19](<run/rendered_slides/337180aaee19/page_0019.png>).
* **Operation Side:** Consists of **Deploy** (make the version available in its environment), **Operate** (run the service and manage incidents or configuration), and **Monitor** (collect feedback about performance, errors, and usage) to turn releases into operational learning [p. 19](<run/rendered_slides/337180aaee19/page_0019.png>).

Crucially, monitoring and operational feedback influence the next planning cycle, making delivery a continuous improvement loop [p. 19](<run/rendered_slides/337180aaee19/page_0019.png>).

### Local-First DevOps Foundations for Lab 01

Practical implementation translates lecture principles into three concrete foundations [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>):

1. **Environment:** Defined development environments reduce hidden differences between machines across language versions, packages, tools, and configuration, ensuring **reproducibility** [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>).
2. **Git:** Version control records project changes over time, supports collaboration, and provides a history of code decisions through commits, ensuring **traceability** [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>).
3. **Docker:** Containerization packages an application with its runtime dependencies so it executes consistently across diverse environments, ensuring **portability** [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>).

The conceptual execution flow flows as: Local project folder -> Git repository -> dependency specification -> Docker image -> repeatable container run [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>).

### Revision Takeaways

* Development prioritizes rapid change and feature delivery, whereas operations prioritizes stability, uptime, and risk mitigation [p. 17](<run/rendered_slides/337180aaee19/page_0017.png>).
* The CALMS framework covers Culture, Automation, Lean, Measurement, and Sharing [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>).
* The DevOps lifecycle is a continuous loop where operational monitoring feeds directly back into planning [p. 19](<run/rendered_slides/337180aaee19/page_0019.png>).
* Environment setup ensures reproducibility, Git ensures traceability, and Docker ensures portability [p. 20](<run/rendered_slides/337180aaee19/page_0020.png>).

## MLOps: Local DevOps Foundations

#### From DevOps Principles to Concrete Artifacts

Abstract DevOps principles become teachable and actionable when they are tied directly to concrete project files, evidence, and assets [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>). A practical DevOps workflow ensures that software can be understood, rebuilt, tested, and operated by anyone on the team [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>). 

* **Need and plan:** Answered by issues, user stories, or backlog items defining what change is made and why [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).
* **Source control:** Answered by Git repositories and commits, tracking which files changed, when, by whom, and for what reason [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).
* **Environment definition:** Answered by README files, requirement files, and Dockerfiles specifying what must exist to run the project correctly [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).
* **Verification:** Answered by tests, logs, and build results showing whether the current version works [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).
* **Delivery package:** Answered by container images or executable packages representing the deliverable version [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).
* **Operation feedback:** Answered by runtime logs, errors, and user reports tracking behavior after deployment [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).

#### Reproducible Development Environments

A software project is reproducible when its required runtime, dependencies, configuration, and execution steps are explicitly stated [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>). Hidden environment discrepancies—such as Developer A running Python 3.11 with Package X at version 2.0 while Developer B runs Python 3.9 with Package X at version 1.4 and missing config variables—lead to divergent behavior or outright failure despite sharing identical source code [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).

To ensure reproducibility, projects must specify:
* **Runtime:** Language or interpreter version (e.g., Python, Node.js, Java) [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).
* **Dependencies:** External packages and compatible versions [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).
* **Configuration:** Environment variables, ports, and local settings [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).
* **Execution steps:** Instructions on how to install, run, test, and stop the application [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).
* **Data assumptions:** Sample data locations and expected schemas or formats [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).

Reproducibility serves as a foundational prerequisite for collaboration, testing, and downstream MLOps pipelines [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).

#### Version Control with Git: The Project Memory

Version control acts as the project memory, recording file changes over time so that specific historical versions can be recalled [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>). Academic definitions emphasize that version control supports history, accountability, experimentation, and collaboration [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>).

Commit history is structured as a sequence of meaningful snapshots (e.g., C1 initial task list, C2 add delete task, C3 fix date bug, C4 add priority) paired with explanatory notes [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>). Team members synchronize these commits with a shared remote repository [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>). Version control provides:
* **Traceability:** Tracking what changed and why [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>).
* **Recovery:** Restoring known working versions [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>).
* **Collaboration:** Enabling multiple people to work together safely [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>).
* **Experimentation:** Allowing new ideas to be tested without risking stable versions [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>).

#### Containerization with Docker: Packaging the Execution Context

Passing around code alone risks failure due to unknown machine states, differing library versions, and system settings [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>). Docker solves this by packaging application source code together with its runtime, dependencies, and settings into a consistent container solution [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>).

The container lifecycle follows three main steps:
1. **Dockerfile:** Describes how to build the package [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>).
2. **Image:** The static packaged artifact built from the Dockerfile [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>).
3. **Running container:** An active execution instance of the image [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>).

In this context, Docker is utilized locally to guarantee repeatable execution rather than targeting cloud deployments directly [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>).

#### Revision Takeaways
* DevOps workflow relies on tangible artifacts to track needs, source code, environments, verifications, packages, and operations [p. 21](<run/rendered_slides/337180aaee19/page_0021.png>).
* Explicit runtimes, dependencies, and configurations prevent hidden environment bugs between developers [p. 22](<run/rendered_slides/337180aaee19/page_0022.png>).
* Git maintains a traceable history of snapshots enabling recovery, collaboration, and safe experimentation [p. 23](<run/rendered_slides/337180aaee19/page_0023.png>).
* Docker encapsulates code, runtimes, and system dependencies into images and running containers for local reproducibility [p. 24](<run/rendered_slides/337180aaee19/page_0024.png>).

## MLOps Foundations: From DevOps to Production AI Systems

### Lecture 01 Synthesis and Bridge to Lecture 02

Software delivery requires structured processes, collaboration, operational feedback, and local reproducibility [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). Working code alone is distinct from a complete software product [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). The software development lifecycle (SDLC) organizes engineering responsibilities, while Waterfall planning and Agile iterative delivery help teams learn earlier from users and change [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). However, Agile alone does not automatically resolve deployment and operational hurdles [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). DevOps bridges development and operations through culture, automation, measurement, and feedback [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). Before advanced MLOps, local reproducibility via Git and Docker forms an essential foundation [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). 

The conceptual chain proceeds from raw code to SDLC responsibilities, Waterfall planning, Agile feedback, the DevOps delivery loop, and local reproducibility [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>). The bridge to MLOps is defined as follows: DevOps asks how to deliver software reliably, whereas MLOps asks how to deliver systems whose behavior also depends on data and models [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>).

### Why This DevOps Foundation Matters for AI Systems

Production AI systems are software systems, but their runtime behavior depends on models, prompts, data, and configuration [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>). A modern AI application is not just a model; it wraps the model with user interfaces, dependencies, data access, evaluation, security, and monitoring [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>). 

The architecture flows sequentially through five components [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>):
- **Source code**: Application logic, API handlers, and UI [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).
- **Model / LLM**: Pretrained models or external inference engines [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).
- **Data / knowledge**: Files, databases, vector stores, and context [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).
- **Environment**: Runtime, libraries, versions, and hardware [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).
- **Users and feedback**: Real requests, errors, and quality signals [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).

While DevOps addresses reliable software delivery, the MLOps/LLMOps extension must handle data, models, prompts, and evaluation [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).

### Local Development Environment: What Must Be Standardized?

Before automation or deployment, developers require a controlled local working environment to ensure commands and results are repeatable [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). A development environment encompasses the tools, versions, folders, variables, and services required to build and run a project [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). Standardization covers five key components [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>):

- **Toolchain**: Python, Node, or Java runtime, package manager, and compiler [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). Different versions can cause divergent behavior [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).
- **Project structure**: Folders, source files, tests, and configuration files [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). Consistent layouts enable team collaboration and automation [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).
- **Dependencies**: Third-party libraries and system packages [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). Projects must explicitly document exact execution requirements [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).
- **Configuration**: Environment variables, ports, paths, and keys [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). Configuration must not remain hidden inside an individual developer laptop [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).
- **Execution command**: Procedures to install, test, run, and stop the system [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>). Teammates must be able to replicate identical steps [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).

The objective of Lab 01 is for every student to clone a project, install dependencies, execute commands, track changes using Git, and containerize the basic application [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).

### Virtual Machines and Containers: Different Abstractions

Virtual machines and containers both provide isolation, but they operate at distinct architectural layers and solve different operational problems [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>). 

- **Virtual machine view**: Stacks hardware at the base, followed by the host operating system, hypervisor, guest operating system, libraries/runtime, and application [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>). A VM virtualizes a full machine, including a complete guest operating system, providing machine-level isolation [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>).
- **Container view**: Stacks hardware, host operating system, container engine, libraries/runtime, and application [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>). A container packages the application and its dependencies while sharing the host operating system kernel, providing lightweight process-level isolation for repeatable execution [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>).

| Abstraction Level | Isolation Type | Core Components | Primary Strengths | Appropriate Use Cases |
|---|---|---|---|---|
| Virtual Machine | Machine-level [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>) | Hardware, host OS, hypervisor, guest OS, runtimes, app [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>) | Strong isolation of entire OS environments [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>) | Running multi-tenant workloads with different OS requirements |
| Container | Process-level [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>) | Hardware, host OS, container engine, runtimes, app [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>) | Lightweight packaging, shares host OS kernel [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>) | Repeatable application execution and microservices |

### Revision Takeaways
- Code alone is insufficient for production; complete systems require SDLC rigor and DevOps automation [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>).
- AI applications wrap models in complex software wrappers encompassing data, code, environments, and feedback loops [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).
- Local environments must standardize toolchains, project structures, dependencies, configuration, and execution commands [p. 27](<run/rendered_slides/337180aaee19/page_0027.png>).
- Containers offer process-level isolation by sharing the host kernel, whereas VMs provide full guest-OS machine-level isolation [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>).

## MLOps: From DevOps and ML to Production AI Systems

### A Local DevOps Workflow for UniTasks

The initial practical target for reliable engineering is not immediate cloud deployment, but establishing a repeatable local workflow that can later be scaled and automated [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>). A simple local loop encapsulates key DevOps concepts: traceability, automation, repeatability, verification, and feedback [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).

#### The Eight-Step Workflow

The local DevOps workflow proceeds through eight discrete steps [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>):
1. **Plan**: Define a small change or bug fix [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
2. **Code**: Edit the source files [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
3. **Commit**: Record the version history in Git [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
4. **Build**: Prepare an executable or package [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
5. **Test**: Check expected behavior against requirements [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
6. **Containerize**: Package the environment to guarantee consistency [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
7. **Run**: Execute the packaged application repeatably [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
8. **Observe**: Collect operational feedback, which then returns directly to the planning phase [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).

This loop is deliberately local, yet its foundational principles scale upward into continuous integration and continuous deployment (CI/CD), model serving, retrieval-augmented generation (RAG) applications, and LLMOps pipelines [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).

### From DevOps to MLOps

Traditional software delivery primarily centers around source code as the changing artifact [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>). Typical DevOps concerns involve versioning code, building and testing automatically, packaging applications, deploying and operating reliably, and monitoring user feedback [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).

In contrast, machine-learning system delivery incorporates changing artifacts across code, data, configuration, and model parameters [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>). Consequently, MLOps introduces additional concerns [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>):
- Tracking experiments and dataset versions [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).
- Validating data quality and model quality [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).
- Deploying model versions safely [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).
- Monitoring drift and performance over time [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).
- Retraining models when underlying systems or environments change [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).

While DevOps teaches engineering teams how to make software delivery repeatable, MLOps extends this mindset to ensure that model-based system delivery remains repeatable, observable, and continuously improvable [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>).

### From Software Artifacts to ML Artifacts

To establish a reliable delivery process, teams must control and version their system artifacts [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>). MLOps does not discard DevOps practices; rather, it builds upon them by adding governance for data, experiments, and model outputs [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).

#### Artifact Comparison

- **DevOps-Oriented Artifacts** [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>):
  - *Source code*: Application logic, tests, and scripts [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).
  - *Dependencies*: Required libraries and runtime versions [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).
  - *Configuration*: Settings and environment variables [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).
  - *Container image*: Packaged executable environments [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).

- **Additional MLOps-Oriented Artifacts** [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>):
  - *Dataset version*: Training, validation, and test data splits [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).
  - *Feature definition*: Specifications for how raw data transforms into model inputs [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).
  - *Experiment record*: Tracked parameters, evaluation metrics, and outputs [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).
  - *Model artifact*: Trained model binaries and associated metadata [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).

### Study Checkpoint and Core Concepts

A comprehensive review of production AI engineering requires mastering several conceptual checkpoints [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>):
1. **Code vs Product**: Understanding why working source code alone is insufficient without packaging, deployment, and operational wrappers [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).
2. **Software Development Life Cycle (SDLC)**: Recognizing lifecycle responsibilities and phase purposes [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).
3. **Waterfall Dynamics**: Analyzing why late feedback introduces high costs in sequential execution [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).
4. **Agile Methodologies**: Examining how iteration, incremental delivery, and continuous feedback reshape delivery models [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).
5. **DevOps Scope**: Acknowledging that Agile principles do not automatically resolve infrastructure deployment and operations challenges [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).
6. **Reproducible Workflows**: Explaining how tools like Git and Docker enforce consistency and repeatability [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).

Sources supporting these frameworks include OpenStax process models, the Agile Manifesto, and industry lifecycle discussions from IBM and Atlassian [p. 30](<run/rendered_slides/337180aaee19/page_0030.png>).

### Revision Takeaways
- A local DevOps loop bridges small-scale coding tasks and large-scale cloud automation through disciplined planning, building, testing, containerizing, running, and observing [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).
- MLOps expands traditional software governance by requiring strict tracking of data versions, feature definitions, experiments, and model artifacts alongside standard source code and container images [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>) [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).

## MLOps Study Chapter: Lab Connection, Study Support, Synthesis, and Checkpoint

### Lab Connection

Operationalizing software engineering concepts requires matching practical tools to engineering problems [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>). Environment setup addresses machine-specific setting dependencies by ensuring controlled runtime assumptions [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>). Git and GitHub provide inspectable, reversible, and shareable project histories for change traceability and recovery [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>). Docker packages code with its dependencies to reduce environment mismatch so applications run reliably elsewhere [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>). Finally, README files and explicit commands document team processes for repeatable execution [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>). The goal of lab exercises is disciplined, reproducible software engineering rather than rote tool memorization [p. 33](<run/rendered_slides/337180aaee19/page_0033.png>).

### Recommended Study Materials

Students should focus on concepts and terminology using targeted readings [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>). The OpenStax SDLC section covers analysis, design, development, testing, deployment, and maintenance lifecycle responsibilities [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>). Process model resources compare sequential and iterative organizational strategies [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>). The Agile Manifesto highlights change responsiveness and working software increments [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>). The IBM DevOps lifecycle resource explains planning, coding, building, testing, releasing, deploying, operating, and monitoring as a continuous loop [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>). Pro Git introduces version control principles for history and recovery [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>), and Docker documentation covers container packaging for portability [p. 34](<run/rendered_slides/337180aaee19/page_0034.png>).

### Lecture Synthesis

The conceptual progression moves through six core phases: code alone is insufficient, software possesses a lifecycle, waterfall organizes work sequentially, agile introduces iteration and feedback, DevOps closes the development-operations gap, and tools like Git and Docker support repeatability [p. 35](<run/rendered_slides/337180aaee19/page_0035.png>). DevOps functions as an engineering solution to delivery problems, ensuring code transitions smoothly into tested, packaged, operated, and monitored systems [p. 35](<run/rendered_slides/337180aaee19/page_0035.png>).

### Concept Check

Active understanding is verified through concept questions [p. 36](<run/rendered_slides/337180aaee19/page_0036.png>). Source code alone is insufficient because products also require requirements, designs, tests, and deployment procedures [p. 36](<run/rendered_slides/337180aaee19/page_0036.png>). The Software Development Life Cycle (SDLC) organizes engineering activities to transform user needs into maintained systems [p. 36](<run/rendered_slides/337180aaee19/page_0036.png>). Agile addresses the rigidity of sequential models via short iterations and working increments [p. 36](<run/rendered_slides/337180aaee19/page_0036.png>), while DevOps resolves remaining delivery friction between development and operations [p. 36](<run/rendered_slides/337180aaee19/page_0036.png>).

## MLOps Lecture 01: Production AI Systems Terminology, Lab Preparation and Bridge

### Introduction to Production AI Systems Terminology

A professional software system extends far beyond raw source code [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>) [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>). A comprehensive **software product** includes requirements, design decisions, tests, configuration, runtime environment, deployment procedures, and maintenance responsibilities [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>). To structure these responsibilities across a system's life, the **SDLC (Software Development Life Cycle)** organizes activities like requirements analysis, design, development, testing, deployment, and maintenance [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>). 

Lifecycle methodologies offer different approaches for managing project progression:
- **Waterfall model**: A plan-driven model arranging major lifecycle activities sequentially [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>). It is easier to manage stable projects but harder to respond to late requirement changes [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>).
- **Agile development**: An iterative approach emphasizing working software, customer collaboration, adaptation to change, and frequent feedback [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>).

### Engineering Practices and Reliability

To deliver software reliably, **DevOps** connects development and operations through a culture and set of practices built on collaboration, automation, measurement, and feedback [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>) [p. 40](<run/rendered_slides/337180aaee19/page_0040.png>). Central to reliable delivery is **reproducibility**: the ability for another person or machine to recreate the exact same result using controlled code versions, documented steps, and a known execution environment [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>). 

An essential study rule is to connect definitions to concrete problems, such as solving the "it works on my machine" dilemma [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>). Core tooling supports this discipline: **Git** serves as a history and collaboration mechanism for traceable changes, while **Docker** acts as an environment packaging mechanism for portable execution assumptions [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>) [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>) [p. 40](<run/rendered_slides/337180aaee19/page_0040.png>).

### Lab 01 Preparation and Practical Requirements

Lab 01 translates lecture concepts into practical execution [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>). Preparation is structured into three explicit pillars:
1. **Understand the purpose**: Conceptual readiness involving why local success is insufficient, distinguishing source code from products, and understanding Git and Docker roles [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>).
2. **Prepare the machine**: Technical setup requiring an administrator-permitted laptop, terminal access, internet connection, installed code editor, Git, Docker Desktop, and a GitHub account [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>).
3. **Produce evidence**: Submission deliverables consisting of an installation screenshot, a Git repository with commits, a descriptive README, a Dockerfile or run command, and a brief reflection on the problems solved by Git and Docker [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>).

### Bridge to Subsequent Topics and Course Scope

Professional software is not finished when code runs locally; it must be specified, designed, implemented, tested, packaged, delivered, operated, monitored, and improved [p. 40](<run/rendered_slides/337180aaee19/page_0040.png>). 

Lecture 02 will advance these concepts into technical foundations:
- **Environment management**: Addressing runtime dependencies like operating systems, interpreter versions, libraries, paths, and configurations [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>).
- **Git workflow**: Leveraging commits, branches, and remote repositories for collaboration and recovery [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>).
- **Docker fundamentals**: Packaging execution assumptions into portable images and containers [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>).
- **Automation mindset**: Turning repeatable commands into building blocks for testing and CI/CD workflows [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>).

Ultimately, **MLOps** extends this standard software delivery discipline to production AI systems whose behaviors depend additionally on data, models, and model-serving workflows [p. 39](<run/rendered_slides/337180aaee19/page_0039.png>) [p. 40](<run/rendered_slides/337180aaee19/page_0040.png>).

### Revision Takeaways
- A software product encompasses documentation, tests, and configuration alongside source code [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>).
- DevOps bridges development and operations to enhance reliability through automation and feedback [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>).
- Reproducibility eliminates the "it works on my machine" failure mode [p. 37](<run/rendered_slides/337180aaee19/page_0037.png>) [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>).
- Git provides project history while Docker packages environment assumptions [p. 38](<run/rendered_slides/337180aaee19/page_0038.png>).
- MLOps scales DevOps principles to machine learning and AI workflows [p. 40](<run/rendered_slides/337180aaee19/page_0040.png>).
