# Full-lecture study materials

MLOps_Lecture01-1stOct2026 (3).pptx

Processing coverage: 40/40 pages. This is not an accuracy score.

Page notes and transcriptions are Gemini-generated drafts; original page images remain authoritative.

## Section 1: From Software Development to DevOps

### Working Code vs Software Product

Working code running locally is insufficient to form a software product. Delivering a complete product requires addressing user needs, requirements, architecture, testing, deployment environments, and ongoing operations.
Sources: 337180aaee19:p1, 337180aaee19:p2

### Software Development Life Cycle (SDLC)

SDLC is a structured framework of major responsibilities needed to transform a need into a maintained software system, encompassing requirements, design, development, testing, deployment, and maintenance.
Sources: 337180aaee19:p4

### SDLC Activities vs Process Models

SDLC activities define what responsibilities must be handled in software development, whereas process models like Waterfall and Agile describe how these activities are organized and scheduled over time.
Sources: 337180aaee19:p4

#### 337180aaee19:p1 (content)

Introduction to the course narrative moving from SDLC through Agile and DevOps to MLOps, highlighting that delivering software requires structured engineering beyond writing code.

Core question of the lecture: IDEA -> CODE -> USER. Between code and a real software product there are disciplined engineering activities.

#### 337180aaee19:p2 (content)

Explains that working code is not a full software product by contrasting beginner views with engineered concerns like user needs, deployment, and maintenance.

A software product includes multiple engineered concerns: User need, Requirements, Architecture & design, Testing & verification, Deployment & environment, Operation & maintenance.

#### 337180aaee19:p3 (content)

Introduces the UniTasks running example to illustrate lifecycle concepts concretely, emphasizing process focus over domain complexity.

UniTasks (My Tasks, Submit OOP assignment, Prepare MLOps proposal, Review Lecture 01, Check lab environment, + Add Task). Initial requirement: Students can create, view, complete and delete personal tasks.

#### 337180aaee19:p4 (content)

Defines the Software Development Life Cycle (SDLC) framework, detailing its six key phases and distinguishing what activities are handled from how processes are organized.

1. Requirements / Analysis -> 2. Design -> 3. Development -> 4. Testing -> 5. Deployment -> 6. Maintenance. life cycle: improvement and maintenance can create new requirements.

## Section 5: MLOps: From DevOps and ML to Production AI Systems - SDLC and Process Models

### Software Development Life Cycle (SDLC) Phases

SDLC breaks software creation into essential phases—Requirements, Design, Development, Testing, Deployment, and Maintenance—each answering a core question and producing specific artifacts such as use cases, source code, and test reports.
Sources: 337180aaee19:p5

### SDLC Activities vs. Process Models

SDLC activities define 'what must be addressed' regarding essential software responsibilities, whereas process models determine 'how work is organized' through specific sequencing, feedback loops, and delivery rhythms like Waterfall or Agile.
Sources: 337180aaee19:p6

### The Waterfall Model

Waterfall is a sequential process model where the output of phase n serves directly as the input to phase n+1. It depends on early requirement clarity and disciplined documentation, making late changes expensive.
Sources: 337180aaee19:p7

### Artifact-Driven Progression

In sequential models like Waterfall, progress is strictly controlled through documentation and reviews, ensuring each phase produces a validated artifact before the subsequent phase relies upon it.
Sources: 337180aaee19:p8

#### 337180aaee19:p5 (content)

Presents a study map table outlining the phases, central questions, typical artifacts, and UniTasks examples for the Software Development Life Cycle (SDLC).

Phase | Central question | Typical artifact | UniTasks example. Requirements, Design, Development, Testing, Deployment, Maintenance.

#### 337180aaee19:p6 (content)

Compares SDLC activities which answer 'What must be addressed?' against process models which answer 'How is work organized?', showing Waterfall, Agile, and DevOps.

SDLC activities answer: What must be addressed? Process models answer: How is work organized? Three ways: Waterfall (Sequential phases), Iterative / Agile (Repeated short cycles), DevOps (Continuous delivery and operation).

#### 337180aaee19:p7 (content)

Details the Waterfall model, highlighting its sequential logic where phase n output feeds phase n+1, along with its main assumptions and academic interpretation.

The Waterfall Model. Requirements -> Design -> Implementation -> Verification / Testing -> Deployment -> Maintenance. Output of phase n -> input of phase n+1.

#### 337180aaee19:p8 (content)

Illustrates the Waterfall model applied to a UniTask project, showing specific artifacts produced across the six sequential phases.

Waterfall Applied to UniTasks. 1 Requirements document, 2 Design document, 3 Implementation build, 4 Test report, 5 Deployment package, 6 Maintenance log.

## Section 9: MLOps: From DevOps and ML to Production AI Systems - Waterfall and Agile

### Waterfall Model Utility

Waterfall is a planned, sequential development model that is useful when the domain is well understood, requirements are stable, formal approval is needed, and strong documentation or predictable planning is required.
Sources: 337180aaee19:p9

### Late Feedback Risk

In sequential models, discovering misunderstandings or requirement changes late leads to costly change propagation, requiring rework across requirements, design, implementation, testing, and delayed releases.
Sources: 337180aaee19:p10

### Iterative Delivery

Agile approaches respond to uncertainty through short delivery cycles (plan, design, build, test, review, improve), utilizing frequent stakeholder feedback to guide subsequent increments without eliminating core engineering activities.
Sources: 337180aaee19:p11

### Agile Manifesto Values

The Agile framework prioritizes individuals and interactions, working software, customer collaboration, and responding to change over processes and tools, documentation, contract negotiation, and strict plan-following.
Sources: 337180aaee19:p12

#### 337180aaee19:p9 (content)

Explores conditions where the Waterfall model is useful, highlighting clear milestones, strong documentation, predictable planning, and stable requirements.

ANALYSIS WATERFALL 09 When Waterfall Can Be Useful Appropriate conditions, Educational value, Typical advantages, Clear milestones, Strong documentation, Predictable planning, Useful for stable systems. Important: A model is useful when its assumptions fit the project.

#### 337180aaee19:p10 (content)

Examines the main risk of Waterfall: late feedback and how change propagation causes expensive rework across requirements, design, implementation, testing, and release.

RISK WATERFALL 10 The Main Risk: Late Feedback. Scenario: a late requirement change. Change propagation flow chart: Requirement misunderstood -> Design no longer matches -> Implementation rework -> Testing must be repeated -> Release is delayed.

#### 337180aaee19:p11 (content)

Introduces Agile iterative delivery, contrasting Waterfall sequential planning with short cycles of plan, design, build, test, review, and improve.

AGILE 11 From Late Feedback to Iterative Delivery. Core shift: Waterfall emphasis vs Agile emphasis. Cycle diagram: Plan -> Design -> Build -> Test -> Review -> Improve (repeat in short cycles). Study statement: Agile does not eliminate planning, design or testing.

#### 337180aaee19:p12 (content)

Details the Agile Manifesto values and explains that items on the left receive higher priority over items on the right during trade-offs.

AGILE 12 Agile Values in Academic Language. Individuals and interactions over processes and tools. Working software over comprehensive documentation. Customer collaboration over contract negotiation. Responding to change over following a plan.

## Section 13: MLOps Lecture Section: Agile, DevOps, and Production Systems

### Agile Iterative Delivery

Releasing software in small increments (such as basic task lists, priorities, reminders, and sharing) allows teams to gather user feedback early and adapt future increments, reducing the risk of building the wrong product.
Sources: 337180aaee19:p13

### Development vs. Delivery Gap

While Agile successfully bridges the feedback gap between stakeholders and developers, a delivery and operational gap often remains between development and IT operations, characterized by manual releases and environmental inconsistencies.
Sources: 337180aaee19:p14

### Delivery Pressure in Agile

Frequent software increments delivered every week or two create intense delivery pressure, transforming manual deployment processes and weak operational coordination into critical system bottlenecks.
Sources: 337180aaee19:p15

### Socio-Technical Definition of DevOps

DevOps is defined as a culture and set of engineering practices combining software development and IT operations to build, test, release, operate, and improve software continuously and reliably.
Sources: 337180aaee19:p16

### Role of Tools in DevOps

Tools like Git, containers, and CI workflows are vital, but they only matter when they actively support broader cultural goals of collaboration, automation, reliability, and feedback rather than serving as mere product labels.
Sources: 337180aaee19:p16

#### 337180aaee19:p13 (content)

Demonstrates Agile iterative delivery applied to a 'UniTasks' app across four increments (task list, dates/priority, reminders, sharing), showing how early user feedback minimizes risk and changes requirements while products are small.

Iteration 1: Basic task list -> Iteration 2: Due dates and priority -> Iteration 3: Reminders -> Iteration 4: Sharing

#### 337180aaee19:p14 (content)

Compares Agile's success in closing the development feedback loop with the persistent delivery and operation gap ('wall') between development and operations teams before DevOps.

Bridge: Customer -> Development (Agile loop). But the delivery/operation gap remains: Development -> wall -> Operations

#### 337180aaee19:p15 (content)

Explains how frequent Agile releases create delivery pressure and manual bottlenecks, introducing the foundational question of how to achieve repeatable, safe software delivery with operational feedback.

Lecture 01 so far: 1. Code is not enough, 2. SDLC identifies responsibilities, 3. Waterfall organizes work sequentially, 4. Agile introduces feedback cycles, 5. Dev/Ops separation remains

#### 337180aaee19:p16 (content)

Defines DevOps academically as a socio-technical culture and set of engineering practices integrating development and IT operations, emphasizing that tools alone do not constitute DevOps.

Working definition: DevOps is a culture and set of engineering practices... Culture | Practices | Tools. Incorrect simplification: 'DevOps = using Docker or Jenkins.'

## Section 17: MLOps: DevOps Foundation

### Development-Operations Tension

Development and operations historically optimized for different goals: developers prioritize rapid feature delivery and change, while operations teams prioritize system availability, security, and stability.
Sources: 337180aaee19:p17

### CALMS Framework

An academic framework standing for Culture, Automation, Lean, Measurement, and Sharing that explains DevOps principles beyond just tool usage.
Sources: 337180aaee19:p18

### DevOps Culture and Sharing

Teams share responsibility for delivery and operation rather than working in silos, ensuring knowledge, feedback, and logs remain visible across teams.
Sources: 337180aaee19:p18

### Lean and Automation in DevOps

Repetitive tasks are automated to improve repeatability, and work is delivered in smaller batches to reduce waste, waiting time, and risk.
Sources: 337180aaee19:p18

#### 337180aaee19:p17 (content)

Explains the development-operations tension, contrasting development's pressure for rapid change with operations' pressure for system stability, and showing how DevOps reconciles both goals.

GAP, Development perspective, Main pressure: change, Operations perspective, Main pressure: stability, DevOps does not eliminate either goal. It makes change safer and stability more compatible with continuous delivery.

#### 337180aaee19:p18 (content)

Introduces the CALMS framework (Culture, Automation, Lean, Measurement, Sharing) as core DevOps principles that explain the utility of engineering tools like Git and Docker.

PRINCIPLES, C Culture shared responsibility, A Automation repeatability, L Lean small batches, M Measurement evidence, S Sharing visibility, For this course: DevOps principles explain why Git, Docker and automation are useful.

## Section 19: DevOps Lifecycle and Lab Foundations

### DevOps Lifecycle

The DevOps lifecycle connects development work with operational feedback in a continuous loop. Plan, Code, Build, and Test produce a candidate version on the development side, while Deploy, Operate, and Monitor turn releases into operational learning.
Sources: 337180aaee19:p19

### Development vs Operation Sides

The development side encompasses planning, coding, building, and testing to yield a software candidate. The operation side deploys releases, operates services, and monitors performance to influence future planning cycles.
Sources: 337180aaee19:p19

### Environment Reproducibility

A defined development environment minimizes hidden disparities across machines regarding language versions, packages, tools, and configurations, ensuring reproducibility [337180aaee19:p20].
Sources: 337180aaee19:p20

### Git Traceability

Version control records project modifications over time, facilitates collaboration, and maintains a complete history of code decisions through explicit commits for traceability [337180aaee19:p20].
Sources: 337180aaee19:p20

### Docker Portability

Containerization packages an application alongside its runtime dependencies so that it executes consistently across diverse environments, ensuring portability [337180aaee19:p20].
Sources: 337180aaee19:p20

#### 337180aaee19:p19 (content)

This slide details the DevOps lifecycle loop, separating development (Plan, Code, Build, Test) from operations (Deploy, Operate, Monitor) to create a continuous improvement cycle.

Plan -> Code -> Build -> Test -> Release -> Deploy -> Operate -> Monitor

#### 337180aaee19:p20 (content)

This slide presents the practical foundations for Lab 01: Environment for reproducibility, Git for traceability, and Docker for portability, mapping out a local-first conceptual flow.

Local project folder -> Git repository -> dependency specification -> Docker image -> repeatable container run

## Section 21: MLOps: Local DevOps Foundations

### DevOps Artifacts

A practical DevOps workflow produces tangible artifacts linked to project concerns, allowing team members to understand, rebuild, test, and operate software systems [337180aaee19:p21].
Sources: 337180aaee19:p21

### Reproducible Development Environments

Reproducibility requires explicit specification of runtime versions, external dependencies, configuration settings, execution steps, and data assumptions to prevent divergent behavior across different developer environments [337180aaee19:p22].
Sources: 337180aaee19:p22

### Version Control with Git

Version control records changes as a sequence of meaningful commits, serving as project memory that supports history, traceability, disaster recovery, safe collaboration, and experimentation [337180aaee19:p23].
Sources: 337180aaee19:p23

### Containerization with Docker

Docker packages application code together with its runtime, system dependencies, and settings into a consistent container solution, progressing from a Dockerfile to an image and finally a running container [337180aaee19:p24].
Sources: 337180aaee19:p24

#### 337180aaee19:p21 (content)

Links abstract DevOps principles to concrete project artifacts across six concerns: need and plan, source control, environment definition, verification, delivery package, and operation feedback.

Table mapping DevOps concerns to typical artifacts and study questions: Need and plan -> issue / user story / backlog item; Source control -> Git repository and commits; Environment definition -> README, requirements file, Dockerfile; Verification -> tests, logs and build results; Delivery package -> container image or executable package; Operation feedback -> runtime logs, errors and user reports.

#### 337180aaee19:p22 (content)

Defines reproducible development environments by explaining how hidden environment discrepancies cause different behaviors, and details what must be specified (runtime, dependencies, configuration, execution steps, data assumptions).

Comparison boxes: Developer A (Python 3.11, Package X = 2.0, Local config file exists) vs Developer B (Python 3.9, Package X = 1.4, Missing config variable). Caption: Same source code, different execution context -> different behavior or failure.

#### 337180aaee19:p23 (content)

Introduces Git version control as project memory, illustrating commit history with sequential snapshots (C1 to C4) synchronized with a remote repository to support traceability, recovery, collaboration, and experimentation.

Commit history workflow graph showing nodes C1 (initial task list), C2 (add delete task), C3 (fix date bug), and C4 (add priority) with a sync arrow pointing to a Remote repository.

#### 337180aaee19:p24 (content)

Explains containerization with Docker for packaging code, runtime, dependencies, and settings into consistent execution contexts following the progression from Dockerfile to image to running container.

Flowchart: Code only -> Unknown machine state (versions, libraries, settings). Container solution packages Application code, Runtime, Dependencies, and Settings. Lifecycle: Dockerfile -> Image -> Running container.

## Section 25: Lecture 01 Synthesis and Bridge to Lecture 02

### SDLC and DevOps Foundation

Software delivery requires structured processes like SDLC and DevOps to connect development and operations through culture, automation, measurement, and feedback, ensuring that working code transitions into a reliable product.
Sources: 337180aaee19:p25

### AI System Architecture

A modern AI application is not just a model; it is a software product that wraps pretrained models or external inference engines with source code, data and vector stores, runtime environments, and user feedback mechanisms.
Sources: 337180aaee19:p26

### Local Development Environment Standardization

Before automation or deployment, developers must standardize their local environments across toolchains, project structures, dependencies, configuration variables, and execution commands to guarantee repeatable results.
Sources: 337180aaee19:p27

### Virtual Machines vs Containers

Virtual machines provide machine-level isolation by virtualizing a full machine including a guest operating system via a hypervisor, whereas containers package applications and dependencies while sharing the host OS kernel for lightweight process-level isolation.
Sources: 337180aaee19:p28

### Bridge from DevOps to MLOps

While DevOps addresses how to deliver software reliably, MLOps extends these principles to handle systems whose behavior dynamically depends on data, models, prompts, and evaluation.
Sources: 337180aaee19:p25, 337180aaee19:p26

#### 337180aaee19:p25 (content)

Lecture 01 synthesis reviewing software delivery principles, SDLC, Waterfall, Agile, DevOps, and reproducibility foundations, bridging into MLOps.

Conceptual chain of Lecture 01: Code is not enough -> SDLC responsibilities -> Waterfall planning -> Agile feedback -> DevOps delivery loop -> Local reproducibility.

#### 337180aaee19:p26 (content)

Explains why DevOps foundations matter for AI systems, illustrating that modern AI applications wrap models with source code, data, environment, and user feedback.

Source code -> Model / LLM -> Data / knowledge -> Environment -> Users & feedback.

#### 337180aaee19:p27 (content)

Outlines local development environment standardization for Lab 01, detailing toolchain, project structure, dependencies, configuration, and execution commands.

Component, Meaning, Why it matters table for Toolchain, Project structure, Dependencies, Configuration, Execution command.

#### 337180aaee19:p28 (content)

Compares virtual machines and containers as abstraction layers, highlighting VM machine-level isolation versus container process-level packaging.

Virtual machine view: Application, Libraries / runtime, Guest operating system, Hypervisor, Host operating system, Hardware. Container view: Application, Libraries / runtime, Container engine, Host operating system, Hardware.

## Section 29: MLOps Lecture Section: From DevOps to MLOps

### Local DevOps Workflow

A repeatable local workflow featuring eight steps (Plan, Code, Commit, Build, Test, Containerize, Run, Observe) that introduces core DevOps principles like traceability, automation, and feedback loops before scaling to cloud deployments [337180aaee19:p29].
Sources: 337180aaee19:p29

### Software vs Machine Learning Delivery

Traditional software delivery focuses primarily on versioning and building source code, whereas machine learning system delivery involves changing code, data, configuration, and model parameters, requiring specialized concerns like dataset tracking and drift monitoring [337180aaee19:p31].
Sources: 337180aaee19:p31

### MLOps Artifact Governance

MLOps extends DevOps by requiring control over a wider set of artifacts beyond code and container images; teams must also version dataset splits, feature definitions, experiment records, and model artifacts [337180aaee19:p32].
Sources: 337180aaee19:p32

### Core Study Checkpoints

A revision framework that tests students on fundamental distinctions such as code versus product, software lifecycle responsibilities, waterfall versus agile dynamics, and how Git and Docker ensure reproducibility [337180aaee19:p30].
Sources: 337180aaee19:p30

#### 337180aaee19:p29 (content)

Presents a minimal local DevOps workflow for UniTasks via an 8-step iterative loop: Plan, Code, Commit, Build, Test, Containerize, Run, and Observe.

WORKFLOW
1. Plan (small change or bug fix) -> 2. Code (edit source files) -> 3. Commit (record version in Git) -> 4. Build (prepare executable/package) -> | 
8. Observe (collect feedback) <- 7. Run (execute repeatably) <- 6. Containerize (package environment) <- 5. Test (check expected behavior)
feedback returns to planning
This loop is deliberately local. The same principles later scale to CI/CD, model serving, RAG applications and LLMOps pipelines.

#### 337180aaee19:p30 (content)

Provides a study checkpoint with six core concept review questions covering code vs product, SDLC, waterfall, agile, DevOps, and reproducibility, plus an exit ticket.

CHECKPOINT
1. Code vs Product: Explain why working source code is not equivalent to a complete software product.
2. SDLC: List the main lifecycle responsibilities and describe the purpose of each.
3. Waterfall: Explain why late feedback can be expensive in a sequential process.
4. Agile: Explain how iteration, increments and feedback change the delivery model.
5. DevOps: Explain why Agile does not automatically solve deployment and operations problems.
6. Reproducibility: Explain how Git and Docker contribute to repeatable work.
Exit ticket: In one sentence: What problem does DevOps solve that Agile alone does not fully solve?
Sources: OpenStax process models; Agile Manifesto; IBM and Atlassian DevOps lifecycle discussions.

#### 337180aaee19:p31 (content)

Bridges traditional software delivery with machine learning system delivery, highlighting additional MLOps concerns like tracking experiments, data validation, and drift monitoring.

BRIDGE
Traditional software delivery: Primary changing artifact: source code. Typical DevOps concern: version the code, build and test it automatically, package the application, deploy and operate it reliably, monitor behavior and user feedback.
Machine-learning system delivery: Changing artifacts now include code, data, configuration and model parameters. Additional MLOps concern: track experiments and datasets, validate data and model quality, deploy model versions safely, monitor drift and performance, retrain when the system changes.
Core bridge: DevOps teaches us to make software delivery repeatable; MLOps asks us to make model-based system delivery repeatable, observable and improvable.

#### 337180aaee19:p32 (content)

Contrasts DevOps-oriented artifacts with additional MLOps-oriented artifacts required to govern data, experiments, feature definitions, and model outputs.

ARTIFACTS
DevOps-oriented artifacts: Source code (application logic, tests, scripts), Dependencies (libraries and runtime versions), Configuration (settings and environment variables), Container image (packaged executable environment).
Additional MLOps-oriented artifacts: Dataset version (training, validation and test data), Feature definition (how raw data becomes model input), Experiment record (parameters, metrics and outputs), Model artifact (trained model file and metadata).
MLOps does not discard DevOps; it adds governance for data, experiments and model outputs.

## Section 33: MLOps: From DevOps and ML to Production AI Systems - Lab Connection, Study Support, Synthesis, and Checkpoint

### Environment Setup

Software execution requires controlled runtime assumptions to prevent reliance on machine-specific settings.
Sources: 337180aaee19:p33

### Version Control (Git / GitHub)

A project history needs to be inspectable, reversible, and shareable to ensure change traceability and recovery.
Sources: 337180aaee19:p33, 337180aaee19:p34

### Containers (Docker)

Packaging code with its dependencies reduces environment mismatch, ensuring that applications run reliably elsewhere.
Sources: 337180aaee19:p33, 337180aaee19:p34

### Software Development Life Cycle (SDLC)

Organizes engineering activities like analysis, design, development, testing, deployment, and maintenance to transform needs into delivered systems.
Sources: 337180aaee19:p34, 337180aaee19:p36

### DevOps Lifecycle

Acts as an engineering response to bridge the gap between development and operations through a continuous loop of planning, building, testing, deploying, operating, and monitoring.
Sources: 337180aaee19:p34, 337180aaee19:p35

#### 337180aaee19:p33 (content)

Lab 01 connection mapping problems introduced in lecture to practical tools like environment setup, Git, Docker, and README commands.

Table mapping problems to tools: Environment setup, Git / GitHub, Docker, README + commands.

#### 337180aaee19:p34 (content)

Recommended study materials including OpenStax SDLC, Agile Manifesto, DevOps lifecycle, Pro Git, and Docker container overview.

Recommended study materials list with topics: SDLC foundation, Process models, Agile values, DevOps lifecycle, Version control, Containers.

#### 337180aaee19:p35 (content)

Lecture synthesis detailing the six-step conceptual progression from code insufficiency to repeatable delivery via DevOps, Git, and Docker.

Progression steps 1 to 6 and essential conclusion on DevOps as a response to delivery problems.

#### 337180aaee19:p36 (content)

Concept check with four review questions covering code definition, SDLC organization, Agile importance, and delivery problems.

Questions Q1 through Q4 with expected ideas for concept assessment.

## Section 37: MLOps Lecture 01: Production AI Systems Terminology, Lab Preparation and Bridge

### Software Product vs. Source Code

A delivered system encompasses requirements, design decisions, tests, configuration, runtime environment, deployment procedures, and maintenance responsibilities, extending far beyond raw source code [337180aaee19:p37, 337180aaee19:p38].
Sources: 337180aaee19:p37, 337180aaee19:p38

### DevOps

A culture and set of practices connecting development and operations to deliver software more reliably through collaboration, automation, measurement, and feedback [337180aaee19:p37, 337180aaee19:p40].
Sources: 337180aaee19:p37, 337180aaee19:p40

### Reproducibility

The ability for another person or machine to recreate identical results using controlled code versions, documented steps, and a known execution environment, overcoming the 'it works on my machine' issue [337180aaee19:p37, 337180aaee19:p38].
Sources: 337180aaee19:p37, 337180aaee19:p38

### Git and Docker Tooling

Git serves as a history and collaboration mechanism for traceable changes, whereas Docker acts as an environment packaging mechanism for portable execution assumptions [337180aaee19:p38, 337180aaee19:p39, 337180aaee19:p40].
Sources: 337180aaee19:p38, 337180aaee19:p39, 337180aaee19:p40

### MLOps Bridge

MLOps extends standard software delivery discipline to production AI systems whose behavior additionally depends on data, models, and model-serving workflows [337180aaee19:p39, 337180aaee19:p40].
Sources: 337180aaee19:p39, 337180aaee19:p40

#### 337180aaee19:p37 (content)

Glossary of key study terms for software products, SDLC, waterfall model, agile development, DevOps, and reproducibility.

GLOSSARY
Software product
SDLC
Waterfall model
Agile development
DevOps
Reproducibility
Study rule: definitions should be connected to an example.

#### 337180aaee19:p38 (content)

Lab 01 preparation requirements detailing conceptual understanding, machine setup, and submission evidence.

PRE-LAB
1. Understand the purpose
2. Prepare the machine
3. Produce evidence
Lab design principle: every command students execute should be attached to a concept from Lecture 01.

#### 337180aaee19:p39 (content)

Bridge to Lecture 02 covering environment management, Git workflow, Docker fundamentals, and automation mindset.

NEXT
1 Environment management
2 Git workflow
3 Docker fundamentals
4 Automation mindset
Connection to the course: once students understand repeatable software delivery, we can ask what changes when the delivered system contains a machine-learning model or an LLM workflow.

#### 337180aaee19:p40 (content)

Closing slide emphasizing that professional software is not finished locally, bridging DevOps to MLOps, and introducing Lab 01 purpose.

TAKEAWAY
A professional software system is not finished when the code runs locally.
It must be specified, designed, implemented, tested, packaged, delivered, operated, monitored and improved.
Lecture 01 conclusion / Course-level bridge / Lab 01 purpose
End of Lecture 01
Next lecture: Reproducible Environments, Git Workflows, Docker Packaging and Introductory Automation
