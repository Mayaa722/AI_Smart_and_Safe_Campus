# Full-lecture quiz — unreviewed draft

Difficulty labels are uncalibrated. The keyed answer/explanation is shown for instructor review.

## 1. What is the primary conceptual distinction between SDLC activities and process models?

A. SDLC activities define how work is scheduled, whereas process models define what responsibilities must be handled.
B. SDLC activities define what responsibilities must be handled in software development, whereas process models describe how these activities are organized and sequenced over time.
C. SDLC activities apply exclusively to Agile frameworks, whereas process models apply only to Waterfall frameworks.
D. SDLC activities represent operational monitoring tasks, whereas process models represent local code development.

Key: B. SDLC activities define what responsibilities must be addressed regarding essential software responsibilities, whereas process models determine how work is organized through specific sequencing and delivery rhythms.

Sources: [p. 6](<run/rendered_slides/337180aaee19/page_0006.png>)

## 2. Which of the following conditions makes the Waterfall model an appropriate choice for a project?

A. When project requirements are uncertain, highly volatile, and need rapid daily feedback loops.
B. When the domain is well understood, requirements are stable, and formal approval is necessary.
C. When lifecycle responsibilities are intentionally mixed together into coding without distinct phases.
D. When continuous delivery and frequent experimental adjustments drive the development lifecycle.

Key: B. According to the lecture text, Waterfall can be useful when the domain is well understood, requirements are relatively stable, documentation is required, and formal approval is important before moving to the next phase.

Sources: [p. 9](<run/rendered_slides/337180aaee19/page_0009.png>)

## 3. According to the lecture, what specific consequence arises when an Agile team delivers new increments every one or two weeks?

A. Manual deployment processes and weak operational coordination become severe delivery bottlenecks.
B. Software release frequencies automatically stabilize without requiring any operational feedback.
C. Sequential project workflows must be reintroduced to enforce strict separation of duties.
D. Code development halts entirely to allow infrastructure teams to catch up with release backlogs.

Key: A. When teams deliver new increments every one or two weeks, manual deployment and weak operational coordination transform into bottlenecks, which creates the necessity for DevOps.

Sources: [p. 15](<run/rendered_slides/337180aaee19/page_0015.png>)

## 4. In the CALMS framework for DevOps, how are Automation and Lean principles defined?

A. Automation script error-prone tasks to maintain system logs, while Lean delivers work in large batches to maximize resource utilization.
B. Automation scripts repetitive and error-prone tasks to improve repeatability, while Lean delivers work in smaller batches to reduce waste, waiting time, and risk.
C. Automation enforces strict boundaries between teams to ensure security, while Lean measures data about builds and releases to improve performance.
D. Automation shares knowledge and feedback across teams, while Lean replaces version control tools with standardized documentation.

Key: B. According to the CALMS framework, Automation involves scripting or automating repetitive and error-prone tasks to improve repeatability, and Lean involves delivering work in smaller batches to reduce waste, waiting time, and risk.

Sources: [p. 18](<run/rendered_slides/337180aaee19/page_0018.png>)

## 5. What is the key structural difference between virtual machines and containers as discussed in local development environment standardization?

A. Containers virtualize a full machine including a guest operating system via a hypervisor, whereas virtual machines share the host OS kernel.
B. Virtual machines provide machine-level isolation by virtualizing a full machine including a guest operating system via a hypervisor, whereas containers share the host OS kernel for lightweight process-level isolation.
C. Both containers and virtual machines rely entirely on hardware-level hypervisors without utilizing the host operating system.
D. Containers offer physical machine isolation, whereas virtual machines only isolate individual user-space processes.

Key: B. Virtual machines provide full machine-level isolation using a hypervisor and guest OS, whereas containers share the host operating system kernel to achieve lightweight process-level isolation [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>).

Sources: [p. 28](<run/rendered_slides/337180aaee19/page_0028.png>)

## 6. Additional teaching: In an enterprise setting where a machine learning pipeline must maintain exact parity across development, staging, and production environments, why is relying solely on a Git repository containing source code insufficient?

A. Git repositories automatically package runtime binaries and system-level dependencies alongside code commits.
B. Machine learning system behavior depends heavily on data, models, configurations, and model parameters that go beyond raw source code versioning.
C. Version control systems prevent developers from tracking dataset splits and feature definitions.
D. Git handles environment standardization and containerization natively without requiring external tools like Docker.

Key: B. While Git tracks code history, machine learning delivery involves changing code, data, configuration, and model parameters, requiring additional governance over datasets, feature definitions, and container environments [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>) [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>).

Sources: [p. 31](<run/rendered_slides/337180aaee19/page_0031.png>) [p. 32](<run/rendered_slides/337180aaee19/page_0032.png>)

## 7. What is the primary role of establishing a repeatable local workflow like the one shown for UniTasks before targeting cloud deployment?

A. To eliminate the requirement for containerization steps during later pipeline automation phases
B. To replace traditional version control mechanisms with direct runtime code execution loops
C. To express fundamental DevOps concepts such as traceability, automation, and feedback locally
D. To transition software development directly into a sequential waterfall deployment model

Key: C. The primary purpose of a local DevOps workflow is to express main DevOps concepts like traceability, automation, repeatability, verification, and feedback before scaling to cloud deployment [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>).

Sources: [p. 29](<run/rendered_slides/337180aaee19/page_0029.png>)

## 8. How does MLOps specifically extend traditional DevOps principles when applied to production AI systems?

A. By replacing standard source code version control entirely with automated data pipelines.
B. By bypassing runtime environment configurations to focus exclusively on model weights.
C. By delivering software systems whose runtime behavior dynamically depends on data, models, prompts, and evaluation.
D. By restricting software delivery pipelines to static binaries that never require retraining or monitoring.

Key: C. MLOps extends traditional DevOps delivery principles by addressing systems whose behavior depends dynamically on data, models, prompts, and evaluation in addition to standard application code [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>) [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>).

Sources: [p. 25](<run/rendered_slides/337180aaee19/page_0025.png>) [p. 26](<run/rendered_slides/337180aaee19/page_0026.png>)
