# Free API lecture comparison - current evidence

Updated 17 Nov 2026 20:06 UTC. Incomplete cells are pending, not zero-quality scores.

| Lecture | API/model | Pages read | Summary | Full guide | Quiz | Tutor cases |
|---|---|---:|---|---|---:|---:|
| Iot (diagram-heavy) | Gemini 3.5 | 50/50 | Saved | Saved; source clarification | 8/8; flagged | 8/8 |
| Calculus (math-heavy) | Gemini 3.5 | 33/33 | Saved | 16 chapters; partial | 0/8 | 0/8 |
| Software (text-heavy) | Gemini 3.5 | 46/46 | Saved | 6 chapters; partial | 8/8 | 1/8 |
| Big_Data (mixed diagrams and mathematics) | Gemini 3.5 | 0/86 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Cloud (text overview with illustrations) | Gemini 3.5 | 0/36 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Data_Analysis (diagram-heavy with statistics) | Gemini 3.5 | 0/59 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Nlp (mixed text, diagrams and mathematics) | Gemini 3.5 | 0/50 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Iot (diagram-heavy) | Groq Qwen 3.8 27B | 40/50 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Calculus (math-heavy) | Groq Qwen 3.8 27B | 12/33 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Software (text-heavy) | Groq Qwen 3.8 27B | 0/46 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Big_Data (mixed diagrams and mathematics) | Groq Qwen 3.8 27B | 0/86 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Cloud (text overview with illustrations) | Groq Qwen 3.8 27B | 0/36 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Data_Analysis (diagram-heavy with statistics) | Groq Qwen 3.8 27B | 0/59 | Pending | 0 chapters; partial | 0/8 | 0/8 |
| Nlp (mixed text, diagrams and mathematics) | Groq Qwen 3.8 27B | 0/50 | Pending | 0 chapters; partial | 0/8 | 0/8 |

**Scope and status:** All 7 attached lectures (360 pages) are queued. Gemini has processed 129 pages and generated three short summaries. Both accounts reached daily free quotas. Groq returned real vision notes but has not completed any full lecture workflow. There is no defensible overall model winner yet. No paid tier or local model was used.

**Findings:** The IoT tutor answered its eight functional cases, including all four modes, visual reasoning, follow-up, unsupported questions and prompt injection. Quiz grading mechanics passed. Assistant source review found 7/8 IoT quiz items academically defensible; one repeats an oversimplified UDP source claim, and another has weak distractors. Raw outputs and automated approvals are preserved; the flagged quiz is gated. Software quiz keys reviewed: 8/8 defensible, but distractors are often too easy. These are development reviews, not instructor ratings.

**Fixed:** Separate summary tab; truncated-JSON recovery; source checkpoints; visible practice/Socratic questions and matching history; hyperbolic/derivative math rendering. Re-uploading identical tested PDFs reuses verified cached materials and preserves content flags without new generation calls.

**Metrics and judge:** Four paper-aligned RAGAS families remain. One IoT answer scored faithfulness 1.0, context precision ~1.0 and context recall 1.0; answer relevance was unscored after service failure. This is text-context evidence for one answer. New 12-criterion concept coverage and quiz validity address real gaps; automated coverage scores are still pending. A fixed Gemini judge confirmed the eight IoT tutor modes/cases, but same-family bias remains. LLM judgments support source review; they cannot establish academic truth or learning gains.

**Recommendation:** Keep Gemini 3.5 as the working baseline, based on completed functionality rather than a proven quality win. Resume only missing work after free quotas refill; finish a matched Groq workflow before deciding. Judge distractor quality and source correctness separately. Do not add more models yet. Linked videos were not ingested. Full evidence and timings are separate; this development run is not a clean speed benchmark.
