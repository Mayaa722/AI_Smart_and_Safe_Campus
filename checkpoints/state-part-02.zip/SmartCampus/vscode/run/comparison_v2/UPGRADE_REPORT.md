# SmartCampus: improved lecture workflow

Gemini 3.5 on the desktop project • Qwen 3.5 4B on Colab GPU
Development comparison and implementation review | 17 November 2026

Keep Gemini 3.5 as the prototype default. Qwen 3.5 4B is the single tested open-weight research arm: its runner now completes the workload, but source inspection still finds substantive mathematical and quiz errors. Its small size made it a practical baseline, not a demonstrated best model for the T4. A stronger replacement requires a controlled validation run. New outputs still require source review; educational superiority and student learning gains are not established.

## What was changed

| Priority | Implemented behavior |
| --- | --- |
| Original visual evidence | Every guide section receives four original page images and original text. Production tutor uses selected original images; visual search aids remain labelled model-derived notes. |
| Concept coverage | A source-based audit checks explanations, conditions, equations and diagrams. One targeted semantic repair is allowed, then remaining flags stay visible. Page accounting alone is not concept accuracy. |
| Quiz correctness | The solver sees original evidence and answer options with the generator key/explanation hidden. Ambiguity, key mismatch and distractors are checked. Editorial answer-cue flags supplement this imperfect same-model audit. |
| Math and tutoring | Restricted arithmetic checks and a narrow geometry-consistency guard flag bad estimates. Flagged drafts are retained outside normal conversation context; the main display is guarded. |
| Recovery and provenance | Checkpointed stages reuse completed work. Fixed Gemini 3.5; no silent cross-model fallback. Actual quota retry windows are shown separately from local allowances. |

The original v1 three-approach experiment, historical approved materials and metrics are preserved. Gemini 3.8 remains an availability-limited historical arm; it is not rerun in this two-arm upgrade. All three protected historical file hashes still match.

## Controlled inputs and actual completion

Both upgraded arms use the same original Hough lecture (88 pages) and MLOps lecture (40 slides), without Gemini-generated notes being transferred to Qwen. Guides use 32 four-page sections. Each lecture has eight MCQs, three direct tutor questions, one hint task and one visual probe. Quiz parts receive their quarter’s original text plus a declared central four-image subset; this is narrower visual coverage than the guides.

| Arm / lecture | Original-image pages | Guide chapters | Source audits passed | MCQs saved |
| --- | --- | --- | --- | --- |
| Gemini 3.5 / hough | 88/88 | 22 | 22 | 8 |
| Gemini 3.5 / mlops | 40/40 | 10 | 10 | 8 |
| Qwen 4B / hough | 88/88 | 22 | 4 | 8 |
| Qwen 4B / mlops | 40/40 | 10 | 9 | 8 |

Submitted original-image coverage means the recorded image hashes match the frozen original source images. It does not prove correct visual interpretation or complete topic retention. Same-model source-audit pass counts are process evidence, not instructor scores.

| Arm | All development attempts | Completed / failed attempts | Median successful attempt |
| --- | --- | --- | --- |
| Gemini 3.5 | 220 | 166 / 54 | 4.441 s |
| Qwen 4B | 170 | 153 / 14 | 69.344 s |

These totals include development prompt revisions, retries and audits, not just one final run. Qwen has three ledger reservations without a saved response record, corresponding to interrupted work; they are not labelled completed or model errors. Timing compares different deployments and varied tasks, not intrinsic model speed. The original v1 4/16 Qwen acceptance result must not be compared directly with the new chapter count.

## Content quality: improvements and remaining defects

The new Gemini Hough chapter explicitly gives (x-a)^2+(y-b)^2=r^2, center parameters (a,b), and a two-dimensional parameter space when radius is known. The old text-only study guide omitted this important visual mathematics. The measurement-noise tutor answer now uses the original figure’s statement that right-bin votes decrease as noise rises. These are specific development examples, not proof of broad superiority.

The visual probe still exposes a real Gemini error: its own intercept estimates of x≈4.1–4.2 and y≈3 imply rho≈2.42–2.44 and a normal angle≈53.8–54.5°, rather than its stated rho≈2.2 and 45°. The new deterministic guard detects this directly from the generated answer and withholds the inconsistent estimates in a derived display. It preserves the raw model answer.

The geometry guard checks internal consistency only. It is limited to explicitly labelled positive intercepts and normal angles in degrees, with engineering tolerances of 0.15 distance units and 3°. It does not verify that the model read the plot correctly, and it is not a general mathematical proof engine.

A quiz can pass a source-key audit and still be pedagogically weak. Assistant inspection found obvious distractors in several new Gemini MCQs and excessive solution disclosure in a hint. The production MLOps quiz also contained source IDs inside correct answer options, which revealed the key. New presentation checks flag these cues, while stable display-only option shuffling reduces fixed answer-position patterns. Raw model choices and keys remain intact.

Qwen completed all 22 Hough chapters, but its self-audit passed only 4 and flagged 18. Several flags demand concepts absent from the source (e.g., Sobel equations), so these are not 18 verified content errors. Actual source inspection also found real point/line duality errors and the persistent vertical-normal-angle pi/2 mistake.

The self-audit approved Hough quiz items 3, 5 and 6 despite definite point/line or polar-duality errors. Item 5 offers no correct two-sinusoid choice. Automatic source-key review is not sufficient.

MLOps quiz item 8 has no defensible answer: key B incorrectly gives Agile the development-operations gap, while its own rationale assigns that gap to DevOps. Several other choices remain weak or give answer cues.

The answer reports intercepts 4 and 3 with rho 2.2 and normal angle 60 degrees; these are inconsistent (rho 2.4 and angle 53.13 degrees follow from those intercepts). The shared geometry guard now detects both actual model phrasings and keeps raw answers unchanged.

The Qwen hint is more restrained than the observed Gemini hint and asks about slope range without giving the normal-form solution. This is a positive example, not a general pedagogical superiority claim.

Eight assistant-reviewed source correction cards and a GPU-only repair module are prepared as a separate supervised development step. They have not been executed after the browser-control stop, and are excluded from matched v2 scores.

Instructor review should assess source accuracy, important omissions, equations, ambiguity, distractor plausibility and how much a hint reveals. Automated checking cannot replace this review. Difficulty and learning gains have not been calibrated or measured.

## Runtime repairs and the live interface

Qwen’s earlier failures were partly runner problems. The old decoder integration imported a tokenizer class from a moved Transformers location. The upgraded runner uses compiled xgrammar constraints. More importantly, the tokenizer/chat end token was 248046, while the model generation default was 248044. Aligning stopping with the chat token prevents valid JSON from continuing to the full output cap. One observed first-chapter call fell from 185.9 s before that stop fix to 76.3 s after it; later prompt changes make this a diagnostic observation, not a controlled speed study.

All Qwen parameters are checked to remain on the Colab CUDA GPU; CPU/disk offload is rejected. The pinned checkpoint is 851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a, with NF4 double quantization and FP16 computation. Public weights require no private Hugging Face token. The T4’s slower reference kernels and constrained decoding still make this workflow substantially slower than the observed API calls.

A mistyped Hough source ID caused three identical greedy retries. Retries now receive the actual validation error and exact-ID instruction, rather than silently rewriting a citation. The failed chapter recovered on its next observed attempt. Truncated outputs receive a bounded larger output allowance. Every earlier attempt remains in the evidence history.

The actual Streamlit MLOps upload processed 40/40 slides and assembled ten chapters. Its initial 63 processing attempts reused four original-image-verified page-note sections, while keeping old quizzes, teacher approval and metric scores separate. Interface inspection then caught answer cues and weak distractors. Afternoon recovery finished after 89 total processing attempts: all eight revised MCQs now pass source and editorial gates, with six item-repair revisions retained. Difficulty and remaining distractor quality still need instructor review.

Google explicitly returned HTTP 429 for the free-tier 500 requests/day limit, with RetryInfo pointing to 17 November 08:00 UTC (10:00 Cairo). This differs from the observed HTTP 503 service overloads and separate local connection failures. The app now shows the provider wait, blocks live controls during it, and keeps saved guides/source pages accessible. No key, billing setting or provider quota was changed.

After the reset, one real MLOps VM/container tutor request succeeded and passed its source audit, selecting original pages [28,39,38,34]. A recovery defect was also fixed: completed quiz-item repairs are now reused after an audit outage, failed-audit state is saved, and provider failures are distinguished from actual content-review flags. The repaired editor opens the current notebook; a clean project profile addresses the old notebook webview cache error.

A separate real four-page Hough integration completed extraction, guide, two-item quiz and a source-reviewed normal-angle tutor response before the quota stop. Focused checks also caught bad arithmetic, rejected executable expressions, detected a known wrong quiz key, and preserved keys through display shuffling. No large new offline test suite or fabricated student feedback was added.

## Evaluation: what the numbers can establish

The original paper-aligned RAGAS baseline remains unchanged. This upgrade uses official RAGAS 0.4.3 faithfulness and answer relevancy for six direct answers per arm (24 planned answer-metric values). The fixed original-text retrieval questions/references/contexts match v1; inherited context precision/recall are explicitly labelled inherited, not newly measured production retrieval performance.

23 of 24 new answer-metric values are currently available. Earlier provider 503 failures and the daily 429 interrupted evaluation; afternoon runs resumed only missing values using saved caches. Any remaining unavailable values stay missing. The same Gemini 3.5 judge family introduces possible judge bias.

For 2 repeatedly failing metric rows, an opt-in equivalent-schema recovery retried responseJsonSchema after a responseSchema 503. The judge model, RAGAS prompt, source contexts and Pydantic response model were retained; actual payload hashes and transport variants are logged separately. Treat this as deployment recovery evidence, not identical API decoding.

| Arm / metric | Available n / planned 6 | Mean on available answers |
| --- | --- | --- |
| Gemini 3.5 / faithfulness | 6/6 | 0.794 |
| Gemini 3.5 / answer relevancy | 6/6 | 0.931 |
| Qwen 4B / faithfulness | 5/6 | 0.652 |
| Qwen 4B / answer relevancy | 6/6 | 0.926 |

Important interpretation: generation received original images, but this RAGAS judge saw original extracted text only. Correct image-derived equations can therefore have low text-support scores. These are text-context diagnostics, not multimodal faithfulness, whole-guide accuracy or a fair completed two-model quality ranking. Report denominators alongside every mean.

One production retrieval development probe changed the noise question’s top pages from [38,67,40,20] to [66,65,68,67] after adding labelled visual notes and concepts. The latter pages were inspected and contain the relevant noise/clutter figures. This is one development probe, not a new context-precision/recall result or a held-out retrieval benchmark.

A source-linked masked output packet and genuinely blank instructor worksheet are supplied. References are assistant-authored development references awaiting instructor validation. No independent instructor numeric ratings, questionnaire means, calibrated difficulty, learning improvement or statistical significance are claimed.

## Relationship to the paper and next actions

The two supplied PDFs are versions of the same tutoring-system paper; the final four-page version is the main reference. Source reading, Socratic modes, equation rendering, teacher review, asynchronous processing and model comparison already appear in that work. They are shared design choices, not our novelty.

| Paper relationship | What this implementation contributes / limits |
| --- | --- |
| Multimodal future direction | Original slide-image evidence throughout guides and selected tutor inputs; no image-generation feature is claimed. |
| Content trust and coverage | Separate structural page accounting from semantic source checks, key-hidden quiz review, flagged math estimates and retained revision provenance. Same-model checks are still fallible. |
| Deployment comparison | Pinned Colab open-weight execution versus local API workflow, with documented interface defects, retries, overloads, quota stops and incomplete values. |
| Different product scope | Standalone student-upload workflow; no Moodle integration by user decision. Lexical retrieval with visual search aids is not the paper’s vector/database stack. |
| Educational effectiveness | No student learning trial yet. Small development examples and human review cannot establish superiority over the paper’s different study. |

Next: use the recovered MLOps interface for a small functionality trial and review the new source-linked outputs. Resolve the Qwen source-correction cards on Colab before publishing those drafts; the optional supervised repairs are prepared but were not executed after desktop control stopped being able to verify the browser URL. Review any remaining missing metric rows separately. Correct genuine content flags before a guide becomes a sole study resource, then run a small real student trial on an unseen lecture. Keep feedback, quiz attempts, RAGAS and instructor review as separate evidence.

Evidence: run/comparison_v2/analysis.json; runtime_amendment.json; outputs/<arm>/records and attempts; original corpus/protocol/input manifests; qualitative_findings.json; ragas_scores.json; supervisor_review/MASKED_OUTPUTS.md and INSTRUCTOR_REVIEW.csv. The original v1 report and approved baseline remain separate. comparison/SmartCampus_Improved_Colab.ipynb is the clean updated-workflow notebook, including later editorial checks. Exact executed cloud code and runtime amendments are preserved separately under colab_executed; the original cloud notebook remains linked.

[Qwen official model card](https://huggingface.co/Qwen/Qwen3.5-4B)

[Transformers Qwen3.5 documentation](https://huggingface.co/docs/transformers/model_doc/qwen3_5)

[Google quota definitions and reset policy](https://aistudio.google.com/docs/rate-limits)

Paper sources: supplied ai tutoring system for moodle 1.pdf and ai tutoring system for moodle 2.pdf. No claim of globally novel methods is made.
