# AIS412 - Topic 2 - Hough Transform.pdf - checked quiz draft

Automated review: passed_automated_review. Instructor review remains separate.

1. How does edge strength relate to our perception of boundaries in computer vision?

A. Edge strength does not necessarily correspond to our perception of boundaries
B. Higher edge strength always guarantees an object boundary
C. Edge strength has a direct linear correlation with human boundary annotation
D. Perception of boundaries is solely determined by low-level edge magnitude

Key: A. As stated in the lecture, edge strength does not necessarily correspond to our perception of boundaries [6b0bc2554460:p10].

2. What do human-annotated boundary maps highlight regarding complex visual inputs?

A. Multiple variations and consensus areas in human boundary perception
B. Absolute pixel-perfect mathematical boundaries generated automatically
C. Regions where edge detection has zero gradient magnitude
D. Uniform boundary locations agreed upon instantly by all observers

Key: A. Human annotated boundaries show multiple overlapping human traces, illustrating how defining and perceiving boundaries can vary [6b0bc2554460:p12].

3. When transforming two distinct points from image space into the parameter space defined by y = mx + b, what geometric representation does each individual point yield?

A. A single intersecting point in parameter space
B. A straight line in parameter space
C. A parabola representing quadratic variation
D. An isolated set of disconnected segments

Key: B. As illustrated in the lecture, a single point in image space maps to a straight line in parameter space, and two points therefore yield two intersecting lines [6b0bc2554460:p32, 6b0bc2554460:p33].

4. In parameter space, what does the intersection point of multiple lines corresponding to different image points represent?

A. A shared set of slope and intercept parameters defining a line that passes through those points in image space
B. The origin point where all image coordinates are equal to zero
C. An error in the Hough transform accumulator array resolution
D. The total number of outlier pixels detected in the image

Key: A. When three collinear points in image space are mapped to parameter space, their respective lines intersect at a common point, indicating the shared line parameters (m and b) [6b0bc2554460:p34, 6b0bc2554460:p35].

5. When representing a single line in polar coordinates for parameter space mapping, how can the same line be written in terms of rho and an angle offset?

A. As a positive rho version x cos(theta) + y sin(theta) = rho and a negative rho version x cos(theta + pi) + y sin(theta + pi) = -rho
B. As a single unique formulation where rho must always be strictly positive and bounded by one
C. As two separate lines that intersect at right angles without sharing any common points
D. As a transformation where theta is held constant while rho varies linearly with the slope

Key: A. The lecture notes demonstrate that there are two ways to write the same line in polar parameter space: a positive rho version x cos(theta) + y sin(theta) = rho and a negative rho version x cos(theta + pi) + y sin(theta + pi) = -rho, utilizing trigonometric identities for sine and cosine offset by pi [6b0bc2554460:p55].

6. What geometric representation does a pair of distinct points in image space transform into when mapped into parameter space using polar coordinates?

A. Two intersecting sinusoidal curves in parameter space
B. A single isolated point representing their midpoint
C. Two parallel straight lines with undefined slopes
D. A closed circle whose radius depends on the distance between the points

Key: A. As shown when two image space points (such as (1,1) and (3,3)) are mapped, each point corresponds to a sinusoidal curve in parameter space, resulting in two curves that intersect at a common point [6b0bc2554460:p57].

7. When the radius of a circle is completely unknown during circle detection, what dimensional configuration does the Hough Space take?

A. 3D Hough Space with accumulator array A(a,b,r)
B. 1D Hough Space tracking only radius changes
C. 2D Hough Space mapping parameters a and b with a fixed radius
D. 4D Hough Space incorporating intensity and color gradients

Key: A. According to the lecture, if the radius is not known, the Hough transform requires a 3D Hough Space using an accumulator array A(a,b,r) [6b0bc2554460:p77].

8. When gradient information (edge location and direction) is used and the circle radius is assumed to be known, how many points must be incremented in the accumulator array for that edge pixel?

A. Only one point in the accumulator
B. An entire continuous circle of points in the accumulator
C. Two points representing opposite edge boundaries
D. A 3D volumetric surface of points

Key: A. Using gradient information and assuming a known radius allows you to calculate the center parameters directly using a = x - r cos(phi) and b = y - r sin(phi), meaning you need to increment only one point in the accumulator [6b0bc2554460:p78].

