# MLOps_Lecture01-1stOct2026 (3).pptx - checked quiz draft

Automated review: passed_automated_review. Instructor review remains separate.

1. According to the study map of SDLC phases, what is the central question answered during the Design phase?

A. How should the solution be organized before implementation begins?
B. What should the software do, for whom, and under which constraints?
C. How will the design be implemented and integrated?
D. How do we know the implemented system behaves correctly?

Key: A. The Design phase answers how the solution should be organized before implementation begins, producing typical artifacts such as architecture sketches, database schemas, and UI flows [337180aaee19:p5].

2. According to the lecture, when is the Waterfall process model best applied during a software project?

A. When frequent releases require automation, monitoring, and shared responsibility
B. When learning, feedback, and changing priorities are expected
C. When requirements are stable and documentation and control are central
D. When short repeated cycles are needed to handle high project uncertainty

Key: C. The source explicitly states that Waterfall, which arranges work mostly in sequential phases, is best when requirements are stable and documentation and control are central [337180aaee19:p6].

3. According to the lecture analysis of the transition from Agile to DevOps, which specific gap remains unaddressed by Agile practices alone?

A. The delivery and operation gap between development and operations teams
B. The feedback gap between stakeholders and developers
C. The planning gap between business analysts and project managers
D. The requirements gap between users and system architects

Key: A. Agile mainly closes the feedback gap between stakeholders and developers [337180aaee19:p14]. However, the delivery and operation gap remains, characterized by issues like local environment discrepancies, manual release steps, and late configuration handoffs [337180aaee19:p14].

4. Based on the academic definition of DevOps presented in the course, which statement best captures its core nature?

A. DevOps is fundamentally a single containerization product or cloud service like Docker or Jenkins.
B. DevOps is a socio-technical culture and set of engineering practices integrating development and IT operations.
C. DevOps is an exclusive methodology focused entirely on maximizing developer change speed without regard for operations.
D. DevOps is a replacement framework designed to eliminate all software planning and design phases.

Key: B. DevOps is not a single tool or product name; it is a socio-technical approach integrating software development and IT operations through shared culture and engineering practices [337180aaee19:p16].

5. When packaging an application with Docker for repeatable execution, which components form the container solution that addresses unknown machine state?

A. Application code, runtime, dependencies, and settings
B. Source code files and remote cloud deployment clusters only
C. Virtual machine guest operating systems and hypervisors
D. Database schemas, user feedback, and UI wireframes

Key: A. Docker solves execution variability by packing application code, runtime versions, dependencies, and settings (ports, commands, configuration) into a consistent container [337180aaee19:p24].

6. According to the MLOps extension framework, how does a modern production AI system differ fundamentally from just having a pretrained model?

A. It wraps the model with source code interfaces, data access, evaluation, security, and runtime environments
B. It eliminates the need for any underlying software runtime dependencies or source code files
C. It relies exclusively on user feedback loops without requiring local development environment setup
D. It replaces traditional software version control entirely with automated cloud model generation

Key: A. A modern AI application is not just a model; it is a software product that wraps the model with interfaces, dependencies, data access, evaluation, security, and monitoring [337180aaee19:p26].

7. Based on the course glossary and study materials, how does the Waterfall model organize major lifecycle activities?

A. Sequentially as a plan-driven model
B. Iteratively through short sprints and continuous feedback
C. As an informal collection of rapid code-only prototypes
D. Randomly based on shifting operational metrics

Key: A. According to the glossary and reading materials, the Waterfall model is a plan-driven model in which major lifecycle activities are arranged sequentially [337180aaee19:p34, 337180aaee19:p37].

8. What is the primary role of containers such as Docker in achieving reliable software delivery, as outlined in the study materials?

A. Replacing the need for writing source code and tests
B. Packaging dependencies to improve portability and repeatability
C. Managing the hardware electricity and server cooling infrastructure
D. Executing manual user interface testing automatically

Key: B. The Docker container overview study material specifies that packaging dependencies improves portability and repeatability [337180aaee19:p34]. Additional teaching: containers isolate the runtime environment to solve the "it works on my machine" problem.

