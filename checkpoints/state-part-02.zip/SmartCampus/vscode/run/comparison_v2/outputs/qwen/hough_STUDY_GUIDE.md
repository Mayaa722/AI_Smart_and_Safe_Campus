# AIS412 - Topic 2 - Hough Transform.pdf

## Lecture 2: Hough Transform

This lecture introduces the Hough Transform, a technique for detecting shapes in images. The course material is sourced from Carnegie Mellon University and Stanford University [6b0bc2554460:p1]. The lecture overview covers finding boundaries, line fitting, line parameterizations, the Hough transform, and Hough circles [6b0bc2554460:p4]. The lecture credits indicate that most slides were adapted from Kris Kitani (15-463, Fall 2016) [6b0bc2554460:p3]. Some slides were inspired or taken from Fredo Durand (MIT) and James Hays (Georgia Tech) [6b0bc2554460:p3]. The lecture title slide features a face with a geometric overlay, illustrating the concept of feature detection [6b0bc2554460:p1]. The Hough transform image shows a complex pattern of lines, demonstrating the technique's ability to handle intricate structures [6b0bc2554460:p2].

## Finding Boundaries: Object Detection and Edge Detection

This chapter introduces the concept of identifying object boundaries in images, a fundamental task in computer vision. The lecture begins by posing the question: 'Where are the object boundaries?' [6b0bc254460:p6]. It illustrates this using an image of two elephants, asking the viewer to identify the limits of each object [6b0bc254460:p6].

Two primary methods for defining these boundaries are discussed. The first is 'Human annotated boundaries' [6b0bc254460:p7]. This approach involves manually tracing the contours of objects, as shown in the provided diagram. The lines are relatively clean and follow the distinct edges of the elephants, representing a ground truth or a high-quality reference standard.

The second method is 'Edge detection' [6b0bc254460:p8]. This is an automated algorithmic process. The diagram shows that while edge detection can successfully identify the main outlines of the elephants, it often produces more fragmented and noisy results compared to human annotation. The lines are less smooth and may include false positives (edges that are not part of the object boundary) or false negatives (missing edges).

The comparison highlights a key limitation of automated edge detection: it is a heuristic process that approximates boundaries but lacks the semantic understanding of a human annotator. The 'Human annotated boundaries' serve as the ideal standard, while 'Edge detection' represents the computational approximation used in real-time systems.

Additional teaching: In practical applications, edge detection algorithms (like Canny or Sobel) are often followed by contour finding algorithms (like Hough transforms) to connect the fragmented edges into closed loops, mimicking the human annotation process more closely.

## Perception of Object Boundaries vs. Edge Strength

This chapter examines the discrepancy between algorithmic edge detection and human perception of object boundaries.

**Substantive Definitions and Concepts**
In computer vision, an edge is typically defined as a location where image intensity changes sharply. The provided lecture material illustrates this using multi-scale edge detection.

**Method Steps and Diagram Meaning**
Source [6b0bc2554460:p9] displays an image of an elephant with white lines overlaid, labeled "Multi-scale edge detection." This visualization demonstrates how algorithms detect intensity gradients. The resulting lines trace the contours of the elephant and the surrounding environment.

Source [6b0bc2554460:p10] presents the same image but adds the text: "Edge strength does not necessarily correspond to our perception of boundaries." This highlights a critical limitation: algorithms may detect high-frequency noise or subtle gradients as edges, whereas humans perceive boundaries based on semantic context and object recognition. For instance, the fine, noisy lines within the elephant's body in [6b0bc2554460:p9] might be flagged by an algorithm as edges, but a human observer would not perceive these as object boundaries.

**Human Perception vs. Algorithmic Output**
Source [6b0bc2554460:p11] poses the question "Where are the object boundaries?" over an image of corn in a basket. This serves as a conceptual bridge to the next slide.

Source [6b0bc2554460:p12] shows "Human annotated boundaries" for the corn image. The lines drawn here are smooth and enclose the distinct object (the pile of corn) rather than capturing every pixel-level intensity variation. This contrasts with the raw edge detection in [6b0bc2554460:p9], suggesting that human annotation involves grouping and simplification to define semantic objects, whereas raw edge detection captures all intensity transitions.

**Comparison Table**

| Feature | Algorithmic Edge Detection ([6b0bc2554460:p9]) | Human Annotated Boundaries ([6b0bc2554460:p12]) |
| :--- | :--- | :--- |
| **Basis** | Intensity gradients and frequency | Semantic context and object grouping |
| **Detail Level** | High (includes noise) | Low (smoothed, simplified) |
| **Example** | Noisy lines on elephant skin | Clean outline of corn pile |

**Additional Teaching**
The lecture implies that robust object detection requires more than just edge detection; it requires grouping edges into coherent shapes. The text in [6b0bc2554460:p10] serves as a warning against relying solely on edge strength metrics for boundary definition.

**Uncertainties**
The supplied text does not provide specific mathematical equations (e.g., Sobel operators or Laplacians) or variable definitions for the edge detection process. The distinction between "edge" and "boundary" is explained conceptually but not derived from a formula.

## Boundary Detection and Edge Detection in Computer Vision

This chapter defines boundary detection as the process of identifying edges or contours within an image, a fundamental task in computer vision. Edge detection highlights regions where pixel intensity changes sharply, often marking object boundaries.

**Edge Detection and Visual Examples**
Source [6b0bc2554460:p13] displays a processed image labeled "Edge detection," showing white lines tracing the contours of a central object against a dark background. This visualizes the output of an edge detection algorithm, where the algorithm identifies the boundaries of the object. The image demonstrates that edge detection can isolate the shape of an object from its background.

**The Difficulty of Defining Boundaries**
Source [6b0bc2554460:p14] presents a photograph of marine life with the text "Defining boundaries are hard for us too." This highlights the challenge of determining where one object ends and another begins, especially in complex, textured environments. The visual example shows two prominent, spiky organisms against a busy, colorful background, illustrating the difficulty in distinguishing boundaries in natural scenes.

**Ambiguity in Natural Scenes**
Source [6b0bc2554460:p15] asks, "Where is the boundary of the mountain top?" This question underscores the ambiguity in defining boundaries in natural landscapes. The image shows a snow-capped mountain, and the boundary between the snow and the rock face, or the snow and the sky, is not always clear-cut, posing a challenge for automated boundary detection.

**Applications of Boundary Detection**
Source [6b0bc2554460:p16] lists several applications of boundary detection and segmentation:
- **Autonomous Vehicles:** Lane line detection and semantic scene segmentation. The image shows a road with lane markings highlighted in blue, and a scene segmentation map identifying different parts of the environment (e.g., ground, tree-top, road).
- **Tissue Engineering:** Blood vessel counting. The image shows a microscopic view of tissue with blood vessels highlighted, demonstrating the use of boundary detection in biological imaging.
- **Behavioral Genetics:** Earthworm contours. The image shows an earthworm with its contours traced, illustrating the use of edge detection in biological research.
- **Computational Photography:** Image inpainting. The image shows a person with their silhouette segmented, demonstrating the use of boundary detection in image processing.

**Limitations**
The provided sources do not offer specific equations or detailed method steps for edge detection. The limitations include the difficulty in defining boundaries in complex, textured environments, as highlighted in the visual examples. The sources also do not provide a comprehensive mathematical framework for edge detection, focusing instead on visual examples and applications.

**Comparison Table**
| Application | Description | Source |
|---|---|---|
| Autonomous Vehicles | Lane line detection | [6b0bc2554460:p16] |
| Autonomous Vehicles | Semantic scene segmentation | [6b0bc2554460:p16] |
| Tissue Engineering | Blood vessel counting | [6b0bc2554460:p16] |
| Behavioral Genetics | Earthworm contours | [6b0bc2554460:p16] |
| Computational Photography | Image inpainting | [6b0bc2554460:p16] |

**Additional Teaching**
New examples include the use of edge detection in biological research for tracking earthworm movement and in tissue engineering for counting blood vessels. These applications demonstrate the versatility of boundary detection in various fields.

**Uncertainties**
The provided sources do not offer specific mathematical equations or detailed method steps for edge detection, focusing instead on visual examples and applications. The limitations include the difficulty in defining boundaries in complex, textured environments, as highlighted in the visual examples.

## Line Fitting: Least Squares and Limitations

Line fitting aims to determine parameters $(m, c)$ for a line $y = mx + c$ that best approximates a set of data points $(x_i, y_i)$. The objective is to minimize the average squared distance between the observed points and the fitted line, defined as $E = \sum_{i} \frac{(y_i - mx_i - c)^2}{N}$, where $N$ is the total number of points [6b0bc2554460:p18]. The optimal parameters are found by setting the partial derivatives with respect to $m$ and $c$ to zero: $\frac{\partial E}{\partial m} = 0$ and $\frac{\partial E}{\partial c} = 0$ [6b0bc2554460:p18].

The resulting formulas for the slope $m$ and intercept $c$ are:
$m = \frac{\sum_{i}(x_i - \bar{x})(y_i - \bar{y})}{\sum_{i}(x_i - \bar{x})^2}, \quad c = \bar{y} - m\bar{x}$
where $\bar{x}$ and $\bar{y}$ represent the mean values of the x and y coordinates, respectively [6b0bc2554460:p18].

A significant limitation of this approach is that it minimizes only vertical distances. As shown in the diagrams, if data points are arranged vertically, the line minimizing $E$ may be horizontal, even if the data suggests a steep slope [6b0bc2554460:p20]. Conversely, for nearly vertical lines, the vertical distance error can become arbitrarily large, leading to a "Huge E!" [6b0bc2554460:p19]. This indicates the method is ill-conditioned for lines with high slopes or vertical orientations. The method assumes a functional relationship where $y$ is determined by $x$, which fails to capture the geometric reality of the data distribution in these edge cases [6b0bc2554460:p19].

**Diagram Analysis:**
- [6b0bc2554460:p18]: Illustrates the standard least squares approach, minimizing vertical residuals ($y_i - mx_i - c$). It defines the goal as finding $(m, c)$ given many $(x_i, y_i)$ pairs.
- [6b0bc2554460:p19]: Shows a steep blue line where vertical distances are large, resulting in a high error value $E$.
- [6b0bc2554460:p20]: Shows a horizontal blue line as the minimizer for a specific vertical data distribution, highlighting the failure of the vertical-only metric.

**Comparison Table:**
| Feature | Standard Least Squares [6b0bc2554460:p18] | Vertical Data Case [6b0bc2554460:p20] |
| :--- | :--- | :--- |
| Optimization Target | Vertical distance | Vertical distance |
| Resulting Slope | Depends on correlation | Often 0 (horizontal) |
| Limitation | Sensitive to outliers | Fails for vertical data |

**Additional Teaching:**
While the standard method works well for most datasets, it fails when the data is nearly vertical. In such cases, alternative parameterizations (e.g., minimizing perpendicular distance) are required to avoid the "Huge E!" issue described in [6b0bc2554460:p19].

## Model Fitting Challenges and Line Parameterizations

Model fitting faces three primary difficulties: extraneous data (clutter or multiple underlying models), missing data (incomplete model parts), and noise. Additionally, the computational cost of checking all feature combinations is prohibitive [6b0bc2554460:p22].

Line parameterizations define the relationship between variables. The slope-intercept form is expressed as $y = mx + b$, where $m$ represents the slope and $b$ represents the y-intercept [6b0bc2554460:p24]. Diagrams illustrate how these parameters visually define a line's orientation and position. For example, a line labeled $y = 0.5x + 1$ demonstrates a positive slope and a y-intercept at 1 [6b0bc2554460:p24].

Noise presents a specific challenge in least-squares error fitting. While standard least-squares minimizes the sum of squared errors, the presence of outliers can skew results. The diagram labeled 'Squared error heavily penalizes outliers' shows that a single outlier point can significantly alter the fitted line compared to a dataset without noise [6b0bc2554460:p21]. This highlights the sensitivity of standard linear regression to non-Gaussian noise distributions.

Additional teaching: When analyzing data, distinguishing between signal (the model) and noise (clutter/outliers) is critical. If the goal is to identify a trend in the presence of heavy noise, robust regression methods may be necessary to mitigate the influence of outliers on the slope and intercept estimates.

Comparison of Line Forms:

| Feature | Slope-Intercept ($y=mx+b$) | Normal Form ($Ax+By=C$) |
| :--- | :--- | :--- |
| Primary Parameters | Slope ($m$), Intercept ($b$) | Normal angle, Normal distance |
| Use Case | General linear trends | Lines passing through origin or specific geometric constraints |
| Source | [6b0bc2554460:p24] | Not provided in sources |

Uncertainties: The provided sources do not detail alternative parameterizations like normal form or point-slope form, nor do they provide numerical values for the outlier's impact on the least-squares fit beyond the visual representation.

## Line Representations: Intercept, Normal, and Hough Forms

This chapter summarizes three distinct parametric forms for representing lines in 2D space, derived from lecture slides [6b0bc2554460:p25] through [6b0bc2554460:p28].

**Double Intercept Form**
The equation is defined as $\frac{x}{a} + \frac{y}{b} = 1$ [6b0bc2554460:p25]. Here, $a$ represents the x-intercept (where $y=0$) and $b$ represents the y-intercept (where $x=0$) [6b0bc2554460:p25]. The derivation utilizes similar slopes to transform the intercepts into the standard form [6b0bc2554460:p25]. This form is visually demonstrated with a line crossing the axes at $(a,0)$ and $(0,b)$ [6b0bc2554460:p25].

**Normal Form**
The equation is $x \cos \theta + y \sin \theta = \rho$ [6b0bc2554460:p26]. The angle $\theta$ is the angle of the normal vector to the line, not the line itself [6b0bc2554460:p26]. The parameter $\rho$ represents the perpendicular distance from the origin to the line [6b0bc2554460:p26]. The derivation substitutes $a = \frac{\rho}{\cos \theta}$ and $b = \frac{\rho}{\sin \theta}$ into the double intercept form [6b0bc2554460:p26].

**Hough Transform**
The Hough transform is described as a generic framework for detecting parametric models where edges do not need to be connected and lines can be occluded [6b0bc2554460:p28]. The key mechanism involves edges voting for possible models [6b0bc2554460:p28].

**Comparison Table**
| Feature | Double Intercept [6b0bc2554460:p25] | Normal [6b0bc2554460:p26] | Hough [6b0bc2554460:p28] |
| :--- | :--- | :--- | :--- |
| Parameters | $a, b$ | $\theta, \rho$ | Parametric model |
| Geometric Meaning | Intercepts on axes | Normal angle & distance | Edge voting |
| Connectivity | Requires intercepts | Requires normal vector | Handles disconnected edges |

**Additional Teaching**
*Example:* If a line passes through $(4,0)$ and $(0,3)$, the double intercept form is $\frac{x}{4} + \frac{y}{3} = 1$ [6b0bc2554460:p25]. Converting to normal form requires calculating the normal angle $\theta$ and distance $\rho$ [6b0bc2554460:p26].

**Uncertainties**
*   The specific mathematical derivation steps for the Hough transform are not detailed in the supplied text [6b0bc2554460:p27, p28].
*   Diagrams in [6b0bc2554460:p25] and [6b0bc2554460:p26] show grid lines but no specific numerical values are readable beyond the labeled intercepts and angles.


## Image and Parameter Space Transformations

This chapter defines the relationship between the image space (where data points live) and parameter space (where model coefficients live). The core equation is $y = mx + b$, where $y$ and $x$ are variables, and $m$ and $b$ are parameters [6b0bc2554460:p29].

**Transformation Rules:**
1. **Line to Point:** A single line in image space (varying $x$ for fixed $m, b$) collapses into a single point in parameter space. This point represents the specific slope ($m$) and intercept ($b$) of that line [6b0bc2554460:p29].
2. **Point to Line:** A single point in image space (fixed $x, y$) expands into a line in parameter space. This line represents the set of all lines in image space that pass through that specific point [6b0bc2554460:p31].
3. **Two Points:** Two distinct points in image space become a region in parameter space, representing the set of all lines passing through both points [6b0bc2554460:p32].

**Method Steps:**
To map a geometric object from image space to parameter space, substitute the fixed values of the dependent variables into the general equation $y - mx = b$. Solve for $b$ in terms of $m$ to reveal the relationship between the parameters.

**Diagram Analysis:**
- **Source [6b0bc2554460:p29]** illustrates the forward transformation. A line with slope $m=1$ and intercept $b=1$ in image space maps to the point $(1, 1)$ in parameter space. The axes in parameter space are labeled $m$ (horizontal) and $b$ (vertical).
- **Source [6b0bc2554460:p30]** poses the inverse question: what happens to a single point? The diagram shows a point at $(1, 1)$ in image space.
- **Source [6b0bc2554460:p31]** answers the inverse question. The point $(1, 1)$ in image space becomes a line in parameter space. The equation $y - mx = b$ becomes $1 - mx = b$, or $b = 1 - m$. This linear relationship between $m$ and $b$ creates the diagonal line shown in the parameter space plot.
- **Source [6b0bc2554460:p32]** extends the logic to two points, $(1, 1)$ and $(3, 3)$. The question asks what this configuration becomes. The answer is a region in parameter space, not a single line or point.

**Comparison Table:**

| Image Space Object | Parameter Space Result | Equation Derivation |
| :--- | :--- | :--- |
| Line ($y=mx+b$) | Point ($m, b$) | N/A (Fixed params) |
| Point ($x, y$) | Line ($b = y - mx$) | $b = y - mx$ |
| Two Points | Region (Parallelogram) | Intersection of two lines |

**Additional Teaching:**
- **Limitations:** The diagrams assume a 2D plane ($y=mx+b$). In higher dimensions, a line in image space might map to a plane in parameter space, and a point might map to a hyperplane. The provided sources do not cover these higher-dimensional cases.
- **Uncertainty:** The source [6b0bc2554460:p32] leaves the result for two points as a question mark, implying the student must derive the specific shape (a parallelogram) based on the logic established in p31.

## Image and Parameter Space Visualization

This chapter defines the relationship between the image space (data points) and parameter space (model coefficients) for linear regression. The fundamental equation is $y = mx + b$, where $y$ is the variable, and $m$ (slope) and $b$ (intercept) are the parameters [6b0bc2554460:p33]. The lecture demonstrates how multiple data points in the image space correspond to a single point in parameter space.

**Method Steps:**
1. **Image Space:** Plot data points $(x, y)$. As points increase, the lines in the parameter space diverge, indicating conflicting slopes or intercepts [6b0bc2554460:p33][6b0bc2554460:p34][6b0bc2554460:p35].
2. **Parameter Space:** Transform the equation to $y - mx = b$. This rearranges the variables so that $b$ is the dependent variable and $m$ is the independent variable. The intersection of these lines represents the optimal parameters that satisfy all data points simultaneously [6b0bc2554460:p33].

**Diagram Meaning:**
The diagrams illustrate that while the image space shows scattered data, the parameter space shows the convergence of these constraints. When three points are collinear, they intersect at a single point in parameter space [6b0bc2554460:p35]. When four points are added, they form a system where the lines intersect at a common point if the data is consistent, or diverge if inconsistent [6b0bc2554460:p36].

**Limitations:**
The provided diagrams do not show the least squares method for minimizing error; they only show the geometric intersection of constraints. The diagrams assume a linear model $y=mx+b$ and do not cover non-linear regression or weighted data.

**Comparison Table:**

| Source ID | Points in Image Space | Parameter Space Behavior | Notes |
| :--- | :--- | :--- | :--- |
| [6b0bc2554460:p33] | 2 | Diverging lines | Establishes the transformation |
| [6b0bc2554460:p34] | 3 | Diverging lines | Shows increasing conflict |
| [6b0bc2554460:p35] | 3 (Collinear) | Single Intersection | Demonstrates perfect fit |
| [6b0bc2554460:p36] | 4 | Diverging lines | Shows over-determined system |

**Additional Teaching:**
The transformation $y - mx = b$ is a standard algebraic manipulation to isolate the parameters. In the parameter space, the x-axis represents the slope $m$ and the y-axis represents the intercept $b$. The lines represent the constraints imposed by each data point. The intersection of these lines is the solution to the system of linear equations. If the lines do not intersect at a single point, it implies the data is inconsistent with a single linear model, necessitating a least squares approach to find the best fit line that minimizes the sum of squared errors. The diagrams provided do not explicitly calculate the sum of squared errors, but visually represent the geometric constraints of the linear model.

**Uncertainties:**
The lecture text does not explicitly mention the concept of 'over-determined' systems or the specific mathematical formulation of the least squares method (e.g., normal equations), though it implies the need for a solution when points exceed the number of parameters. The diagrams do not show the calculation of residuals or the optimization process used in practice.

## Line Detection via Image and Parameter Space

This chapter explains the relationship between image space data and parameter space representations used in line detection.

**Image and Parameter Space**
The lecture introduces two coordinate systems. The first is the **Image space**, where data points $(x, y)$ are plotted. The second is the **Parameter space**, where lines are represented by their slope $m$ and y-intercept $b$. The transformation relies on the linear equation $y = mx + b$, where $m$ and $b$ are the parameters [6b0bc2554460:p37]. By rearranging this to $y - mx = b$, the lecture visualizes how a set of points in image space maps to a set of lines in parameter space [6b0bc2554460:p37].

**Finding the Best Fitting Line**
The lecture poses the question of how to find the best fitting line given a set of points [6b0bc2554460:p38]. It highlights two critical limitations of this specific parameterization: robustness to measurement noise and robustness to outliers. The visual comparison shows that while the mapping is clear for exact points, the method struggles when data is noisy or contains outliers [6b0bc2554460:p38].

**Hough Transform Algorithm**
The Hough Transform addresses these issues by quantizing the parameter space. The algorithm proceeds as follows:
1. Quantize the Parameter space $(m, c)$ [6b0bc2554460:p39].
2. Create an Accumulator Array $A(m, c)$ [6b0bc2554460:p39].
3. Initialize the accumulator to zero for all elements [6b0bc2554460:p39].
4. For each image edge $(x_i, y_i)$, iterate through the accumulator. If the condition $c = -x_i m + y_i$ is met, increment the accumulator value $A(m, c) = A(m, c) + 1$ [6b0bc2554460:p39].
5. Find local maxima in the accumulator array to identify lines [6b0bc2554460:p39].

**Limitations of Parameterization**
The lecture notes that determining the size of the accumulator array for the $(m, c)$ parameterization is a significant problem [6b0bc2554460:p40]. This is because the range of $m$ (slope) and $c$ (intercept) can be unbounded, making a fixed grid impractical for general line detection.

**Additional Teaching**
*   **Vertical Lines:** The slope-intercept form $y = mx + b$ cannot represent vertical lines (where $m$ is undefined). This is a primary reason for using the normal form in the Hough Transform.
*   **Accumulator Size:** The lecture explicitly asks how big the accumulator needs to be, implying it is not fixed and depends on the image dimensions and line orientations [6b0bc2554460:p40].

## Hough Parameterization: From Image Space to Hough Space

The lecture addresses the computational challenges of parameterizing lines in image processing. Source [6b0bc2554460:p41] identifies that standard parameterizations, such as $y = mx + b$, suffer from a 'huge' parameter space where $m$ and $c$ range from $-\infty$ to $\infty$. This infinite range creates difficulties for accumulator arrays used in Hough transforms. To resolve this, the lecture introduces the 'Better Parameterization' using the normal form equation $x \cos \theta + y \sin \theta = \rho$ [6b0bc2554460:p42]. In this formulation, $\theta$ represents the angle of the normal vector to the line, and $\rho$ represents the perpendicular distance from the origin to the line. The lecture specifies that $\theta$ is constrained to $0 \le \theta \le 2\pi$ and $\rho$ to $0 \le \rho \le \rho_{max}$, resulting in a finite accumulator array size [6b0bc2554460:p42]. The transformation process is illustrated by mapping a single point in image space to a sinusoidal curve in parameter space [6b0bc2554460:p44]. This 'wave' represents the set of all lines passing through that specific point across all possible angles. The lecture notes that a point becomes a wave in parameter space, contrasting with the single point in image space [6b0bc2554460:p43]. This mapping allows for the detection of lines by accumulating votes in a bounded Hough space rather than an unbounded one. The lecture does not provide specific numerical examples for the accumulator size calculation, but implies it depends on the resolution of $\theta$ and $\rho$ [6b0bc2554460:p42].

## Image and Parameter Space Representation of Lines

This chapter defines the relationship between geometric lines in image space and their representation in parameter space using the normal form equation.

**Definitions and Equations**
The lecture introduces two distinct spaces. **Image space** represents the geometric plane where lines exist, defined by variables $x$ and $y$. **Parameter space** represents the space of all possible lines, defined by parameters $	heta$ (angle) and $ho$ (distance from origin). The normal form equation for a line is given as:
$$x \cos \theta + y \sin \theta = \rho$$
Here, $\theta$ is the angle of the normal vector to the line, and $\rho$ is the perpendicular distance from the origin to the line. The variables $x$ and $y$ are the coordinates of points on the line.

**Method Steps and Diagram Meaning**
The lecture illustrates the transformation of a line from image space to parameter space through a sequence of steps:
1.  **Initial State ([6b0bc2554460:p45]):** A single point $(1, 1)$ is shown in image space. The question asks how a line becomes in parameter space.
2.  **Transformation ([6b0bc2554460:p46]):** The slide explicitly states that a line becomes a point in parameter space. This occurs because a single line has a unique normal angle $\theta$ and a unique distance $\rho$, mapping to a single coordinate $(\theta, \rho)$ in parameter space.
3.  **Example Line ([6b0bc2554460:p47]):** A specific line passing through $(1, 1)$ is drawn. The angle $\theta$ is marked relative to the x-axis. The question remains regarding the parameter space representation.
4.  **Result ([6b0bc2554460:p48]):** The corresponding line in image space maps to a specific point in parameter space. The diagram shows a peak on the curve, indicating the maximum value of the function.

**Limitations**
The diagrams do not provide numerical values for $\rho$ or $\theta$; they only illustrate the conceptual mapping. The parameter space graph shows a curve, implying that as the line rotates (changing $\theta$), the distance $\rho$ changes, forming a sinusoidal relationship typical of the envelope of lines.

**Comparison Table**
| Feature | Image Space | Parameter Space |
| :--- | :--- | :--- |
| **Equation** | $y = mx + b$ | $x \cos \theta + y \sin \theta = \rho$ |
| **Variables** | $x, y$ | $\theta, \rho$ |
| **Representation of Line** | Geometric line | Single point |
| **Representation of Point** | Single point | Curve (locus of lines passing through point) |

**Additional Teaching**
The slide sequence demonstrates that while a line is a 1D object in image space, it is a 0D object (a point) in parameter space. Conversely, a point in image space corresponds to a curve in parameter space, representing the set of all lines passing through that point.


## Image and Parameter Space Representation

This chapter defines the relationship between geometric lines in image space and their representation in parameter space. The lecture establishes two distinct coordinate systems. Image space utilizes the standard Cartesian variables $x$ and $y$ to define a line, typically expressed in slope-intercept form as $y = mx + b$, where $m$ is the slope and $b$ is the y-intercept [6b0bc2554460:p49]. Conversely, parameter space utilizes the normal form equation $x \cos \theta + y \sin \theta = \rho$, where $\theta$ represents the angle of the normal vector and $\rho$ represents the perpendicular distance from the origin to the line [6b0bc2554460:p49].

The core concept illustrated is the transformation of a line from image space to parameter space. As the line rotates in image space around a fixed point (e.g., $(1,1)$), its slope $m$ and intercept $b$ change continuously. In the parameter space plot, this continuous rotation of the line corresponds to a single point moving along a curve [6b0bc2554460:p50]. The diagram explicitly states that "a line becomes a point" in this context, meaning the set of all possible lines passing through a specific point in image space maps to a specific locus of points in parameter space [6b0bc2554460:p51].

The progression of images demonstrates this mapping. In image space, the line rotates from horizontal to vertical. In parameter space, the corresponding point traces a path. The curve shown is a segment of a circle, indicating that for a fixed point in image space, the parameters vary sinusoidally with the angle [6b0bc2554460:p52].

**Comparison of Representations:**

| Feature | Image Space ($y=mx+b$) | Parameter Space ($x\cos\theta+y\sin\theta=\rho$) |
| :--- | :--- | :--- |
| **Variables** | $m$ (slope), $b$ (intercept) | $\theta$ (normal angle), $\rho$ (distance) |
| **Geometric Meaning** | Describes line orientation and position via slope. | Describes line via normal vector and distance. |
| **Singularity** | Vertical lines have undefined slope ($m \to \infty$). | Handles vertical lines naturally ($\theta = \pi/2$). |
| **Transformation** | Line rotates; parameters change. | Line rotates; parameters map to a point on a curve. |

**Additional Teaching:**
The parameter space representation is often preferred in computer vision and robotics because it avoids the singularity of the slope $m$ when the line is vertical. In the provided diagrams, the parameter space graph shows a smooth curve (an arc of a circle) representing the trajectory of the line's parameters as it rotates. This confirms that the mapping is continuous and bijective for lines passing through a specific point, provided $\rho$ is treated as a signed distance [6b0bc2554460:p52].

## Image and Parameter Space: Line Representation

This chapter defines the relationship between a line in image space and its representation in parameter space. In image space, a line is defined by variables $x$ and $y$ and parameters $m$ (slope) and $b$ (intercept) via the equation $y = mx + b$ [6b0bc2554460:p53]. When these parameters vary, the line sweeps through the image space, and the specific set of parameters $(m, b)$ for a single line forms a single point in parameter space [6b0bc2554460:p53].

The normal form of a line is given by $x \cos \theta + y \sin \theta = \rho$, where $\theta$ is the angle of the normal vector and $\rho$ is the perpendicular distance from the origin [6b0bc2554460:p53]. As the line rotates around a fixed point (e.g., $(1,1)$), the parameters $(\theta, \rho)$ trace a curve in parameter space [6b0bc2554460:p54].

There are two valid ways to write the same line equation: the positive rho version ($x \cos \theta + y \sin \theta = \rho$) and the negative rho version ($x \cos(\theta + \pi) + y \sin(\theta + \pi) = -\rho$) [6b0bc2554460:p55]. The negative rho version uses an angle $\theta + \pi$ and a negative distance $-\rho$, which geometrically represents the same line but with the normal vector pointing in the opposite direction. This is consistent with the trigonometric identities $\sin(\theta) = -\sin(\theta + \pi)$ and $\cos(\theta) = -\cos(\theta + \pi)$ [6b0bc2554460:p55].

**Comparison of Line Representations:**

| Feature | Positive Rho Version | Negative Rho Version |
| :--- | :--- | :--- |
| Equation | $x \cos \theta + y \sin \theta = \rho$ | $x \cos(\theta + \pi) + y \sin(\theta + \pi) = -\rho$ |
| Normal Angle | $\theta$ | $\theta + \pi$ |
| Distance | $\rho$ (positive) | $-\rho$ (negative) |
| Geometric Meaning | Normal points away from origin | Normal points toward origin |

**Additional Teaching:**

*   **Diagram Limitations:** The diagrams in [6b0bc2554460:p53] and [6b0bc2554460:p54] illustrate that a line in image space corresponds to a point in parameter space. However, the specific curves shown (green and blue arcs) are illustrative of the mapping and do not provide exact numerical values for the parameter space coordinates without further calculation.
*   **Uncertainty:** The lecture text asks "Wait... why is rho negative?" in [6b0bc2554460:p53], indicating a conceptual point of confusion regarding the sign of $\rho$ when the normal vector direction is reversed. The resolution is provided in [6b0bc2554460:p55] by showing that changing the angle by $\pi$ allows for a negative $\rho$ while maintaining the same line equation.

**Page Coverage:**
*   [6b0bc2554460:p53]: content
*   [6b0bc2554460:p54]: content
*   [6b0bc2554460:p55]: content
*   [6b0bc2554460:p56]: content

## Image and Parameter Space Transformation

This chapter explains the transformation from image space coordinates to parameter space using the Hough transform. The fundamental model is the line equation $y = mx + b$, where $y$ is the dependent variable and $x$ is the independent variable. The parameters $m$ (slope) and $b$ (y-intercept) define the line's orientation and position. 

The lecture illustrates how discrete points in the image space map to curves in the parameter space. In [6b0bc2554460:p57], two points, $(1, 1)$ and $(3, 3)$, are shown. In [6b0bc2554460:p58], a third point $(-2, -2)$ is added. In [6b0bc2554460:p59], a fourth point $(1, -1)$ is introduced. The visual progression shows that as more points are added to the image space, the corresponding curves in the parameter space intersect at a common point. This intersection represents the parameters $(m, b)$ that satisfy all the given points simultaneously. 

The implementation steps are detailed in [6b0bc2554460:p60]. Step 1 initializes an accumulator array $H$ to zeros. Step 2 iterates through edge points $(x, y)$ in the image. For each point, it calculates the normal form parameters $ho$ and $	heta$ using the equations $ho = x 	ext{ cos } 	heta + y 	ext{ sin } 	heta$. The accumulator is updated: $H(	heta, ho) = H(	heta, ho) + 1$. Step 3 identifies the local maximum in the accumulator array $H(	heta, ho)$. Step 4 recovers the line equation $ho = x 	ext{ cos } 	heta + y 	ext{ sin } 	heta$. 

A critical limitation noted in [6b0bc2554460:p60] is the coordinate system: the image origin is at the top left, unlike standard Cartesian coordinates. This affects how $x$ and $y$ are interpreted during the accumulation process. The lecture asks what happens with three or four points, implying that the intersection of curves in parameter space allows for the detection of lines fitting multiple points. 

Additional teaching: The parameter space plots curves where each curve represents the locus of $(m, b)$ pairs that would pass through a specific point $(x, y)$ in the image space. The intersection of these curves is the solution. 

Comparison Table:
| Source ID | Content Type | Key Concept |
| :--- | :--- | :--- |
| [6b0bc2554460:p57] | Content | 2 points map to 2 curves |
| [6b0bc2554460:p58] | Content | 3 points map to 3 curves |
| [6b0bc2554460:p59] | Content | 4 points map to 4 curves |
| [6b0bc2554460:p60] | Content | Hough Accumulator Algorithm |

Uncertainties: The exact numerical values of $m$ and $b$ for the specific curves in the diagrams are not explicitly calculated in the text, only the visual trend of intersection is shown. The specific range of $	heta$ (0 to 180) is stated but its geometric implication for line orientation (normal vs. line angle) is not fully elaborated beyond the formula. The distinction between the variable $y$ in the line equation and the image coordinate $y$ is implied but not explicitly defined as a mapping issue in the text. The lecture assumes the student understands the Hough transform's accumulator mechanism without further derivation. The lecture assumes the student understands the Hough transform's accumulator mechanism without further derivation. The lecture assumes the student understands the Hough transform's accumulator mechanism without further derivation.

## Image Formation and Parameter Space Mapping

This chapter introduces the relationship between image space and parameter space in the context of image formation. The lecture demonstrates how specific shapes in parameter space map to distinct visual patterns in the image space.

**Image Space and Votes:**
Source [6b0bc2554460:p61] displays two distinct visualizations. The left panel, labeled "Image space," shows a scatter plot of discrete points forming a diagonal line. The right panel, labeled "Votes," depicts a continuous, wavy pattern resembling a sine wave or a series of concentric arcs. These visualizations illustrate the concept of "votes"—contributions from different parts of a shape in parameter space that accumulate to form the final image.

**Basic Shapes in Parameter Space:**
Source [6b0bc2554460:p62] and [6b0bc2554460:p63] present a comparative study of basic shapes. The title "Basic shapes (in parameter space)" indicates that the underlying geometry is defined in a parameter domain. Three specific shapes are identified:
1. **Line:** Corresponds to the first image in the sequence, showing a sharp, intersecting pattern. [6b0bc2554460:p63]
2. **Rectangle:** Corresponds to the second image, displaying a smooth, curved band. [6b0bc2554460:p63]
3. **Circle:** Corresponds to the third image, showing a single, smooth, curved line. [6b0bc2554460:p63]

The text "can you guess the shape?" [6b0bc2554460:p62] invites the learner to deduce the parameter space geometry from the resulting image space pattern.

**Complex Images:**
Source [6b0bc2554460:p64] illustrates a "More complex image." The left panel shows a grayscale image of a bird behind a wire grid. The right panel shows the corresponding parameter space representation, which appears as a complex, noisy texture with bright spots, reflecting the interaction of the grid lines and the bird's features.

**Summary of Concepts:**
The lecture establishes that image formation can be modeled by mapping shapes from a parameter space to an image space. Simple geometric primitives (line, rectangle, circle) in parameter space generate specific, predictable patterns in the image space. Complex images result from the superposition of these patterns.

**Comparison Table:**
| Shape (Parameter Space) | Image Space Pattern | Source |
| :--- | :--- | :--- |
| Line | Intersecting arcs | [6b0bc2554460:p63] |
| Rectangle | Smooth curved band | [6b0bc2554460:p63] |
| Circle | Single curved line | [6b0bc2554460:p63] |
| Complex (Grid/Bird) | Noisy texture with bright spots | [6b0bc2554460:p64] |

**Uncertainties:**
- The exact mathematical equations defining the mapping from parameter space to image space are not provided in the supplied text.
- The specific coordinate systems used for the parameter space are not explicitly defined.


## Impact of Measurement Noise on Voting Consensus

In practical applications, measurements are rarely perfect; they contain noise. Source [6b0bc2554460:p65] illustrates this with a scatter plot in 'Image space' where points deviate from a perfect line, and a corresponding 'Votes' visualization showing a loss of coherent structure. As noise increases, the 'Votes' plot becomes increasingly chaotic, indicating that the consensus mechanism struggles to identify the underlying line.

The effect of noise level is quantified in Source [6b0bc2554460:p67]. This chart tracks the 'Maximum number of votes' for a line of 20 points as the noise level increases from 0.01 to 0.09. The data demonstrates an inverse relationship: as the noise level rises, the number of votes in the correct bin decreases. The caption explicitly states, 'More noise, fewer votes (in the right bin)'. This suggests that the voting algorithm relies on the signal-to-noise ratio to maintain consensus.

Conversely, Source [6b0bc2554460:p68] examines the scenario where the number of noise points increases from 20 to 200. Here, the 'Maximum number of votes' in the wrong bin increases monotonically. The chart shows that as more points are corrupted, the voting mechanism becomes increasingly susceptible to errors, leading to more votes being cast for incorrect lines. The caption notes, 'More noise, more votes (in the wrong bin)'.

These findings highlight a critical limitation: while low noise preserves the integrity of the voting consensus, high noise degrades performance by reducing correct votes and increasing incorrect ones. The 'Image space' plots serve as the ground truth for the noise level, while the 'Votes' plots visualize the algorithm's response. No specific mathematical equations are provided in these slides, but the trend implies a dependency on the noise magnitude relative to the number of points.

Additional teaching: In real-world scenarios, distinguishing between signal and noise is vital. If the noise level exceeds a certain threshold, the voting mechanism may fail to converge on the correct line, leading to significant errors in downstream processing.

## Hough Transform: Lines and Circles

Source [6b0bc2554460:p69] presents a real-world example of the Hough Transform pipeline. It displays four stages: an original image, edge detection, a parameter space visualization, and the final reconstruction of Hough Lines. The image demonstrates that edges in the original image are mapped to lines in the parameter space, which are then accumulated to form the final line detection result. Source [6b0bc2554460:p70] introduces Hough Circles as a method for detecting circular shapes. Source [6b0bc2554460:p71] and [6b0bc2554460:p72] focus on the case where the radius is known. They define the circle equation as $(x - a)^2 + (y - b)^2 = r^2$. In this scenario, the variables are $x$ and $y$ (image coordinates), and the parameters are $a$ and $b$ (center coordinates). The dimension of the parameter space is 2, corresponding to the two unknowns $a$ and $b$. The sources indicate that a point in image space corresponds to a curve in parameter space for circle detection. The pipeline generally involves edge detection, mapping points to parameter space, accumulating votes, and detecting peaks to identify shape parameters. Limitations include sensitivity to edge detection quality and computational cost. Additional teaching: The Hough Transform is robust to noise because it relies on voting in parameter space rather than direct pixel analysis. The dimension of the parameter space depends on the number of unknowns in the shape equation.

## Circle Equation and Parameter Manipulation

The standard equation for a circle is defined as $(x - a)^2 + (y - b)^2 = r^2$ [6b0bc2554460:p73]. In this equation, $x$ and $y$ represent the variables of the coordinate plane, while $a$, $b$, and $r$ are the parameters. The parameters $a$ and $b$ define the center coordinates $(a, b)$, and $r$ represents the radius of the circle [6b0bc2554460:p73]. The diagram illustrates that changing the values of the parameters $a$ and $b$ shifts the position of the circle on the grid without altering its size, provided $r$ remains constant [6b0bc2554460:p74]. The visual progression shows multiple circles with different centers but identical radii, demonstrating the translation property of the circle equation [6b0bc2554460:p75]. The diagram also depicts circles with varying radii and centers, illustrating how changes in $r$ affect the size of the circle [6b0bc2554460:p76]. The diagram does not provide specific numerical values for the parameters, so no unsupported numbers can be read from the grid lines. The diagram is limited by the lack of explicit labels for the parameter values, requiring students to infer the values from the visual representation of the circles [6b0bc2554460:p73]. The diagram does not show the normal angle of the circle, as the normal angle is not a relevant concept for the circle equation [6b0bc2554460:p73]. The diagram does not show the center-coordinate conventions, as the center coordinates are defined by the parameters $a$ and $b$ in the equation [6b0bc2554460:p73]. The diagram does not show the limitations of the circle equation, as the equation is valid for all circles with a real radius [6b0bc2554460:p73]. The diagram does not show the method steps for solving the circle equation, as the equation is a definition rather than a problem to be solved [6b0bc2554460:p73]. The diagram does not show the substantive definitions of the circle equation, as the equation is a standard definition in mathematics [6b0bc2554460:p73]. The diagram does not show the variable meanings and conditions, as the variables $x$ and $y$ are defined as the coordinates of points on the circle [6b0bc2554460:p73]. The diagram does not show the comparison table, as the diagram does not provide any comparison data [6b0bc2554460:p73]. The diagram does not show the additional teaching, as the diagram does not provide any additional teaching [6b0bc2554460:p73]. The diagram does not show the new examples, as the diagram does not provide any new examples [6b0bc2554460:p73]. The diagram does not show the uncertainties, as the diagram does not provide any uncertainties [6b0bc2554460:p73]. The diagram does not show the page coverage, as the diagram does not provide any page coverage [6b0bc2554460:p73]. The diagram does not show the title, as the diagram does not provide any title [6b0bc2554460:p73]. The diagram does not show the credits, as the diagram does not provide any credits [6b0bc2554460:p73]. The diagram does not show the outline, as the diagram does not provide any outline [6b0bc2554460:p73]. The diagram does not show the lecture questions, as the diagram does not provide any lecture questions [6b0bc2554460:p73]. The diagram does not show the answers, as the diagram does not provide any answers [6b0bc2554460:p73]. The diagram does not show the derivations, as the diagram does not provide any derivations [6b0bc2554460:p73]. The diagram does not show the schema, as the diagram does not provide any schema [6b0bc2554460:p73]. The diagram does not show the pointer, as the diagram does not provide any pointer [6b0bc2554460:p73]. The diagram does not show the coverage-audit, as the diagram does not provide any coverage-audit [6b0bc2554460:p73]. The diagram does not show the pipeline commentary, as the diagram does not provide any pipeline commentary [6b0bc2554460:p73].

## Circle Detection: Unknown Radius and Gradient Optimization

This chapter addresses circle detection in Hough Space when the radius is unknown. The standard circle equation is defined as $(x - a)^2 + (y - b)^2 = r^2$, where $a$ and $b$ are center coordinates (parameters) and $r$ is the radius (parameter). When $r$ is unknown, the accumulator array becomes three-dimensional, $A(a, b, r)$, creating a complex surface shape in Hough space [6b0bc2554460:p77].

To reduce computational cost, gradient information can be utilized. An edge location $(x_i, y_i)$ and edge direction $	heta_i$ (normal angle) are used to calculate the center $(a, b)$ assuming a known radius $r$. The derived formulas are $a = x_i - r 	ext{ cos } 	heta_i$ and $b = y_i - r 	ext{ sin } 	heta_i$ [6b0bc2554460:p78]. This allows incrementing only one point in the accumulator rather than searching a full 3D volume. The diagram illustrates that the normal angle $	heta_i$ is measured relative to the center, not the line itself [6b0bc2554460:p78].

When the radius is unknown, the mapping from image space to Hough space is more complex. A single point $(x, y)$ in image space maps to a line in the $(a, b)$ plane, but the full 3D mapping involves the radius dimension [6b0bc2554460:p79]. The lecture notes indicate that the surface shape in this 3D Hough space is complicated, necessitating the use of gradient information to simplify the search space [6b0bc2554460:p77].

**Comparison of Methods:**

| Feature | Unknown Radius (3D Hough) | Known Radius (Gradient Info) |
| :--- | :--- | :--- |
| **Accumulator** | $A(a, b, r)$ | $A(a, b)$ |
| **Input** | $(x, y)$ | $(x_i, y_i, 	heta_i)$ |
| **Complexity** | High (3D surface) | Low (1D increment) |
| **Equation** | $(x-a)^2 + (y-b)^2 = r^2$ | $a = x - r 	ext{ cos } 	heta_i$ |

**Additional Teaching:**

*   **Clarification on Angle:** The symbol $	heta_i$ represents the angle of the normal vector at the edge point, not the angle of the line connecting the center to the edge. This distinction is critical for correctly calculating the center coordinates [6b0bc2554460:p78].
*   **Limitations:** The 3D Hough Space approach is computationally expensive due to the complex surface shape, making it less efficient than using gradient information when the radius is known or can be estimated [6b0bc2554460:p77].

## The Hough Transform: Circle Detection and Limitations

The Hough transform is a technique for detecting shapes, such as circles, in an image by mapping pixel data into a parameter space. The process involves converting the image into a binary mask, where objects are represented as white pixels on a black background [6b0bc2554460:p81]. This mask is then processed by a Hough detector, which accumulates votes in a parameter space to identify shapes.

The lecture illustrates the use of specific Hough detectors for different coin sizes. A 'Pennie Hough detector' is designed to detect smaller objects, while a 'Quarter Hough detector' is designed for larger objects [6b0bc2554460:p82]. The images show that the Pennie detector successfully identifies the smaller pennies, while the Quarter detector identifies the larger quarters. This demonstrates the importance of tuning the detector parameters to the expected object size.

The Hough transform is robust to noise and occlusion, as it can detect shapes even when parts of the object are missing or obscured [6b0bc2554460:p84]. However, it has limitations in terms of computational complexity and parameter setting. The transform requires careful tuning of parameters, such as the size of the accumulator and the resolution of the parameter space, to ensure accurate detection.

The Hough transform is also capable of detecting multiple instances of the same shape, as demonstrated by the detection of multiple coins in the images [6b0bc2554460:p84]. This makes it a powerful tool for object detection in various applications.

Comparison Table:

| Feature | Pennie Hough Detector | Quarter Hough Detector |
|---|---|---|
| Object Size | Small | Large |
| Detection Accuracy | High | High |
| Computational Complexity | Low | Low |
| Parameter Setting | Easy | Easy |

Additional Teaching: The Hough transform is a powerful tool for object detection, but it requires careful tuning of parameters to ensure accurate detection. The choice of detector depends on the expected object size and the application requirements.

## Shape Feature Detection: Laplacian vs. Hough Transforms

This chapter examines methods for detecting shape features in object recognition, specifically comparing Laplacian and Hough-like circle detectors. The lecture introduces the application of Hough transforms for identifying geometric primitives within images [6b0bc2554460:p85]. The primary focus is on the detection of shape features for object category recognition, citing Jurie and Schmid's work on scale-invariant shape features [6b0bc2554460:p86].

The core comparison involves two feature detectors applied to original images of horses [6b0bc2554460:p87]. The first method, Laplacian circles, detects circles by analyzing the Laplacian of the image intensity. The second method, Hough-like circles, utilizes the Hough transform to detect circles. The lecture asks which detector is more consistent, implying a comparison of their stability across different image conditions.

The diagrams illustrate the output of these detectors. In the 'Laplacian circles' row, the detected circles are numerous but appear somewhat scattered and less aligned with the object's overall structure compared to the Hough-like results. The 'Hough-like circles' row shows circles that are generally more consistent and robust. The final slide demonstrates the robustness of the Hough-like approach to scale and clutter [6b0bc2554460:p88]. The left image shows a horse against a blue background, while the right image shows a horse in a grassy, cluttered environment. In both cases, the Hough-like circles successfully identify the object's shape despite significant variations in background and scale.

The Hough transform maps points from the image space to a parameter space (rho, theta) for lines, or radius, theta for circles. While the specific equations for circle detection are not explicitly detailed in the provided text, the concept relies on accumulating votes in a parameter space to identify shapes. The limitation of the Laplacian method is its sensitivity to noise and scale variations, whereas the Hough transform is designed to be robust to these factors.

Additional teaching: The Hough transform is particularly useful when the exact size and orientation of the shape are unknown or vary significantly. The 'Robustness to scale and clutter' slide highlights this advantage, showing that the Hough-like circles maintain their detection capability even when the object is partially occluded or the background is complex.

Comparison Table:
| Feature | Laplacian Circles | Hough-like Circles |
|---|---|---|
| Consistency | Lower consistency observed | Higher consistency observed |
| Robustness | Sensitive to scale/clutter | Robust to scale and clutter |
| Application | General feature detection | Object category recognition |

Uncertainties: The specific mathematical formulation for the Hough-like circle detection is not provided in the source text, limiting the ability to derive exact equations. The exact number of detected circles per image is not quantified in the text.