# MLOps_Lecture01-1stOct2026 (3).pptx

## Lecture 01: From Software Development to DevOps

This lecture establishes the software-engineering foundation required before discussing ML systems, model serving, and LLMOps. The core question addresses the gap between writing code and delivering a real software product. The course narrative follows the progression: SDLC → Waterfall → Agile → Dev/Ops gap → DevOps foundations.

**Substantive Definitions and Concepts**
A program becomes a product only when it satisfies user needs, can be delivered, operated, and improved [337180aaee19:p2]. The common beginner view—that code running on a machine is finished—is incorrect because it ignores users, requirements, testing, deployment environments, and operational responsibilities [337180aaee19:p2].

A software product includes multiple engineered concerns:
1. **User need**: What real problem should the system solve?
2. **Requirements**: What functions and constraints must be satisfied?
3. **Architecture & design**: How will components, data, and interfaces be organized?
4. **Testing & verification**: How do we know the system behaves correctly?
5. **Deployment & environment**: Where and how will users access the software?
6. **Operation & maintenance**: How is the system monitored, fixed, and evolved?

**Method Steps: SDLC**
The Software Development Life Cycle (SDLC) is a structured framework for planning, building, testing, delivering, and maintaining software [337180aaee19:p4]. It identifies major responsibilities but does not mandate a strict sequence. The formal steps are:
1. **Requirements / Analysis**: Clarify problem, users, functional needs, and constraints.
2. **Design**: Define architecture, data, interfaces, and solution structure.
3. **Development**: Implement the system and integrate components.
4. **Testing**: Evaluate whether software satisfies expectations and requirements.
5. **Deployment**: Release the system so intended users can access it.
6. **Maintenance**: Fix defects, support users, and evolve the system over time.

**Diagram Meaning and Limitations**
The diagram in [337180aaee19:p1] illustrates the flow from IDEA to CODE to USER. The text explicitly states that between code and a real software product, there are disciplined engineering activities: requirements, design, verification, delivery, operation, and improvement [337180aaee19:p1]. The UniTasks example in [337180aaee19:p3] is intentionally simple to focus on process rather than domain complexity.

**Comparison Table: SDLC vs. Process Models**
| Feature | SDLC | Waterfall / Agile |
| :--- | :--- | :--- |
| **Definition** | Describes what must be handled (activities) | Describes how activities are organized over time |
| **Scope** | Planning, building, testing, delivering, maintaining | Organizational flow of the above activities |

**Additional Teaching**
Most project failures are not caused by bad syntax; they often arise from unclear requirements, weak testing, poor deployment preparation, missing operational ownership, or uncontrolled change [337180aaee19:p4].

**Uncertainties**
No specific numerical values or equations are provided in the supplied sources.


## Software Development Life Cycle (SDLC) and Process Models

The Software Development Life Cycle (SDLC) defines the essential responsibilities of professional software work: understanding the need, designing the solution, implementing it, verifying it, delivering it, and maintaining it [337180aaee19:p6]. These responsibilities are organized into phases, each answering a specific central question and producing a typical artifact [337180aaee19:p5].

The SDLC phases are defined as follows:
1. Requirements: Answers 'What should the software do, for whom, and under which constraints?' and produces artifacts like requirements lists and use cases [337180aaee19:p5].
2. Design: Answers 'How should the solution be organized before implementation begins?' and produces architecture sketches and database schemas [337180aaee19:p5].
3. Development: Answers 'How will the design be implemented and integrated?' and produces source code and configuration [337180aaee19:p5].
4. Testing: Answers 'How do we know the implemented system behaves correctly?' and produces test cases and defect reports [337180aaee19:p5].
5. Deployment: Answers 'How will users access the working system in a controlled environment?' and produces release packages [337180aaee19:p5].
6. Maintenance: Answers 'How will the software be corrected, supported and improved after release?' and produces bug fixes and change requests [337180aaee19:p5].

Process models answer 'How is work organized?' by defining sequencing, iteration, and delivery rhythm [337180aaee19:p6]. Three primary models organize these concerns:
- Waterfall: A sequential process model where the output of phase n becomes the input of phase n+1 [337180aaee19:p7]. It assumes major requirements are understood before implementation begins and relies on early clarity and disciplined documentation [337180aaee19:p7].
- Iterative/Agile: Organizes work into repeated short cycles, best when learning and changing priorities are expected [337180aaee19:p6].
- DevOps: Extends the delivery loop into deployment, operation, and monitoring, best when frequent releases require automation [337180aaee19:p6].

The Waterfall model is artifact-driven, meaning each phase must clarify, document, or validate something before the next phase relies on it [337180aaee19:p8]. For example, the Requirements phase produces a Requirements Document, which guides the Design phase [337180aaee19:p8].

Comparison of Process Models:
| Model | Organization | Best Used When |
|---|---|---|
| Waterfall | Sequential phases [337180aaee19:p6] | Requirements are stable and documentation/control are central [337180aaee19:p6]. |
| Agile | Repeated short cycles [337180aaee19:p6] | Learning, feedback, and changing priorities are expected [337180aaee19:p6]. |
| DevOps | Continuous delivery and operation [337180aaee19:p6] | Frequent releases require automation, monitoring, and shared responsibility [337180aaee19:p6]. |

Core idea: Waterfall and Agile are not different 'phase lists'; they are different strategies for managing feedback, uncertainty, and delivery [337180aaee19:p6]. Waterfall becomes risky when the problem is not yet well understood or when feedback arrives late [337180aaee19:p7].

## Waterfall vs. Agile: Process Models for Development

The Waterfall model is a planned approach suited for domains with well-understood requirements and stable specifications [337180aaee19:p9]. It provides clear milestones, strong documentation, and predictable planning, making it useful for stable systems where formal approval is required before phase transitions [337180aaee19:p9]. The educational value lies in making lifecycle responsibilities visible, separating requirements, design, implementation, and maintenance [337180aaee19:p9].

The primary risk in Waterfall is late feedback. If a requirement change occurs after implementation has started, the cost of revision propagates through the system [337180aaee19:p10]. A change in requirements (e.g., from personal to collaborative tasks) forces changes in design, code, tests, and deployment [337180aaee19:p10]. This motivates iterative approaches.

Agile approaches respond to uncertainty by delivering smaller increments and learning from frequent feedback [337180aaee19:p11]. The core shift moves from planning a large portion of work early to working in short cycles with frequent stakeholder involvement [337180aaee19:p11]. Agile does not eliminate planning or testing; it changes their rhythm, repeating these activities in smaller cycles [337180aaee19:p11].

Agile values prioritize individuals and interactions over processes and tools, working software over comprehensive documentation, customer collaboration over contract negotiation, and responding to change over following a plan [337180aaee19:p12]. The word 'over' indicates higher priority during trade-offs, not that the right-side items are worthless [337180aaee19:p12].

Comparison Table:

| Feature | Waterfall [337180aaee19:p9] | Agile [337180aaee19:p11] |
| :--- | :--- | :--- |
| Planning | Large portion planned early | Short cycles, adapt plans |
| Feedback | Major feedback late | Frequent feedback |
| Documentation | Explicitly recorded | Working software prioritized |
| Change Handling | Expensive if late | Adapt to change |
| Best For | Stable systems, formal approval | Uncertain requirements |

Additional Teaching: The diagram in [337180aaee19:p11] illustrates the Agile rhythm: Plan -> Design -> Build -> Test -> Review -> Improve, repeated in short cycles. This contrasts with the sequential flow of Waterfall.

## From Agile to DevOps: Bridging Development and Operations

This chapter defines the progression from Agile development to DevOps operations, focusing on how teams manage software delivery and reliability.

**Agile Methodology**
Agile applies to software by releasing useful increments rather than waiting for a complete system [337180aaee19:p13]. The process follows an iterative cycle where feedback adapts the next increment. For example, Iteration 1 focuses on a basic task list, while Iteration 2 adds due dates and priority levels [337180aaee19:p13]. The core risk profile change is that misunderstandings are discovered while the product is still small enough to change [337180aaee19:p13].

**The Delivery/Operation Gap**
While Agile improves the development loop by closing the feedback gap between stakeholders and developers [337180aaee19:p14], it does not fully solve the delivery/operation gap. As illustrated in the diagram, a 'wall' separates Development from Operations [337180aaee19:p14]. Typical symptoms before DevOps include manual release steps, late delivery to operations, and monitoring added only after problems occur [337180aaee19:p14].

**Why DevOps is Necessary**
Frequent change creates delivery pressure; if a team delivers increments every one or two weeks, manual deployment becomes a bottleneck [337180aaee19:p15]. The question shifts from code changes to how to move to reliable running software repeatedly, safely, and with feedback from operation [337180aaee19:p15].

**Defining DevOps**
DevOps is defined academically as a culture and set of engineering practices integrating development and IT operations [337180aaee19:p16]. It is not a single tool like Docker or Jenkins, but a way of organizing delivery and operation [337180aaee19:p16]. The definition relies on three pillars: Culture (shared responsibility), Practices (repeatable ways of working), and Tools (technology supporting practices) [337180aaee19:p16].

**Comparison Table**

| Feature | Agile | DevOps |
| :--- | :--- | :--- |
| **Primary Focus** | Development feedback and increment quality [337180aaee19:p13] | Reliable delivery and operation [337180aaee19:p14] |
| **Gap Addressed** | Feedback gap between stakeholders and developers [337180aaee19:p14] | Delivery/operation gap between Development and Operations [337180aaee19:p14] |
| **Outcome** | Builds the right increment [337180aaee19:p14] | Delivers and operates increments reliably [337180aaee19:p14] |

**Additional Teaching**
The lecture outlines a progression: Code -> SDLC -> Waterfall -> Agile -> DevOps separation [337180aaee19:p15]. DevOps addresses the remaining separation by linking development, delivery, operation, and monitoring [337180aaee19:p14].

## DevOps Foundations: Tension, Principles, and Lifecycle

DevOps emerged to resolve the historical conflict between Development and Operations. Development optimizes for speed and change, while Operations optimizes for stability and reliability [337180aaee19:p17]. DevOps does not eliminate these goals but makes change safer and stability compatible with continuous delivery.

The core framework is CALMS: Culture, Automation, Lean, Measurement, and Sharing [337180aaee19:p18]. Culture ensures shared responsibility rather than handoffs. Automation improves repeatability by scripting error-prone tasks. Lean reduces waste via small batches. Measurement provides evidence from builds and incidents. Sharing ensures visibility of knowledge and logs.

The DevOps Lifecycle connects development and operations in a continuous loop [337180aaee19:p19]. The Development side includes Plan, Code, Build, and Test. The Operation side includes Deploy, Operate, and Monitor. The loop matters: monitoring and operational feedback influence the next plan, making delivery a continuous improvement process.

Lab 01 establishes three practical foundations: Environment, Git, and Docker [337180aaee19:p20]. Environment ensures reproducibility by reducing hidden differences between machines. Git ensures traceability by recording project changes and code decisions. Docker ensures portability by packaging applications with runtime dependencies. The conceptual flow is: Local project folder → Git repository → dependency specification → Docker image → repeatable container run.

Additional teaching: The distinction between Development (change) and Operations (stability) is the primary tension. The CALMS framework explains why tools like Git and Docker are useful; they are practical expressions of the principles, not substitutes. The lifecycle loop ensures that operational feedback drives future planning.

## DevOps Artifacts, Reproducibility, and Containerization

This chapter defines the concrete artifacts required to operationalize DevOps principles. A practical workflow produces artifacts that allow understanding, rebuilding, and operating software systems [337180aaee19:p21]. These artifacts map specific concerns to tangible deliverables. For instance, the 'Need and plan' concern is addressed by an issue or user story, answering 'What change are we making and why?' [337180aaee19:p21]. 'Source control' utilizes Git repositories and commits to track which files changed, when, by whom, and for what reason [337180aaee19:p21]. 'Environment definition' requires a README, requirements file, or Dockerfile to specify what must exist to run the project correctly [337180aaee19:p21]. 'Verification' relies on tests, logs, and build results to confirm the current version still works [337180aaee19:p21]. Finally, 'Delivery package' provides a container image or executable package to define the exact version deliverable [337180aaee19:p21].

Reproducibility is defined as a state where required runtime, dependencies, configuration, and execution steps are explicit [337180aaee19:p22]. Without this, hidden environment differences cause failure. For example, Developer A might use Python 3.11 with Package X = 2.0, while Developer B uses Python 3.9 with Package X = 1.4 and a missing config variable. This results in the same source code producing different behavior or failure [337180aaee19:p22]. To ensure reproducibility, one must specify: (1) Runtime (e.g., Python, Node.js, Java), (2) Dependencies (external packages and compatible versions), (3) Configuration (environment variables, ports, local settings), (4) Execution steps (install, run, test, stop), and (5) Data assumptions (sample data location and schema) [337180aaee19:p22].

Version control with Git acts as the project memory, recording changes over time to allow reconstruction of earlier states [337180aaee19:p23]. Each commit is a meaningful snapshot plus an explanation of the change. The system supports four key functions: Traceability (What changed and why?), Recovery (Can we return to a working version?), Collaboration (Can multiple people work safely?), and Experimentation (Can we try an idea without losing the stable version?) [337180aaee19:p23].

Containerization with Docker packages application code with dependencies and runtime assumptions to execute consistently [337180aaee19:p24]. The problem is that the same program may behave differently when the surrounding execution context changes due to unknown machine state versions, libraries, and settings [337180aaee19:p24]. The solution involves packaging: Application code (source files and entry point), Runtime (Python/Node/Java version), Dependencies (libraries and system packages), and Settings (ports, commands, configuration) [337180aaee19:p24]. The pipeline is defined as Dockerfile -> Image -> Running container, where the Dockerfile describes how to build the package, the image is the packaged artifact, and the container is a running instance [337180aaee19:p24].

Additional teaching: The distinction between an Image and a Container is critical. The Image is the static, packaged artifact built from the Dockerfile. The Container is the dynamic, running instance of that image [337180aaee19:p24].

Comparison Table: Source Alternatives
| Concern | Artifact Type | Question Answered |
| :--- | :--- | :--- |
| Need and plan | Issue / User Story | What change are we making and why? |
| Source control | Git Repo & Commits | Which files changed, when, by whom? |
| Environment | README / Dockerfile | What must exist to run correctly? |
| Verification | Tests / Logs | How do we know it still works? |
| Delivery | Container Image | What exact version is delivered? |
| Feedback | Runtime Logs | What happened after use? |

Uncertainties: None identified in supplied sources.

## Lecture 01 Synthesis: Software Delivery Foundations and Bridge to MLOps

This lecture establishes that working code is insufficient for a complete software product, which requires process, collaboration, and operational feedback [337180aaee19:p25]. The conceptual chain progresses from 'Code is not enough' through SDLC responsibilities, Waterfall planning limitations, Agile feedback, DevOps delivery loops, and finally local reproducibility [337180aaee19:p25].

A modern AI application is not 'just a model'; it is a software product wrapping the model with interfaces, dependencies, data access, evaluation, security, and monitoring [337180aaee19:p26]. The system architecture includes Source code, Model/LLM, Data/Knowledge, Environment, and Users & feedback [337180aaee19:p26]. DevOps asks how to deliver software reliably, while MLOps extends this to systems where behavior depends on data, models, prompts, and evaluation [337180aaee19:p26].

To ensure reproducibility, a 'development environment' must be standardized. Components include Toolchain (e.g., Python/Node/Java), Project structure, Dependencies, Configuration, and Execution command [337180aaee19:p27]. The Lab 01 objective requires students to clone the project, install dependencies, run commands, track changes with Git, and containerize the application [337180aaee19:p27].

Virtual Machines (VMs) and Containers offer different abstractions. A VM view includes Application, Libraries/runtime, Guest OS, Hypervisor, Host OS, and Hardware; it virtualizes a full machine [337180aaee19:p28]. A Container view includes Application, Libraries/runtime, Container engine, Host OS, and Hardware; it packages dependencies while sharing the host OS kernel [337180aaee19:p28]. VM isolation is machine-level, whereas container isolation is application/process-level packaging [337180aaee19:p28].

Additional teaching: The bridge to MLOps emphasizes that while DevOps handles the software delivery loop, MLOps must account for the volatility of data and models within that loop [337180aaee19:p26].

## MLOps Foundations: Local DevOps Workflow and Artifact Governance

This chapter defines the foundational workflow for local software delivery and extends it to machine learning contexts. The primary goal is establishing a repeatable local workflow before scaling to cloud deployment [337180aaee19:p29].

**The Minimal Local DevOps Loop**
The workflow consists of eight sequential steps designed to express traceability, automation, repeatability, verification, and feedback [337180aaee19:p29].
1. **Plan**: Define a small change or bug fix.
2. **Code**: Edit source files.
3. **Commit**: Record version in Git.
4. **Build**: Prepare executable or package.
5. **Test**: Check expected behavior.
6. **Containerize**: Package environment.
7. **Run**: Execute repeatably.
8. **Observe**: Collect feedback.

Feedback returns to planning, creating a closed loop [337180aaee19:p29]. This loop is deliberately local, though principles scale to CI/CD and LLMOps pipelines [337180aaee19:p29].

**Core Concepts**
Students must distinguish between code and product, understanding that source code is not a complete software product [337180aaee19:p30]. Key concepts include SDLC responsibilities, the cost of late feedback in Waterfall, and how Agile changes delivery via iteration [337180aaee19:p30]. DevOps solves deployment and operations problems that Agile alone does not address [337180aaee19:p30]. Reproducibility relies on Git for versioning and Docker for environment packaging [337180aaee19:p30].

**From DevOps to MLOps**
MLOps extends the disciplined delivery mindset of DevOps to systems where behavior depends on data and models [337180aaee19:p31].

*Traditional Software Delivery* focuses on versioning code, automatic build/test, packaging, reliable deployment, and monitoring [337180aaee19:p31].

*Machine-Learning System Delivery* adds complexity: changing artifacts include code, data, configuration, and model parameters [337180aaee19:p31]. Additional concerns include tracking experiments, validating data quality, deploying model versions safely, monitoring drift, and retraining [337180aaee19:p31].

**Artifact Governance**
In DevOps, teams control source code, dependencies, configuration, and container images [337180aaee19:p32]. In MLOps, teams must also control dataset versions, feature definitions, experiment records, and model artifacts [337180aaee19:p32]. MLOps does not discard DevOps; it adds governance for data, experiments, and model outputs [337180aaee19:p32].

**Additional Teaching**
*Example*: In a local workflow, if the 'Build' step fails, the 'Test' step is skipped, breaking the repeatability loop. This highlights why 'Containerize' (step 6) is critical to ensure the 'Run' step executes repeatably regardless of local environment variations [337180aaee19:p29].

**Comparison Table: DevOps vs. MLOps Artifacts**

| Artifact Type | DevOps Scope | MLOps Scope | Source |
| :--- | :--- | :--- | :--- |
| **Code** | Source code, tests, scripts | Source code, tests, scripts | [337180aaee19:p32] |
| **Environment** | Dependencies, Configuration, Container image | Dependencies, Configuration, Container image | [337180aaee19:p32] |
| **Data** | N/A | Dataset version, Feature definition | [337180aaee19:p32] |
| **Model** | N/A | Experiment record, Model artifact | [337180aaee19:p32] |

**Uncertainties**
No unsupported numerical values were extracted from the diagrams. The distinction between 'Code' and 'Product' is conceptual rather than mathematical [337180aaee19:p30].

## Lecture 01 Synthesis: From Software Lifecycle to Reliable Delivery

This chapter summarizes the progression from the software lifecycle to reliable delivery, emphasizing that DevOps is an engineering response to delivery problems rather than a toolset [337180aaee19:p35].

**Conceptual Progression**
The lecture outlines a six-step progression:
1. Code alone is insufficient [337180aaee19:p35].
2. Software has a lifecycle [337180aaee19:p35].
3. Waterfall organizes work sequentially [337180aaee19:p35].
4. Agile adds iteration and feedback [337180aaee19:p35].
5. DevOps closes the development–operations gap [337180aaee19:p35].
6. Git and Docker support repeatability [337180aaee19:p35].

**Engineering Problems and Tools**
Each tool in Lab 01 addresses a specific problem:
- **Environment setup**: Addresses machine-specific settings; software execution requires controlled runtime assumptions [337180aaee19:p33].
- **Git/GitHub**: Addresses the need for traceability and recovery; project history should be inspectable, reversible, and shareable [337180aaee19:p33].
- **Docker**: Addresses the need for reliable execution elsewhere; packaging code with dependencies reduces environment mismatch [337180aaee19:p33].
- **README + commands**: Addresses the need for repeatable steps; the process must be documented so another person can reproduce it [337180aaee19:p33].

**Study Materials**
Recommended readings include OpenStax SDLC, Agile Manifesto, Pro Git, and Docker container overview [337180aaee19:p34]. Students should explain concepts using UniTasks, not merely repeat definitions [337180aaee19:p34].

**Concept Check**
- **Q1**: Source code alone is insufficient because a product requires requirements, design, tests, environment assumptions, deployment procedures, operation, and maintenance [337180aaee19:p36].
- **Q2**: The SDLC organizes engineering activities to transform needs into a working, delivered, and maintained system [337180aaee19:p36].
- **Q3**: Agile became important because it responds better to changing requirements using shorter iterations, feedback, and working software increments [337180aaee19:p36].
- **Q4**: Even after Agile improves development, software must still move reliably from development to operations, requiring collaboration, automation, and feedback [337180aaee19:p36].

**Additional Teaching**
DevOps is introduced as an engineering response to a delivery problem: teams need a reliable way to move from change to tested, packaged, operated, and monitored software [337180aaee19:p35]. The lab is not "Git commands + Docker commands"; it is the first concrete practice of disciplined, reproducible software engineering [337180aaee19:p33].

## Lecture 01: Foundations of Reproducible Software Delivery

This chapter summarizes the key concepts and preparation steps for Lab 01, focusing on the transition from high-level lifecycle concepts to the practical foundations of DevOps.

**Substantive Definitions and Concepts**
Students must understand that a **Software product** is a delivered system including source code, requirements, design, tests, and maintenance responsibilities [337180aaee19:p37]. The **SDLC** organizes activities like requirements analysis and testing across a system's life [337180aaee19:p37]. The **Waterfall model** arranges activities sequentially, managing stable projects but struggling with late changes [337180aaee19:p37]. **Agile development** emphasizes working software and frequent feedback [337180aaee19:p37]. **DevOps** connects development and operations via automation and feedback [337180aaee19:p37]. **Reproducibility** is the ability to recreate results using controlled code and environments; a common failure mode is "it works on my machine" [337180aaee19:p37].

**Method Steps for Lab 01**
1. **Understand the purpose**: Recognize Git as a history/collaboration mechanism and Docker as an environment packaging mechanism [337180aaee19:p38].
2. **Prepare the machine**: Ensure a working laptop, installed code editor, terminal, and Git/Docker [337180aaee19:p38].
3. **Produce evidence**: Submit screenshots, a Git repository with a meaningful commit, a README, and a Dockerfile [337180aaee19:p38].

**Lecture Progression**
Lecture 02 will introduce technical building blocks: Environment management (runtime assumptions), Git workflow (collaboration), Docker fundamentals (portable units), and Automation mindset (CI/CD) [337180aaee19:p39].

**Core Takeaway**
A professional software system is not finished when code runs locally; it must be specified, designed, implemented, tested, packaged, delivered, operated, monitored, and improved [337180aaee19:p40].

**Comparison Table: Source Alternatives**
| Concept | Waterfall Model | Agile Development | DevOps |
| :--- | :--- | :--- | :--- |
| Approach | Plan-driven, sequential | Iterative, collaborative | Culture of collaboration/automation |
| Change Handling | Harder to respond to late changes | Emphasizes adaptation to change | Focuses on reliable delivery |
| Scope | Lifecycle activities | Working software focus | Connects Dev and Ops |

**Additional Teaching**
The lab design principle states every command executed should attach to a concept from Lecture 01 [337180aaee19:p38]. Git solves traceability and recovery; Docker solves environment packaging [337180aaee19:p38].

**Uncertainties**
None identified in supplied sources.