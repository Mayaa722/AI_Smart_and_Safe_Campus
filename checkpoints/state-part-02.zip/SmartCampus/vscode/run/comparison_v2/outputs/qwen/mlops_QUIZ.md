# MLOps_Lecture01-1stOct2026 (3).pptx quiz - automated review draft

1. In the context of the Waterfall model, what is the primary reason why late changes to requirements become expensive?

A. Because the team must wait for the next semester to address new user needs.
B. Because earlier decisions require rework, and the output of one phase becomes the input for the next.
C. Because the software is already deployed and cannot be modified without a full system restart.
D. Because the documentation is too detailed to allow for any modifications after the design phase.

Key: B. The Waterfall model relies on sequential logic where the output of phase n becomes the input of phase n+1. This structure means that if requirements are misunderstood or change late, earlier work must be revised, making late changes expensive.

2. What is the fundamental distinction between SDLC activities and process models like Waterfall or Agile?

A. SDLC activities describe how work is organized, while process models describe what responsibilities must be addressed.
B. SDLC activities describe what must be handled, while process models describe how these activities are organized over time.
C. SDLC activities are only used for maintenance, while process models cover the entire development lifecycle.
D. SDLC activities are specific to Waterfall, while process models are generic frameworks for all software projects.

Key: B. The lecture explicitly states that SDLC activities describe what must be handled (the responsibilities), whereas process models such as Waterfall and Agile describe how these activities are organized over time (sequencing, iteration, rhythm).

3. According to the lecture, what is the primary reason that DevOps became necessary after the adoption of Agile practices?

A. Agile eliminated the need for manual deployment steps entirely.
B. Agile created a delivery pressure where frequent increments made manual deployment and weak coordination bottlenecks.
C. Agile removed the distinction between development and operations teams.
D. Agile focused exclusively on the operational side of software delivery.

Key: B. The lecture states that while Agile improves the development loop, it creates a new delivery pressure. If a team delivers new increments frequently (e.g., every one or two weeks), manual deployment and weak operational coordination become bottlenecks, necessitating DevOps to move from code changes to reliable running software.

4. What is the fundamental tension between the Development and Operations perspectives that DevOps aims to resolve?

A. Development focuses on stability while Operations focuses on rapid change.
B. Development prioritizes change and speed, while Operations prioritizes stability and system availability.
C. Development prefers predictable releases, while Operations prefers frequent, uncontrolled changes.
D. Development and Operations have identical goals regarding uptime and feature velocity.

Key: B. The lecture explicitly defines the Development perspective as having a main pressure for 'change' (delivering features quickly, experimenting), while the Operations perspective has a main pressure for 'stability' (keeping systems available, avoiding unexpected failures). DevOps does not eliminate these goals but makes them compatible.

5. According to the lecture, what is the primary reason that a container is necessary when using Docker, and what specific components does it package to ensure consistent execution?

A. To isolate the application from the host OS kernel by virtualizing a full guest operating system, including the hypervisor.
B. To package the application code along with dependencies, runtime versions, and settings so the execution context remains consistent.
C. To replace the need for version control by storing the entire project history and file changes within a single executable package.
D. To automatically solve deployment and operations problems by removing the need for manual configuration of environment variables and ports.

Key: B. The lecture states that a container packages application code with dependencies and runtime assumptions needed to execute it consistently, addressing the problem where the same program behaves differently when the surrounding execution context changes. It explicitly lists Runtime, Dependencies, and Settings as components packaged in the solution.

6. In the context of local development environments, which component is defined as the collection of tools, versions, folders, variables, and services required to build and run a project?

A. The Toolchain, which includes the compiler or runtime but excludes configuration files.
B. The Project Structure, which refers only to the folders and source files used for collaboration.
C. The Development Environment, which is the collection of tools, versions, folders, variables, and services required to build and run the project.
D. The Execution Command, which is the specific sequence of steps to install, test, and stop the system.

Key: C. Source [337180aaee19:p27] explicitly defines a 'development environment' as 'the collection of tools, versions, folders, variables and services required to build and run the project.' The other options represent specific components within this environment but do not define the entire collection.

7. According to the lecture synthesis, what is the primary engineering problem that DevOps is introduced to solve?

A. To replace the need for manual testing phases in the software development lifecycle.
B. To provide a reliable way to move software from change to tested, packaged, operated, and monitored states.
C. To automate the compilation of source code into executable binaries without human intervention.
D. To ensure that all software projects follow a sequential Waterfall model for maximum stability.

Key: B. The lecture explicitly states that DevOps is an engineering response to a delivery problem where teams need a reliable way to move from change to tested, packaged, operated, and monitored software.

8. In the progression of software delivery concepts, what specific gap does the adoption of Agile development address compared to sequential models?

A. It eliminates the need for any formal design or requirements analysis phases.
B. It closes the gap between development and operations by integrating feedback loops.
C. It replaces the need for version control systems to manage code history.
D. It ensures that all software can be deployed to production without any testing.

Key: B. The conceptual progression identifies that Agile adds iteration and feedback, while DevOps closes the development-operations gap. The checkpoint confirms Agile responds better to changing requirements through shorter iterations and feedback.

