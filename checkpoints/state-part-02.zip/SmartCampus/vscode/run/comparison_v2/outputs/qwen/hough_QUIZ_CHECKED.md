# AIS412 - Topic 2 - Hough Transform.pdf - checked quiz draft

Automated review: passed_automated_review. Instructor review remains separate.

1. In the context of defining object boundaries, what does the lecture indicate about the relationship between raw edge strength and human perception?

A. Raw edge strength always perfectly aligns with human perception of boundaries.
B. Raw edge strength does not necessarily correspond to our perception of boundaries.
C. Raw edge strength is the primary factor used by humans to define object boundaries.
D. Raw edge strength is irrelevant to the task of finding object boundaries.

Key: B. The lecture explicitly states that edge strength does not necessarily correspond to our perception of boundaries, highlighting a discrepancy between automated edge detection metrics and human annotation.

2. When comparing automated edge detection results to human annotations, what distinction is made regarding the identification of object boundaries?

A. Automated edge detection consistently produces cleaner, more accurate boundaries than human annotations.
B. Human annotations and automated edge detection are identical in their identification of object boundaries.
C. Automated edge detection may identify different boundaries than those annotated by humans.
D. Human annotations are impossible to perform on images containing texture.

Key: C. The lecture presents separate visualizations for 'Human annotated boundaries' and 'Edge detection', implying that these methods yield different results when identifying where object boundaries are located.

3. According to the lecture progression, what geometric shape do two distinct points in image space transform into within parameter space?

A. A single point
B. A line
C. Two intersecting lines
D. A filled region

Key: B. The lecture explicitly states that a single point in image space becomes a line in parameter space. Conversely, the progression shows that two points in image space become a line in parameter space, as demonstrated by the transformation of the two points (1,1) and (3,3) into a single line segment in the parameter space plot.

4. According to the lecture sequence, how do the points in the image space transform into the parameter space?

A. Each point in the image space corresponds to a single point in the parameter space.
B. Each point in the image space corresponds to a line in the parameter space, and multiple points result in multiple intersecting lines.
C. All points in the image space collapse into a single point in the parameter space.
D. Points in the image space do not transform into lines in the parameter space.

Key: B. The lecture demonstrates that a single point in image space (e.g., (1,1), (3,3), or (-2,-2)) corresponds to a line in parameter space (e.g., the red, green, or blue lines). When multiple points are added, they each generate a distinct line in parameter space, which intersect at a single point (the solution to the system). This is explicitly shown in sources [6b0bc2554460:p34] and [6b0bc2554460:p35].

5. In the lecture's parameter space visualization, what geometric shape do two distinct points in image space transform into?

A. A single point
B. A line segment
C. A closed loop
D. A scattered set of points

Key: B. The lecture explicitly states that 'two points become ?' and shows a transition from two distinct points in image space to a line segment in parameter space, contrasting this with the single point formed by one line.

6. According to the lecture, how does the representation of a single line in image space differ between the positive rho and negative rho versions in parameter space?

A. They form two different curves that do not intersect
B. They represent the same line but appear as different curves in parameter space
C. They both collapse into a single point in parameter space
D. The negative rho version is invalid and does not exist

Key: B. The lecture notes that there are two ways to write the same line (positive and negative rho versions) and shows that while they describe the same line in image space, they map to different curves in parameter space, illustrating the redundancy of the representation.

7. When the radius of a circle is unknown, how does the lecture describe the resulting parameter space compared to when the radius is known?

A. The parameter space remains 2D in both cases, but the accumulator array is larger when the radius is unknown.
B. The parameter space becomes 3D when the radius is unknown, whereas it is 2D when the radius is known.
C. The parameter space becomes 1D when the radius is unknown because the center coordinates are fixed.
D. The parameter space is undefined when the radius is unknown, requiring a different transform entirely.

Key: B. The lecture explicitly states that if the radius is not known, a '3D Hough Space' is used, whereas the context of known radius implies a 2D space defined by center coordinates (a, b).

8. How does using gradient information (edge direction) simplify the computation in the Hough accumulator when the radius is assumed to be known?

A. It requires incrementing multiple points in the accumulator to account for edge uncertainty.
B. It allows the system to ignore the radius parameter entirely, reducing the search space.
C. It enables incrementing only one point in the accumulator by calculating the center directly from the edge location and direction.
D. It increases the number of votes required to detect a circle, making the process slower.

Key: C. The lecture states that with gradient information and assuming the radius is known, one can calculate the center (a, b) and 'Need to increment only one point in accumulator!'

