# Full-lecture study materials

AIS412 - Topic 2 - Hough Transform.pdf

Processing coverage: 88/88 pages. This is not an accuracy score.

Page notes and transcriptions are Gemini-generated drafts; original page images remain authoritative.

## Assistant source and note clarifications

Original slides and generated records are preserved. Read these distinctions alongside the original notes.

### Double-intercept derivation: printed sign typo

The original slide prints ya + yx - ba + bx = -yx. Expanding (y-b)(a-x) = -xy instead gives ay - xy - ab + bx = -xy. Cancelling -xy yields ay + bx = ab and therefore x/a + y/b = 1 (when a and b are nonzero). The final intercept equation is correct; the intermediate printed plus sign is a source typo, not a valid algebra step.
Sources: 6b0bc2554460:p25

### Signed rho versus geometric distance

In a signed-rho convention, rho may be negative; the nonnegative perpendicular distance is abs(rho). The sign depends on the chosen oriented normal. Keep the theta range and rho convention consistent: a half-turn theta range pairs with signed rho, while a full-turn range can use nonnegative rho.
Sources: 6b0bc2554460:p55

### The sinusoidal plots use normal-form Hough space

The slides retain a y=mx+b label, but the plotted curves are sinusoids with an angular horizontal axis. A fixed image point gives a straight line b=y-mx in (m,b) space, and a sinusoid rho=x*cos(theta)+y*sin(theta) in (theta,rho) space. The generated wording 'sinusoidal curves using y=mx+b' conflates the stale label with the plot. Preserve the original slide and use this distinction when studying the plots.
Sources: 6b0bc2554460:p57, 6b0bc2554460:p58, 6b0bc2554460:p59

### An unsuitable objective is different from an incorrect optimizer

The horizontal line illustrates a limitation of minimizing vertical squared residuals for a near-vertical point cloud. Calling it an 'incorrect minimum' is misleading: it can minimize the stated objective while failing to represent the intended geometric line. This is a modeling/parameterization issue.
Sources: 6b0bc2554460:p20

### Known-radius intersections estimate the center

On pages 73–76 the radius is already fixed, so the intersection identifies center parameters (a,b), not an independently estimated radius. Radius becomes an additional unknown parameter in the three-dimensional accumulator on page 77.
Sources: 6b0bc2554460:p73, 6b0bc2554460:p74, 6b0bc2554460:p75, 6b0bc2554460:p76, 6b0bc2554460:p77

### Complete the line-voting worked example

Additional teaching: for points (1,2) and (3,4), m=(4-2)/(3-1)=1 and b=2-1*1=1, so y=x+1. In normal form choose theta=135 degrees (3*pi/4): cos(theta)=-1/sqrt(2), sin(theta)=1/sqrt(2). Both points then give rho=(y-x)/sqrt(2)=1/sqrt(2). Their voting curves therefore meet at this line parameter. These numeric inputs are a new teaching example, not values claimed to appear in the lecture.
Sources: 6b0bc2554460:p26, 6b0bc2554460:p44, 6b0bc2554460:p60

## Section 1: Lecture 2: Hough Transform

### Finding Boundaries

The process of locating object boundaries in an image, which can be done via human annotations or algorithmic edge detection.
Sources: 6b0bc2554460:p4, 6b0bc2554460:p6, 6b0bc2554460:p7, 6b0bc2554460:p8

### Hough Transform

A feature extraction technique used in computer vision to isolate features of a particular shape, such as lines and circles, represented graphically by intersecting curves.
Sources: 6b0bc2554460:p1, 6b0bc2554460:p2, 6b0bc2554460:p4

### Line Fitting

An overview topic in the lecture addressing how lines are fitted to spatial data points during boundary and feature extraction.
Sources: 6b0bc2554460:p4

### Line Parameterizations

The mathematical representation of lines (such as slope-intercept or polar form) used prior to applying transformations like the Hough transform.
Sources: 6b0bc2554460:p4

### Hough Circles

An extension of the Hough transform designed specifically to detect circular shapes and parameters in digital images.
Sources: 6b0bc2554460:p4

#### 6b0bc2554460:p1 (administrative)

Title slide for AIS412 Lecture 2 on Hough Transform by Mustafa Elattar, with course material attribution to CMU and Stanford.

AIS412 Lecture 2: Hough Transform MUSTAFA ELATTAR

#### 6b0bc2554460:p2 (content)

Title slide with Hough transform visual graphic showing intersecting sinusoidal curves.

Hough transform

#### 6b0bc2554460:p3 (administrative)

Slide credits listing Kris Kitani, Fredo Durand, and James Hays as sources for adapted slide content.

Slide Credits Kris Kitani Fredo Durand James Hays

#### 6b0bc2554460:p4 (content)

Lecture overview outlining topics including finding boundaries, line fitting, line parameterizations, Hough transform, and Hough circles.

Lecture Overview Finding boundaries Line fitting Line parameterizations Hough transform Hough circles

#### 6b0bc2554460:p5 (content)

Section divider slide for finding boundaries.

Finding Boundaries

#### 6b0bc2554460:p6 (content)

Visual example displaying an image of elephants with the question asking where object boundaries are located.

Where are the object boundaries?

#### 6b0bc2554460:p7 (content)

Human annotated boundaries outlining the elephants in the image against a black background.

Human annotated boundaries

#### 6b0bc2554460:p8 (content)

Edge detection output showing computed edges for the elephant image.

Edge detection

## Section 2: Multi-Scale Edge Detection and Boundary Definition Applications

### Multi-Scale Edge Detection

Multi-scale edge detection extracts boundaries at various levels of detail or scale, helping capture coarse object structures alongside finer internal textures [6b0bc2554460:p9].
Sources: 6b0bc2554460:p9

### Perceptual vs. Gradient Edge Strength

Raw edge strength computed via gradient magnitude does not always align with human semantic perception of object boundaries, as low-level gradients can capture noise or irrelevant textures [6b0bc2554460:p10].
Sources: 6b0bc2554460:p10

### Human-Annotated Boundaries

Human annotators often provide diverse, overlapping boundary traces for the same visual objects, reflecting subjective judgment and ambiguity in defining precise edge locations [6b0bc2554460:p12].
Sources: 6b0bc2554460:p12

### Boundary Ambiguity in Natural Scenes

Defining object or feature boundaries in complex natural images (such as mountain tops or textured organic patterns) is challenging for both automated algorithms and human observers [6b0bc2554460:p14, 6b0bc2554460:p15].
Sources: 6b0bc2554460:p14, 6b0bc2554460:p15

### Applications of Edge and Boundary Detection

Edge and boundary detection methods are widely utilized across domains such as autonomous driving (lane detection and semantic segmentation), medical imaging (blood vessel counting), genetics (earthworm contours), and computational photography (inpainting) [6b0bc2554460:p16].
Sources: 6b0bc2554460:p16

#### 6b0bc2554460:p9 (content)

This slide introduces multi-scale edge detection, demonstrating extracted edge lines over a visual scene.

Multi-scale edge detection

#### 6b0bc2554460:p10 (content)

Discusses that computed edge strength does not necessarily correspond directly to human perception of object boundaries.

Edge strength does not necessarily correspond to our perception of boundaries

#### 6b0bc2554460:p11 (content)

Presents an image of textured objects (grain/seeds in a cloth bag) questioning where true object boundaries lie.

Where are the object boundaries?

#### 6b0bc2554460:p12 (content)

Shows human-annotated boundaries outlining objects, displaying variance and multiple overlapping human annotations.

Human annotated boundaries

#### 6b0bc2554460:p13 (content)

Displays algorithmic edge detection output applied to the textured grain bag scene.

Edge detection

#### 6b0bc2554460:p14 (content)

Illustrates complex natural textures (such as underwater feather duster worms) to show that defining boundaries is hard for humans too.

Defining boundaries are hard for us too

#### 6b0bc2554460:p15 (content)

Shows a mountain landscape photo, raising the ambiguity of precisely locating the mountain top boundary.

Where is the boundary of the mountain top?

#### 6b0bc2554460:p16 (content)

Outlines multiple practical applications of edge and boundary detection including autonomous vehicles, tissue engineering, behavioral genetics, and computational photography.

Applications 
 Autonomous Vehicles (lane line detection) 
 tissue engineering (blood vessel counting) 
 behavioral genetics (earthworm contours) 
 Autonomous Vehicles (semantic scene segmentation) 
 Computational Photography (image inpainting)

## Section 3: Line Fitting and Parameterizations

### Line Fitting Least Squares

Given multiple point pairs, line fitting finds parameters m and c by minimizing the average squared distance error function E using partial derivatives set to zero.
Sources: 6b0bc2554460:p18

### Parameterization Failures

Standard slope-intercept parameterizations fail for near-vertical lines or when minimizing standard squared error over y yields horizontal or unintended minimums with huge error values.
Sources: 6b0bc2554460:p19, 6b0bc2554460:p20

### Outlier Sensitivity

Least-squares error fits heavily penalize outliers, meaning single stray points can drastically skew the fitted line away from the main cluster of noisy data.
Sources: 6b0bc2554460:p21

### Model Fitting Challenges

Model fitting is complicated by extraneous clutter, missing data parts, noise, and the combinatorial infeasibility of checking every possible feature combination subset.
Sources: 6b0bc2554460:p22

### Slope Intercept Form

A standard representation of a line defined as y = mx + b, where m represents the slope and b represents the y-intercept.
Sources: 6b0bc2554460:p24

#### 6b0bc2554460:p17 (content)

Title slide for lecture section on Line Fitting.

Line Fitting

#### 6b0bc2554460:p18 (content)

Introduces line fitting formulation, minimizing average squared distance E with respect to parameters m and c.

Given: Many (x_i, y_i) pairs. Find: Parameters (m, c). Minimize: Average square distance: E = sum_i (y_i - mx_i - c)^2 / N. Using: dE/dm = 0 & dE/dc = 0. Note: y_bar = sum_i y_i / N, x_bar = sum_i x_i / N. c = y_bar - mx_bar, m = sum_i (x_i - x_bar)(y_i - y_bar) / sum_i (x_i - x_bar)^2.

#### 6b0bc2554460:p19 (content)

Illustrates problems with parameterizations when a vertical or near-vertical line yields a huge error E.

Problems with parameterizations. Where is the line that minimizes E? E = sum_{i=1}^n (y_i - mx_i - b)^2. Huge E!

#### 6b0bc2554460:p20 (content)

Demonstrates another parameterization limitation where a horizontal line minimizes E incorrectly.

Problems with parameterizations. Where is the line that minimizes E? E = sum_{i=1}^n (y_i - mx_i - b)^2. Line that minimizes E!!

#### 6b0bc2554460:p21 (content)

Explains problems with noise, showing how least-squares error fits are heavily influenced by outliers.

Problems with noise. Least-squares error fit. Squared error heavily penalizes outliers.

#### 6b0bc2554460:p22 (content)

Summarizes why model fitting is difficult due to extraneous data, missing data, noise, and combinatorial cost.

Model fitting is difficult because... Extraneous data: clutter or multiple models. Missing data: only some parts of model are present. Noise. Cost: It is not feasible to check all combinations of features by fitting a model to each possible subset. So what can we do?

#### 6b0bc2554460:p23 (content)

Title slide for line parameterizations.

Line parameterizations

#### 6b0bc2554460:p24 (content)

Introduces slope-intercept form y = mx + b with graphical representation.

Slope intercept form. y = mx + b. slope, y-intercept. Graph showing y = 0.5x + 1.

## Section 4: Hough Transform and Line Representations

### Double Intercept Form

The double intercept form expresses a line in terms of its x-intercept (a) and y-intercept (b) using the equation x/a + y/b = 1, derived from similar triangles and slope equivalence.
Sources: 6b0bc2554460:p25

### Normal Form

The normal form represents a line using the perpendicular distance rho from the origin and the angle theta of the normal vector, expressed as x cos(theta) + y sin(theta) = rho.
Sources: 6b0bc2554460:p26

### Hough Transform Core Idea

The Hough transform is a generic framework for detecting parametric models where edges vote for possible model parameters, allowing detection even when edges are unconnected or occluded.
Sources: 6b0bc2554460:p28

### Image Space to Parameter Space Duality (Line to Point)

Using the slope-intercept parameterization, a straight line in image space corresponds to a single unique point (m, b) in parameter space.
Sources: 6b0bc2554460:p29

### Image Space to Parameter Space Duality (Point to Line)

A fixed point (x, y) in image space corresponds to a linear equation in parameter space, meaning a single point transforms into a line of possible (m, b) parameters.
Sources: 6b0bc2554460:p30, 6b0bc2554460:p31

#### 6b0bc2554460:p25 (content)

Introduces the double intercept form of a line equation (x/a + y/b = 1) along with its geometric derivation.

x/a + y/b = 1, Derivation: (y - b)/(x - 0) = (0 - y)/(a - x), ya + yx - ba + bx = -yx, ya + bx = ba, y/b + x/a = 1

#### 6b0bc2554460:p26 (content)

Presents the normal form of a line equation (x cos(theta) + y sin(theta) = rho) and its geometric derivation.

x cos(theta) + y sin(theta) = rho, cos(theta) = rho/a -> a = rho/cos(theta), sin(theta) = rho/b -> b = rho/sin(theta)

#### 6b0bc2554460:p27 (content)

Title slide for Hough transform.

Hough transform

#### 6b0bc2554460:p28 (content)

Lists key properties and advantages of the Hough transform for detecting parametric models under occlusion and fragmentation.

Generic framework for detecting a parametric model, Edges don't have to be connected, Lines can be occluded, Key idea: edges vote for the possible models

#### 6b0bc2554460:p29 (content)

Illustrates how a line in image space maps to a single point in parameter space.

y = mx + b, y - mx = b, Image space, Parameter space, a line becomes a point

#### 6b0bc2554460:p30 (content)

Poses the question of how a point in image space maps into parameter space.

y = mx + b, Image space, What would a point in image space become in parameter space?, (1, 1)

#### 6b0bc2554460:p31 (content)

Demonstrates that a single point in image space becomes a line in parameter space.

y = mx + b, y - mx = b, Image space, Parameter space, a point becomes a line, (1, 1)

#### 6b0bc2554460:p32 (content)

Poses a question about how two points in image space map into parameter space.

y = mx + b, y - mx = b, Image space, Parameter space, two points become ?, (1, 1), (3, 3)

## Section 5: Hough Transform and Line Detection

### Image Space to Parameter Space Mapping

A point in image space (x, y) maps to a line in parameter space defined by the slope-intercept form y = mx + b, or rearranged as b = y - mx.
Sources: 6b0bc2554460:p33, 6b0bc2554460:p34

### Collinearity and Intersecting Lines

Collinear points in image space correspond to lines in parameter space that intersect at a common point (m, b), identifying the shared line parameters.
Sources: 6b0bc2554460:p35, 6b0bc2554460:p37

### Hough Transform Algorithm

The Hough transform detects geometric shapes by quantizing parameter space, creating an accumulator array, voting for parameter sets corresponding to edge points, and finding local maxima.
Sources: 6b0bc2554460:p39

### Accumulator Array

An accumulator array A(m, c) discretizes the parameter space into bins to count votes from edge points, where peaks indicate the presence of lines.
Sources: 6b0bc2554460:p39, 6b0bc2554460:p40

### Parameterization Challenges

Choosing parameterizations (like slope-intercept m, c) poses challenges such as unbounded parameter ranges and determining appropriate accumulator bin sizes.
Sources: 6b0bc2554460:p40

#### 6b0bc2554460:p33 (content)

Mapping two points from image space to lines in parameter space using y = mx + b.

y = mx + b, y - mx = b, Image space, Parameter space, two points become?

#### 6b0bc2554460:p34 (content)

Adding a third point in image space and observing its corresponding line in parameter space.

three points become?

#### 6b0bc2554460:p35 (content)

Three lines intersect at a common point in parameter space corresponding to collinear points.

three points become?

#### 6b0bc2554460:p36 (content)

Adding a fourth point in image space and showing its line in parameter space.

four points become?

#### 6b0bc2554460:p37 (content)

Four points mapped to parameter space showing multiple intersecting lines.

four points become?

#### 6b0bc2554460:p38 (content)

Discussing robustness of line fitting methods to measurement noise and outliers.

How would you find the best fitting line? Is this method robust to measurement noise? Is this method robust to outliers?

#### 6b0bc2554460:p39 (content)

Algorithm steps for Line Detection by Hough Transform including quantization and accumulator arrays.

Algorithm: 1. Quantize Parameter Space (m, c). 2. Create Accumulator Array A(m, c). 3. Set A(m, c) = 0 for all m, c. 4. For each image edge (x_i, y_i) For each element in A(m, c) If (m, c) lies on the line: c = -x_i m + y_i Increment A(m, c) = A(m, c) + 1. 5. Find local maxima in A(m, c).

#### 6b0bc2554460:p40 (content)

Discussing problems with parameterization and the size requirements for accumulator arrays.

Problems with parameterization. How big does the accumulator need to be for the parameterization (m, c)? A(m, c)

## Section 6: Hough Transform Parameterization and Mapping

### Slope-Intercept Parameterization Issues

Using slope m and intercept c for line detection leads to unbounded accumulator arrays because both parameters can range from negative infinity to positive infinity, making standard accumulator sizing impractical.
Sources: 6b0bc2554460:p41

### Normal Form Parameterization

To resolve infinite bounds, the normal form equation x cos(theta) + y sin(theta) = rho is used, bounding theta between 0 and 2pi and rho between 0 and rho_max, resulting in a finite accumulator array size.
Sources: 6b0bc2554460:p42

### Point to Wave Mapping

In the normal form Hough space, a single point (x_i, y_i) in the image space transforms into a sinusoidal wave (or curve) in the parameter space (rho, theta).
Sources: 6b0bc2554460:p43, 6b0bc2554460:p44

### Line to Point Mapping

Conversely, a complete line passing through points in the image space maps to a specific accumulation point in the parameter space where the corresponding sinusoids intersect.
Sources: 6b0bc2554460:p45, 6b0bc2554460:p46, 6b0bc2554460:p47, 6b0bc2554460:p48

#### 6b0bc2554460:p41 (content)

This page discusses problems with parameterization in accumulator spaces, specifically highlighting that the parameter spaces for slope m and intercept c are huge because they range from negative infinity to positive infinity.

How big does the accumulator need to be for the parameterization (m,c)? A(m,c) grid with accumulator values. -infinity <= m <= infinity, -infinity <= c <= infinity.

#### 6b0bc2554460:p42 (content)

This page introduces a better parameterization using the normal form x cos(theta) + y sin(theta) = rho, giving finite bounds for theta and rho.

Use normal form: x cos(theta) + y sin(theta) = rho. Given points (x_i, y_i) find (rho, theta). Hough Space Sinusoid. 0 <= theta <= 2pi, 0 <= rho <= rho_max. (Finite Accumulator Array Size)

#### 6b0bc2554460:p43 (content)

This page sets up the mapping between image space and parameter space, showing a point at (1,1) in image space and asking what it becomes in parameter space.

Image and parameter space. y = mx + b (variables, parameters). x cos(theta) + y sin(theta) = rho (parameters, variables). Image space grid with point (1,1). a point becomes?

#### 6b0bc2554460:p44 (content)

This page shows that a single point in image space maps to a wave (sinusoid) in the parameter space under the normal form representation.

a point becomes a wave. Parameter space plot showing a sinusoidal curve.

#### 6b0bc2554460:p45 (content)

This page introduces a line passing through a point in image space and asks what this line maps to in parameter space.

Image space showing a vertical line through (1,1). a line becomes?

#### 6b0bc2554460:p46 (content)

This page demonstrates that a line in image space corresponds to a single point in parameter space.

a line becomes a point. Parameter space shows a point on the sinusoid curve.

#### 6b0bc2554460:p47 (content)

This page presents another line at an angle in image space passing through (1,1) and asks what it transforms into in parameter space.

Image space showing an angled line through (1,1) with an angle indicator. a line becomes?

#### 6b0bc2554460:p48 (content)

This page concludes that the angled line in image space maps to a specific intersection point along the sinusoid wave in parameter space.

a line becomes a point. Parameter space shows a point corresponding to the line parameters.

## Section 7: Image and Parameter Space in Hough Transform

### Image and Parameter Space Mapping

A geometric line in image space (coordinates x, y) transforms into a single point in parameter space (coordinates m, b or rho, theta), forming the foundational mapping principle of the Hough transform.
Sources: 6b0bc2554460:p49, 6b0bc2554460:p50, 6b0bc2554460:p51, 6b0bc2554460:p52, 6b0bc2554460:p56

### Polar Hough Transform Representation

Lines are parameterized using polar coordinates via the equation x cos(theta) + y sin(theta) = rho, where rho is the perpendicular distance from the origin to the line and theta is the angle of the normal vector.
Sources: 6b0bc2554460:p49, 6b0bc2554460:p55

### Negative Rho in Parameter Space

Depending on the orientation of the normal vector relative to the origin, the perpendicular distance rho can take negative values, corresponding to points on the complementary sinusoidal branch in parameter space.
Sources: 6b0bc2554460:p53, 6b0bc2554460:p54, 6b0bc2554460:p55

### Trigonometric Identities for Line Equations

Alternative representations of the same geometric line use angle shifts by pi combined with sign inversion of rho, relying on the trigonometric relations sin(theta) = -sin(theta + pi) and cos(theta) = -cos(theta + pi).
Sources: 6b0bc2554460:p55

#### 6b0bc2554460:p49 (content)

Introduces image space and parameter space, showing how a line in image space maps to a point in parameter space using y = mx + b and x cos(theta) + y sin(theta) = rho.

Image space, Parameter space, y = mx + b (variables: y, x; parameters: m, b), x cos(theta) + y sin(theta) = rho, a line becomes a point.

#### 6b0bc2554460:p50 (content)

Demonstrates mapping of a rotated line passing through point (1,1) in image space to a point on the sinusoidal curve in parameter space.

Image space, Parameter space, a line becomes a point, (1,1).

#### 6b0bc2554460:p51 (content)

Shows another orientation of the line through (1,1) in image space, mapping to a different point along the parameter space curve.

Image space, Parameter space, a line becomes a point, (1,1).

#### 6b0bc2554460:p52 (content)

Illustrates a vertical line through (1,1) in image space mapping to the end of the curve in parameter space.

Image space, Parameter space, a line becomes a point, (1,1).

#### 6b0bc2554460:p53 (content)

Presents a question regarding why rho becomes negative for certain orientations when mapping a vertical line in image space.

Wait ...why is rho negative?, Image space, Parameter space, a line becomes a point, (1,1).

#### 6b0bc2554460:p54 (content)

Explores the same line through the point with additional annotations pointing to the two branches corresponding to positive and negative rho.

same line through the point, a line becomes a point, Image space, Parameter space, (1,1).

#### 6b0bc2554460:p55 (content)

Compares positive and negative rho versions of line equations using trigonometric identities to explain dual parameter space representations.

There are two ways to write the same line: Positive rho version: x cos(theta) + y sin(theta) = rho, Negative rho version: x cos(theta + pi) + y sin(theta + pi) = -rho, Recall: sin(theta) = -sin(theta + pi), cos(theta) = -cos(theta + pi).

#### 6b0bc2554460:p56 (content)

Summarizes parameter space mapping with annotations showing how the same line through the point corresponds to multiple locations on the parameter curve.

Image space, Parameter space, same line through the point, a line becomes a point, (1,1).

## Section 8: Hough Transform and Parameter Space

### Image and Parameter Space Mapping

Points in image space map to curves in parameter space. For example, using the line equation y = mx + b, a point (x, y) becomes a curve in parameter space where m and b are parameters.
Sources: 6b0bc2554460:p57, 6b0bc2554460:p58, 6b0bc2554460:p59

### Hough Transform Implementation Algorithm

The Hough transform is implemented by initializing an accumulator array H to zeros, iterating over each edge point and angle theta, calculating rho = x cos(theta) + y sin(theta), and incrementing the accumulator votes.
Sources: 6b0bc2554460:p60

### Accumulator Local Maxima

Detecting geometric structures involves finding local maximum values of H(theta, rho) in the accumulator array, which represent intersecting curves corresponding to collinear points.
Sources: 6b0bc2554460:p60, 6b0bc2554460:p61

### Basic Shapes in Parameter Space

Different geometric structures produce distinct accumulation patterns in parameter space, allowing the Hough transform to distinguish between shapes such as lines, rectangles, and circles.
Sources: 6b0bc2554460:p62, 6b0bc2554460:p63

#### 6b0bc2554460:p57 (content)

Illustrates how two points in image space map to sinusoidal curves in parameter space using y = mx + b.

y = mx + b, variables, parameters, two points become ?

#### 6b0bc2554460:p58 (content)

Shows how adding a third point in image space introduces a third curve in parameter space intersecting at a common point.

y = mx + b, three points become ?

#### 6b0bc2554460:p59 (content)

Demonstrates four points in image space mapping to four intersecting curves in parameter space.

y = mx + b, four points become ?

#### 6b0bc2554460:p60 (content)

Provides the implementation algorithm for the Hough transform using accumulator arrays and notes image coordinate origin.

1. Initialize accumulator H to all zeros
2. For each edge point (x,y) in the image
For theta = 0 to 180
rho = x cos(theta) + y sin(theta)
H(theta, rho) = H(theta, rho) + 1
end
end
3. Find the value(s) of (theta, rho) where H(theta, rho) is a local maximum
4. The detected line in the image is given by rho = x cos(theta) + y sin(theta)
NOTE: Watch your coordinates. Image origin is top left!

#### 6b0bc2554460:p61 (content)

Compares an image space point distribution with its corresponding voting pattern in parameter space.

Image space, Votes

#### 6b0bc2554460:p62 (content)

Displays parameter space voting patterns and asks the viewer to guess the corresponding shape.

Basic shapes (in parameter space), can you guess the shape?

#### 6b0bc2554460:p63 (content)

Identifies basic shapes in parameter space corresponding to line, rectangle, and circle.

line, rectangle, circle

#### 6b0bc2554460:p64 (content)

Shows a complex image of a bird behind cage bars alongside its accumulator voting space.

More complex image

## Section 9: Hough Transform: Noise Effects and Circle Detection

### Noise Impact on Hough Transform Votes

Higher measurement noise spreads out votes in parameter space, decreasing the maximum vote count in the correct accumulator bin while increasing false votes in incorrect bins.
Sources: 6b0bc2554460:p65, 6b0bc2554460:p66, 6b0bc2554460:p67, 6b0bc2554460:p68

### Hough Circles with Known Radius

When the circle radius r is known, the circle equation is (x - a)^2 + (y - b)^2 = r^2, where x and y are image coordinates and a and b are the unknown circle center parameters.
Sources: 6b0bc2554460:p71, 6b0bc2554460:p72

### Image Space to Parameter Space Mapping for Circles

A single data point (x, y) in the image space corresponds to a continuous locus of possible parameters (a, b)—specifically a circle—in the parameter space.
Sources: 6b0bc2554460:p72

#### 6b0bc2554460:p65 (content)

Demonstrates the effect of noisy measurements on image space and votes in parameter space.

In practice, measurements are noisy...
Image space
Votes

#### 6b0bc2554460:p66 (content)

Illustrates the impact of high noise levels on image space and corresponding vote dispersion.

Too much noise ...
Image space
Votes

#### 6b0bc2554460:p67 (content)

Bar chart showing that as noise level increases, the maximum number of votes in the correct bin decreases.

Effects of noise level
Number of votes for a line of 20 points with increasing noise
Maximum number of votes: 5, 10, 15
Noise level: 0.01 to 0.09
More noise, fewer votes (in the right bin)

#### 6b0bc2554460:p68 (content)

Bar chart showing that increasing the number of noise points increases votes in the wrong bin.

Effects of noise level
Maximum number of votes: 0, 3, 6, 9, 12
Number of noise points: 20 to 200
More noise, more votes (in the wrong bin)

#### 6b0bc2554460:p69 (content)

Presents a real-world example of edge detection, parameter space mapping, and extracted Hough lines.

Real-world example
Original
Edges
parameter space
Hough Lines

#### 6b0bc2554460:p70 (content)

Title slide introducing Hough Circles.

Hough Circles

#### 6b0bc2554460:p71 (content)

Introduces circle equation assuming known radius, labeling variables and parameters.

Let's assume radius known
(x - a)^2 + (y - b)^2 = r^2
parameters (a, b)
variables (x, y)
What is the dimension of the parameter space?

#### 6b0bc2554460:p72 (content)

Relates a point in image space to its corresponding locus in parameter space for circle detection.

(x - a)^2 + (y - b)^2 = r^2
Image space (x, y point at 3,2)
Parameter space (axes a and b)
What does a point in image space correspond to in parameter space?

## Section 10: Circle Hough Transform and Gradient Information

### Circle Hough Transform Mapping

A point (x, y) in image space maps to a circular locus of parameters (a, b) in Hough space satisfying (x - a)^2 + (y - b)^2 = r^2, where a and b are parameters and x and y are variables.
Sources: 6b0bc2554460:p73, 6b0bc2554460:p74, 6b0bc2554460:p75, 6b0bc2554460:p76

### Accumulator Intersection

Multiple edge points in image space generate intersecting loci in Hough space. The point of maximum intersection corresponds to the parameters of the geometric shape (circle center and radius).
Sources: 6b0bc2554460:p74, 6b0bc2554460:p75, 6b0bc2554460:p76

### Unknown Radius Hough Space

If the radius r is not known, the Hough space expands to 3 dimensions, requiring a 3D accumulator array A(a, b, r) with a complicated surface shape.
Sources: 6b0bc2554460:p77

### Gradient Information in Hough Transform

Using edge location (x_i, y_i) and edge direction phi_i saves computation when the radius is known, allowing the algorithm to increment only a single point in the accumulator using equations a = x - r cos(phi) and b = y - r sin(phi).
Sources: 6b0bc2554460:p78, 6b0bc2554460:p79, 6b0bc2554460:p80

#### 6b0bc2554460:p73 (content)

Mapping a single point in image space (x, y) to a circular locus of parameter values (a, b) in Hough space using the circle equation with parameters a, b and variables x, y.

(x - a)^2 + (y - b)^2 = r^2

#### 6b0bc2554460:p74 (content)

Adding a second point in image space creates a second intersecting circle in Hough space, identifying common parameter configurations.

(x - a)^2 + (y - b)^2 = r^2

#### 6b0bc2554460:p75 (content)

Accumulating a third point in image space adds a third intersecting circle in Hough space, refining the intersection center.

(x - a)^2 + (y - b)^2 = r^2

#### 6b0bc2554460:p76 (content)

Four points in image space form four intersecting circles in Hough space sharing a common intersection point at the circle parameters.

(x - a)^2 + (y - b)^2 = r^2

#### 6b0bc2554460:p77 (content)

Extending to an unknown radius requires a 3D Hough space accumulator array A(a, b, r), resulting in a complicated surface shape.

Accumulator array A(a, b, r)

#### 6b0bc2554460:p78 (content)

Using gradient information and edge direction phi_i allows incrementing only one point in the accumulator when radius is known.

EdgeLocation (x_i, y_i), EdgeDirection phi_i, a = x - r cos(phi), b = y - r sin(phi)

#### 6b0bc2554460:p79 (content)

Mapping an edge point with gradient information directly to a single point in the parameter space using gradient orientation.

(x, y, phi)

#### 6b0bc2554460:p80 (content)

Demonstrating how gradient-based voting maps edge segments to a specific parameter point in accumulator space.

(x, y, phi)

## Section 11: The Hough Transform and Shape Feature Detection

### Hough Transform for Circle Detection

The Hough transform maps image edge pixels into parameter accumulator spaces to detect specific geometric shapes like pennies or quarters, handling occlusions and multiple instances well despite high computational complexity.
Sources: 6b0bc2554460:p81, 6b0bc2554460:p82, 6b0bc2554460:p83, 6b0bc2554460:p84

### Scale-Invariant Shape Features

Object category recognition can be performed using scale-invariant shape features that detect structural contours across varying scales, as introduced by Jurie and Schmid.
Sources: 6b0bc2554460:p86

### Laplacian Circles vs. Hough-like Circles

Feature detectors can be evaluated for consistency by comparing Laplacian circle responses against Hough-like circle detectors on articulated or textured object categories like horse toys.
Sources: 6b0bc2554460:p87

### Robustness to Scale and Clutter

Advanced shape feature detectors using Hough-like approaches demonstrate resilience against background clutter and scale variations in natural images.
Sources: 6b0bc2554460:p88

#### 6b0bc2554460:p81 (content)

Visual comparison of an input coin image alongside its edge-detected binary map.

Left: Color image of four coins on textured fabric. Right: Edge detection result showing binary contours of the coins.

#### 6b0bc2554460:p82 (content)

Accumulator space representations using Pennie Hough detector versus Quarter Hough detector on coin images.

Pennie Hough detector | Quarter Hough detector

#### 6b0bc2554460:p83 (content)

Accumulator space outputs highlighting detected peaks for pennies and quarters.

Pennie Hough detector | Quarter Hough detector

#### 6b0bc2554460:p84 (content)

Evaluation of the Hough transform across multiple performance criteria using thumbs up and down icons.

The Hough transform
(Thumbs up) Deals with occlusion well?
(Thumbs up) Detects multiple instances?
(Thumbs up) Robust to noise?
(Thumbs down) Good computational complexity?
(Thumbs down) Easy to set parameters?

#### 6b0bc2554460:p85 (content)

Title slide introducing applications of Hough transforms.

Application of Hough transforms

#### 6b0bc2554460:p86 (content)

Introduction to scale-invariant shape features for object category recognition, referencing Jurie and Schmid (CVPR 2004).

Detecting shape features
F. Jurie and C. Schmid, Scale-invariant shape features for recognition of object categories, CVPR2004

#### 6b0bc2554460:p87 (content)

Comparison between Laplacian circles and Hough-like circles for consistent feature detection on horse images.

Original images
Laplacian circles | Hough-like circles
Which feature detector is more consistent?

#### 6b0bc2554460:p88 (content)

Demonstration of robustness to scale and clutter using Hough-like circle features.

Robustness to scale and clutter
