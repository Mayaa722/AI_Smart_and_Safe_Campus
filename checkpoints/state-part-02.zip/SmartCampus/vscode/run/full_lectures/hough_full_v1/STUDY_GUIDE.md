# Study Guide: Hough Transform and Boundary Detection

This study guide covers Lecture 2 on the Hough Transform, including finding boundaries, line fitting, line parameterizations, the Hough transform algorithm, Hough circles, and applications.

# Finding Boundaries and Line Fitting

Finding object boundaries is difficult because edge strength does not always correspond directly to human perception, and natural images contain texture, clutter, and ambiguity [p. 10](<run/cache/d2ed44c68345d2b0/page_0010.png>) [p. 14](<run/cache/d2ed44c68345d2b0/page_0014.png>) [p. 15](<run/cache/d2ed44c68345d2b0/page_0015.png>)

Applications of edge and boundary detection include autonomous vehicles for lane line detection and semantic scene segmentation, tissue engineering for blood vessel counting, behavioral genetics for earthworm contours, and computational photography for image inpainting [p. 16](<run/cache/d2ed44c68345d2b0/page_0016.png>)

Line fitting is formulated by minimizing the average squared distance E with respect to parameters m and c given (x\_i, y\_i) pairs: E = sum\_i (y\_i - mx\_i - c)^2 / N [p. 18](<run/cache/d2ed44c68345d2b0/page_0018.png>)

Least-squares minimization uses derivative conditions dE/dm = 0 and dE/dc = 0, yielding parameters c = y\_bar - mx\_bar and m = sum\_i (x\_i - x\_bar)(y\_i - y\_bar) / sum\_i (x\_i - x\_bar)^2 where x\_bar = sum\_i x\_i / N and y\_bar = sum\_i y\_i / N [p. 18](<run/cache/d2ed44c68345d2b0/page_0018.png>)

Model fitting difficulties arise from extraneous data, missing data, noise, and the high combinatorial cost of checking all subsets [p. 22](<run/cache/d2ed44c68345d2b0/page_0022.png>)

# Line Parameterizations

Slope-intercept form is represented as y = mx + b [p. 24](<run/cache/d2ed44c68345d2b0/page_0024.png>)

Double intercept form is represented as x/a + y/b = 1, derived via (y - b)/(x - 0) = (0 - y)/(a - x) [p. 25](<run/cache/d2ed44c68345d2b0/page_0025.png>)

Normal form is represented as x cos(theta) + y sin(theta) = rho, where cos(theta) = rho/a leading to a = rho/cos(theta), and sin(theta) = rho/b leading to b = rho/sin(theta) [p. 26](<run/cache/d2ed44c68345d2b0/page_0026.png>)

# Hough Transform for Lines

The Hough transform is a generic framework for detecting parametric models where edges do not have to be connected and lines can be occluded, with the key idea that edges vote for possible models [p. 28](<run/cache/d2ed44c68345d2b0/page_0028.png>)

In parameter space, a single point in image space maps to a line using y = mx + b or to a sinusoid wave using x cos(theta) + y sin(theta) = rho [p. 31](<run/cache/d2ed44c68345d2b0/page_0031.png>) [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>)

Line detection algorithm using normal form: 1. Initialize accumulator H to all zeros. 2. For each edge point (x,y), for theta = 0 to 180, compute rho = x cos(theta) + y sin(theta) and increment H(theta, rho) = H(theta, rho) + 1. 3. Find local maxima in H(theta, rho). 4. Detected line is given by rho = x cos(theta) + y sin(theta). Note that image origin is top left [p. 60](<run/cache/d2ed44c68345d2b0/page_0060.png>)

Using normal form x cos(theta) + y sin(theta) = rho provides finite bounds for theta (0 <= theta <= 2pi) and rho (0 <= rho <= rho\_max) compared to infinite bounds for slope-intercept parameters m and c [p. 41](<run/cache/d2ed44c68345d2b0/page_0041.png>) [p. 42](<run/cache/d2ed44c68345d2b0/page_0042.png>)

Two ways to write the same line are the positive rho version x cos(theta) + y sin(theta) = rho and the negative rho version x cos(theta + pi) + y sin(theta + pi) = -rho, recalling trigonometric identities sin(theta) = -sin(theta + pi) and cos(theta) = -cos(theta + pi) [p. 55](<run/cache/d2ed44c68345d2b0/page_0055.png>)

# Hough Circles

Assuming radius is known, circle equation is (x - a)^2 + (y - b)^2 = r^2 with parameters (a, b) and variables (x, y) [p. 71](<run/cache/d2ed44c68345d2b0/page_0071.png>)

An unknown radius requires a 3D Hough space accumulator array A(a, b, r), resulting in a complicated surface shape [p. 77](<run/cache/d2ed44c68345d2b0/page_0077.png>)

Using gradient information and edge direction phi\_i allows incrementing only one point in the accumulator when radius is known via a = x - r cos(phi) and b = y - r sin(phi) [p. 78](<run/cache/d2ed44c68345d2b0/page_0078.png>)

Evaluation of the Hough transform shows thumbs up for dealing with occlusion well, detecting multiple instances, and robustness to noise, but thumbs down for computational complexity and ease of setting parameters [p. 84](<run/cache/d2ed44c68345d2b0/page_0084.png>)

Additional teaching: Worked example 1 (Line Hough Voting). Consider two edge points at image coordinates (1, 2) and (3, 4). Using the normal form equation, each point casts sinusoidal votes across all tested theta values in accumulator space. Where these sinusoids intersect at a peak accumulator bin (theta, rho), a supporting line passing through both points is detected. [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>) [p. 60](<run/cache/d2ed44c68345d2b0/page_0060.png>)

Additional teaching: Worked example 2 (Circle Parameterization). If an edge point is located at (x=5, y=3) with an edge gradient direction phi = 0 radians and a fixed radius r = 2, the center parameters can be computed directly as a = 5 - 2 cos(0) = 3 and b = 3 - 2 sin(0) = 3, casting a direct vote at accumulator bin (3, 3) without needing a full circular sweep. [p. 78](<run/cache/d2ed44c68345d2b0/page_0078.png>)

**Additional teaching:** Common misconceptions: A common misconception is that a point in image space maps to a point in parameter space for lines; in slope-intercept and normal forms, a point in image space actually maps to a line or a sinusoid wave in parameter space, whereas a line in image space maps to a point in parameter space. [p. 31](<run/cache/d2ed44c68345d2b0/page_0031.png>) [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>) [p. 46](<run/cache/d2ed44c68345d2b0/page_0046.png>)

**Additional teaching:** Revision questions: 1. Why does the slope-intercept parameterization (m, c) fail for vertical lines? 2. How does using gradient direction phi simplify circle detection in the Hough transform? [p. 19](<run/cache/d2ed44c68345d2b0/page_0019.png>) [p. 78](<run/cache/d2ed44c68345d2b0/page_0078.png>)

## Assistant source and note clarifications

### Double-intercept derivation: printed sign typo

The original slide prints ya + yx - ba + bx = -yx. Expanding (y-b)(a-x) = -xy instead gives ay - xy - ab + bx = -xy. Cancelling -xy yields ay + bx = ab and therefore x/a + y/b = 1 (when a and b are nonzero). The final intercept equation is correct; the intermediate printed plus sign is a source typo, not a valid algebra step. [p. 25](<run/cache/d2ed44c68345d2b0/page_0025.png>)

### Signed rho versus geometric distance

In a signed-rho convention, rho may be negative; the nonnegative perpendicular distance is abs(rho). The sign depends on the chosen oriented normal. Keep the theta range and rho convention consistent: a half-turn theta range pairs with signed rho, while a full-turn range can use nonnegative rho. [p. 55](<run/cache/d2ed44c68345d2b0/page_0055.png>)

### The sinusoidal plots use normal-form Hough space

The slides retain a y=mx+b label, but the plotted curves are sinusoids with an angular horizontal axis. A fixed image point gives a straight line b=y-mx in (m,b) space, and a sinusoid rho=x\*cos(theta)+y\*sin(theta) in (theta,rho) space. The generated wording 'sinusoidal curves using y=mx+b' conflates the stale label with the plot. Preserve the original slide and use this distinction when studying the plots. [p. 57](<run/cache/d2ed44c68345d2b0/page_0057.png>) [p. 58](<run/cache/d2ed44c68345d2b0/page_0058.png>) [p. 59](<run/cache/d2ed44c68345d2b0/page_0059.png>)

### An unsuitable objective is different from an incorrect optimizer

The horizontal line illustrates a limitation of minimizing vertical squared residuals for a near-vertical point cloud. Calling it an 'incorrect minimum' is misleading: it can minimize the stated objective while failing to represent the intended geometric line. This is a modeling/parameterization issue. [p. 20](<run/cache/d2ed44c68345d2b0/page_0020.png>)

### Known-radius intersections estimate the center

On pages 73–76 the radius is already fixed, so the intersection identifies center parameters (a,b), not an independently estimated radius. Radius becomes an additional unknown parameter in the three-dimensional accumulator on page 77. [p. 73](<run/cache/d2ed44c68345d2b0/page_0073.png>) [p. 74](<run/cache/d2ed44c68345d2b0/page_0074.png>) [p. 75](<run/cache/d2ed44c68345d2b0/page_0075.png>) [p. 76](<run/cache/d2ed44c68345d2b0/page_0076.png>) [p. 77](<run/cache/d2ed44c68345d2b0/page_0077.png>)

### Complete the line-voting worked example

Additional teaching: for points (1,2) and (3,4), m=(4-2)/(3-1)=1 and b=2-1\*1=1, so y=x+1. In normal form choose theta=135 degrees (3\*pi/4): cos(theta)=-1/sqrt(2), sin(theta)=1/sqrt(2). Both points then give rho=(y-x)/sqrt(2)=1/sqrt(2). Their voting curves therefore meet at this line parameter. These numeric inputs are a new teaching example, not values claimed to appear in the lecture. [p. 26](<run/cache/d2ed44c68345d2b0/page_0026.png>) [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>) [p. 60](<run/cache/d2ed44c68345d2b0/page_0060.png>)

