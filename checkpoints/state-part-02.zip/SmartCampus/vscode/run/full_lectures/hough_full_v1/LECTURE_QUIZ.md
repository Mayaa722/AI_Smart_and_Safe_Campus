# Full-lecture quiz — unreviewed draft

Difficulty labels are uncalibrated. The keyed answer/explanation is shown for instructor review.

## 1. Why does computed edge strength often fail to match human perception when locating object boundaries?

A. Edge detection algorithms always operate at infinite resolution.
B. Computed edge strength does not necessarily correspond directly to human perception of object boundaries, as seen in textured scenes.
C. Humans only perceive boundaries that are horizontal or vertical.
D. Edge detectors completely ignore color information.

Key: B. The lecture notes explicitly state that computed edge strength does not necessarily correspond to our perception of boundaries, especially in complex textured or natural scenes.

Sources: [p. 10](<run/cache/d2ed44c68345d2b0/page_0010.png>)

## 2. What is a major failure mode of least-squares line fitting when using the slope-intercept parameterization (y = mx + b)?

A. It cannot handle any noise whatsoever.
B. Vertical or near-vertical lines result in an extremely large or undefined error E.
C. It always underestimates the number of data points.
D. It requires non-linear optimization for horizontal lines.

Key: B. The slope-intercept parameterization struggles with vertical or near-vertical lines because the slope approaches infinity, resulting in a huge error E.

Sources: [p. 19](<run/cache/d2ed44c68345d2b0/page_0019.png>)

## 3. Which of the following is cited as a reason why model fitting is difficult in computer vision?

A. Extraneous data, missing data, noise, and combinatorial cost
B. Lack of matrix multiplication hardware
C. Computers cannot represent floating-point numbers
D. Every model must have exactly two parameters

Key: A. The lecture lists extraneous data (clutter/multiple models), missing data, noise, and combinatorial cost as the primary difficulties for model fitting.

Sources: [p. 22](<run/cache/d2ed44c68345d2b0/page_0022.png>)

## 4. In the standard Hough transform for lines using the normal form (x cos(theta) + y sin(theta) = rho), what does a single point in image space map to in parameter space?

A. A single point
B. A straight line
C. A sinusoid (wave curve)
D. A parabola

Key: C. Under the normal form representation, a single point in image space maps to a sinusoid (wave) in the (theta, rho) parameter space.

Sources: [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>)

## 5. Why is the normal form representation (x cos(theta) + y sin(theta) = rho) preferred over the slope-intercept form (y = mx + b) for the Hough transform accumulator?

A. It avoids trigonometric calculations entirely.
B. It provides finite bounds for the parameter space (theta and rho), whereas m and c range from negative to positive infinity.
C. It allows negative pixel coordinates.
D. It completely eliminates the need for voting.

Key: B. The slope and intercept parameters (m, c) range from negative infinity to positive infinity making an infinite accumulator grid necessary, whereas the normal form uses bounded ranges for theta and rho.

Sources: [p. 41](<run/cache/d2ed44c68345d2b0/page_0041.png>) [p. 42](<run/cache/d2ed44c68345d2b0/page_0042.png>)

## 6. What is the primary effect of increased noise levels on the Hough accumulator array performance?

A. It increases the number of votes in the correct bin while suppressing all noise.
B. It has zero effect on accumulator counts.
C. It decreases the maximum number of votes in the correct bin and increases votes in wrong bins due to clutter.
D. It automatically removes all outlier edge points.

Key: C. As noise and clutter increase, fewer votes land in the correct bin and more votes accumulate in incorrect bins.

Sources: [p. 67](<run/cache/d2ed44c68345d2b0/page_0067.png>) [p. 68](<run/cache/d2ed44c68345d2b0/page_0068.png>)

## 7. When detecting circles with an unknown radius using the Hough transform, what dimension is required for the accumulator array if gradient information is not used?

A. 1D accumulator array
B. 2D accumulator array
C. 3D accumulator array A(a, b, r)
D. 4D accumulator array

Key: C. Extending circle detection to an unknown radius requires a 3D Hough space accumulator array A(a, b, r) representing the center coordinates and the radius.

Sources: [p. 77](<run/cache/d2ed44c68345d2b0/page_0077.png>)

## 8. According to the summary evaluation in the lecture, what are known strengths and weaknesses of the Hough transform?

A. It handles occlusion and multiple instances well, but has poor computational complexity and is hard to set parameters for.
B. It has perfect computational complexity and makes parameter tuning trivial.
C. It fails completely in the presence of occlusion and noise.
D. It can only detect a single instance of a model at a time.

Key: A. The evaluation summary gives thumbs up for handling occlusion, detecting multiple instances, and noise robustness, but gives thumbs down for computational complexity and ease of parameter setting.

Sources: [p. 84](<run/cache/d2ed44c68345d2b0/page_0084.png>)
