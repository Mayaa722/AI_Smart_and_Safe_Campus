# Full-lecture quiz — unreviewed draft

Difficulty labels are uncalibrated. The keyed answer/explanation is shown for instructor review.

## 1. A textured surface produces strong internal edges that a person does not regard as object boundaries. Which conclusion matches the lecture?

A. Strong local intensity changes need not match the boundaries perceived by a human.
B. Changing the Hough accumulator resolution directly resolves semantic boundary ambiguity.
C. Selecting only the finest-scale edges removes texture boundaries while preserving object contours.
D. The largest image gradients are sufficient to identify semantic object boundaries.

Key: A. The lecture distinguishes computed edge strength from human perception of boundaries; texture can create strong changes inside a single object. [p. 10](<run/cache/d2ed44c68345d2b0/page_0010.png>)

Sources: [p. 10](<run/cache/d2ed44c68345d2b0/page_0010.png>)

## 2. A line-fitting method becomes unstable for nearly vertical lines in y=mx+b form. Which change addresses the parameterization problem?

A. Use smaller intercept bins while retaining the same slope range.
B. Represent the line by normal angle and perpendicular distance.
C. Increase the weight of points with large vertical residuals.
D. Estimate the intercept first and force all lines to share it.

Key: B. Near-vertical lines cause problems for slope-intercept parameters. Normal form uses angle and perpendicular distance and avoids an unbounded slope. [p. 19](<run/cache/d2ed44c68345d2b0/page_0019.png>) [p. 42](<run/cache/d2ed44c68345d2b0/page_0042.png>)

Sources: [p. 19](<run/cache/d2ed44c68345d2b0/page_0019.png>) [p. 42](<run/cache/d2ed44c68345d2b0/page_0042.png>)

## 3. An edge map contains clutter, occluded object fragments and noisy measurements. Which set of model-fitting difficulties does the lecture identify?

A. Only the choice of intercept; testing subsets is independent of the number of points.
B. Extraneous data, missing data, noise and combinatorial cost.
C. Only inaccurate parameter bins; the set of edge points is otherwise sufficient.
D. Only missing data; points from other objects do not affect model selection.

Key: B. The lecture explicitly lists extraneous data, missing data, noise and combinatorial cost. A scene with clutter and occlusion can exhibit these together. [p. 22](<run/cache/d2ed44c68345d2b0/page_0022.png>)

Sources: [p. 22](<run/cache/d2ed44c68345d2b0/page_0022.png>)

## 4. Additional teaching application: using rho=x\*cos(theta)+y\*sin(theta), what curve does the image point (0,2) vote along?

A. rho=sin(theta)+2
B. rho=2 for every theta
C. rho=2\*cos(theta)
D. rho=2\*sin(theta)

Key: D. Substituting x=0 and y=2 gives rho=2\*sin(theta). This new example applies the lecture normal form and its point-to-sinusoid mapping. [p. 26](<run/cache/d2ed44c68345d2b0/page_0026.png>) [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>)

Sources: [p. 26](<run/cache/d2ed44c68345d2b0/page_0026.png>) [p. 44](<run/cache/d2ed44c68345d2b0/page_0044.png>)

## 5. Why is normal form convenient when building a line Hough accumulator for a finite image?

A. It offers bounded angle/distance ranges while slope and intercept can be unbounded.
B. It makes the vote peak independent of the selected bin widths.
C. It replaces edge locations with edge intensity values as the only parameters.
D. It assigns one vote to each image point without testing parameter values.

Key: A. The lecture contrasts unbounded slope/intercept parameters with bounded angle and distance ranges. A practical slope-intercept accumulator would require additional restrictions. [p. 41](<run/cache/d2ed44c68345d2b0/page_0041.png>) [p. 42](<run/cache/d2ed44c68345d2b0/page_0042.png>)

Sources: [p. 41](<run/cache/d2ed44c68345d2b0/page_0041.png>) [p. 42](<run/cache/d2ed44c68345d2b0/page_0042.png>)

## 6. As measurement noise increases, which accumulator change matches the lecture plots?

A. The correct-bin peak grows because each noisy point supplies more matching votes.
B. The correct-bin peak remains unchanged while only image-space positions move.
C. The correct-bin peak falls and more votes can appear in wrong bins.
D. The correct-bin peak moves to a radius dimension even for line detection.

Key: C. The noise plots show fewer votes in the right bin and more spurious votes in wrong bins as measurements become noisy. [p. 67](<run/cache/d2ed44c68345d2b0/page_0067.png>) [p. 68](<run/cache/d2ed44c68345d2b0/page_0068.png>)

Sources: [p. 67](<run/cache/d2ed44c68345d2b0/page_0067.png>) [p. 68](<run/cache/d2ed44c68345d2b0/page_0068.png>)

## 7. A circle detector must estimate both center coordinates and an unknown radius. What accumulator parameter space does the lecture require?

A. A 2D accumulator over theta and rho.
B. A 1D accumulator over r, with the center implicit in each edge point.
C. A 2D accumulator over a and b with one fixed global radius.
D. A 3D accumulator over a, b and r.

Key: D. Unknown-radius circles require the center coordinates and radius as three parameters, represented by A(a,b,r). [p. 77](<run/cache/d2ed44c68345d2b0/page_0077.png>)

Sources: [p. 77](<run/cache/d2ed44c68345d2b0/page_0077.png>)

## 8. Additional teaching application: use the lecture convention a=x-r\*cos(phi), b=y-r\*sin(phi). For (x,y)=(5,3), r=2 and phi=0, which center bin receives the vote?

A. (5,1)
B. (3,1)
C. (3,3)
D. (7,3)

Key: C. Using the stated convention gives a=5-2\*1=3 and b=3-2\*0=3. The other options reverse the sign, swap direction axes, or subtract r from both coordinates. This is a new worked example using the original slide formula. [p. 78](<run/cache/d2ed44c68345d2b0/page_0078.png>)

Sources: [p. 78](<run/cache/d2ed44c68345d2b0/page_0078.png>)
