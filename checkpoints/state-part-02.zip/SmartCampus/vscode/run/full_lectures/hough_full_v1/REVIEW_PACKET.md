# Hough lecture review packet

Prepared for genuine user/instructor review. All human ratings are blank; assistant review is not instructor approval.

Use 1 (poor) to 5 (strong) for source support, correctness, clarity and teaching usefulness. For quizzes also assess whether exactly one option is defensible and whether wrong options are plausible.

## Whole-lecture guide

This study guide covers Lecture 2 on the Hough Transform, including finding boundaries, line fitting, line parameterizations, the Hough transform algorithm, Hough circles, and applications.

# Finding Boundaries and Line Fitting

Finding object boundaries is difficult because edge strength does not always correspond directly to human perception, and natural images contain texture, clutter, and ambiguity [6b0bc2554460:p10] [6b0bc2554460:p14] [6b0bc2554460:p15]

Applications of edge and boundary detection include autonomous vehicles for lane line detection and semantic scene segmentation, tissue engineering for blood vessel counting, behavioral genetics for earthworm contours, and computational photography for image inpainting [6b0bc2554460:p16]

Line fitting is formulated by minimizing the average squared distance E with respect to parameters m and c given (x_i, y_i) pairs: E = sum_i (y_i - mx_i - c)^2 / N [6b0bc2554460:p18]

Least-squares minimization uses derivative conditions dE/dm = 0 and dE/dc = 0, yielding parameters c = y_bar - mx_bar and m = sum_i (x_i - x_bar)(y_i - y_bar) / sum_i (x_i - x_bar)^2 where x_bar = sum_i x_i / N and y_bar = sum_i y_i / N [6b0bc2554460:p18]

Model fitting difficulties arise from extraneous data, missing data, noise, and the high combinatorial cost of checking all subsets [6b0bc2554460:p22]

# Line Parameterizations

Slope-intercept form is represented as y = mx + b [6b0bc2554460:p24]

Double intercept form is represented as x/a + y/b = 1, derived via (y - b)/(x - 0) = (0 - y)/(a - x) [6b0bc2554460:p25]

Normal form is represented as x cos(theta) + y sin(theta) = rho, where cos(theta) = rho/a leading to a = rho/cos(theta), and sin(theta) = rho/b leading to b = rho/sin(theta) [6b0bc2554460:p26]

# Hough Transform for Lines

The Hough transform is a generic framework for detecting parametric models where edges do not have to be connected and lines can be occluded, with the key idea that edges vote for possible models [6b0bc2554460:p28]

In parameter space, a single point in image space maps to a line using y = mx + b or to a sinusoid wave using x cos(theta) + y sin(theta) = rho [6b0bc2554460:p31] [6b0bc2554460:p44]

Line detection algorithm using normal form: 1. Initialize accumulator H to all zeros. 2. For each edge point (x,y), for theta = 0 to 180, compute rho = x cos(theta) + y sin(theta) and increment H(theta, rho) = H(theta, rho) + 1. 3. Find local maxima in H(theta, rho). 4. Detected line is given by rho = x cos(theta) + y sin(theta). Note that image origin is top left [6b0bc2554460:p60]

Using normal form x cos(theta) + y sin(theta) = rho provides finite bounds for theta (0 <= theta <= 2pi) and rho (0 <= rho <= rho_max) compared to infinite bounds for slope-intercept parameters m and c [6b0bc2554460:p41] [6b0bc2554460:p42]

Two ways to write the same line are the positive rho version x cos(theta) + y sin(theta) = rho and the negative rho version x cos(theta + pi) + y sin(theta + pi) = -rho, recalling trigonometric identities sin(theta) = -sin(theta + pi) and cos(theta) = -cos(theta + pi) [6b0bc2554460:p55]

# Hough Circles

Assuming radius is known, circle equation is (x - a)^2 + (y - b)^2 = r^2 with parameters (a, b) and variables (x, y) [6b0bc2554460:p71]

An unknown radius requires a 3D Hough space accumulator array A(a, b, r), resulting in a complicated surface shape [6b0bc2554460:p77]

Using gradient information and edge direction phi_i allows incrementing only one point in the accumulator when radius is known via a = x - r cos(phi) and b = y - r sin(phi) [6b0bc2554460:p78]

Evaluation of the Hough transform shows thumbs up for dealing with occlusion well, detecting multiple instances, and robustness to noise, but thumbs down for computational complexity and ease of setting parameters [6b0bc2554460:p84]

Additional teaching: Worked example 1 (Line Hough Voting). Consider two edge points at image coordinates (1, 2) and (3, 4). Using the normal form equation, each point casts sinusoidal votes across all tested theta values in accumulator space. Where these sinusoids intersect at a peak accumulator bin (theta, rho), a supporting line passing through both points is detected. [6b0bc2554460:p44] [6b0bc2554460:p60]

Additional teaching: Worked example 2 (Circle Parameterization). If an edge point is located at (x=5, y=3) with an edge gradient direction phi = 0 radians and a fixed radius r = 2, the center parameters can be computed directly as a = 5 - 2 cos(0) = 3 and b = 3 - 2 sin(0) = 3, casting a direct vote at accumulator bin (3, 3) without needing a full circular sweep. [6b0bc2554460:p78]

**Additional teaching:** Common misconceptions: A common misconception is that a point in image space maps to a point in parameter space for lines; in slope-intercept and normal forms, a point in image space actually maps to a line or a sinusoid wave in parameter space, whereas a line in image space maps to a point in parameter space. [6b0bc2554460:p31] [6b0bc2554460:p44] [6b0bc2554460:p46]

**Additional teaching:** Revision questions: 1. Why does the slope-intercept parameterization (m, c) fail for vertical lines? 2. How does using gradient direction phi simplify circle detection in the Hough transform? [6b0bc2554460:p19] [6b0bc2554460:p78]

## Quiz item 1

A textured surface produces strong internal edges that a person does not regard as object boundaries. Which conclusion matches the lecture?

A. Strong local intensity changes need not match the boundaries perceived by a human.
B. Changing the Hough accumulator resolution directly resolves semantic boundary ambiguity.
C. Selecting only the finest-scale edges removes texture boundaries while preserving object contours.
D. The largest image gradients are sufficient to identify semantic object boundaries.

Generated/refined key: A. The lecture distinguishes computed edge strength from human perception of boundaries; texture can create strong changes inside a single object. [6b0bc2554460:p10]

[6b0bc2554460:p10 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0010.png>)

## Quiz item 2

A line-fitting method becomes unstable for nearly vertical lines in y=mx+b form. Which change addresses the parameterization problem?

A. Use smaller intercept bins while retaining the same slope range.
B. Represent the line by normal angle and perpendicular distance.
C. Increase the weight of points with large vertical residuals.
D. Estimate the intercept first and force all lines to share it.

Generated/refined key: B. Near-vertical lines cause problems for slope-intercept parameters. Normal form uses angle and perpendicular distance and avoids an unbounded slope. [6b0bc2554460:p19] [6b0bc2554460:p42]

[6b0bc2554460:p19 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0019.png>)
[6b0bc2554460:p42 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0042.png>)

## Quiz item 3

An edge map contains clutter, occluded object fragments and noisy measurements. Which set of model-fitting difficulties does the lecture identify?

A. Only the choice of intercept; testing subsets is independent of the number of points.
B. Extraneous data, missing data, noise and combinatorial cost.
C. Only inaccurate parameter bins; the set of edge points is otherwise sufficient.
D. Only missing data; points from other objects do not affect model selection.

Generated/refined key: B. The lecture explicitly lists extraneous data, missing data, noise and combinatorial cost. A scene with clutter and occlusion can exhibit these together. [6b0bc2554460:p22]

[6b0bc2554460:p22 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0022.png>)

## Quiz item 4

Additional teaching application: using rho=x*cos(theta)+y*sin(theta), what curve does the image point (0,2) vote along?

A. rho=sin(theta)+2
B. rho=2 for every theta
C. rho=2*cos(theta)
D. rho=2*sin(theta)

Generated/refined key: D. Substituting x=0 and y=2 gives rho=2*sin(theta). This new example applies the lecture normal form and its point-to-sinusoid mapping. [6b0bc2554460:p26] [6b0bc2554460:p44]

[6b0bc2554460:p26 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0026.png>)
[6b0bc2554460:p44 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0044.png>)

## Quiz item 5

Why is normal form convenient when building a line Hough accumulator for a finite image?

A. It offers bounded angle/distance ranges while slope and intercept can be unbounded.
B. It makes the vote peak independent of the selected bin widths.
C. It replaces edge locations with edge intensity values as the only parameters.
D. It assigns one vote to each image point without testing parameter values.

Generated/refined key: A. The lecture contrasts unbounded slope/intercept parameters with bounded angle and distance ranges. A practical slope-intercept accumulator would require additional restrictions. [6b0bc2554460:p41] [6b0bc2554460:p42]

[6b0bc2554460:p41 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0041.png>)
[6b0bc2554460:p42 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0042.png>)

## Quiz item 6

As measurement noise increases, which accumulator change matches the lecture plots?

A. The correct-bin peak grows because each noisy point supplies more matching votes.
B. The correct-bin peak remains unchanged while only image-space positions move.
C. The correct-bin peak falls and more votes can appear in wrong bins.
D. The correct-bin peak moves to a radius dimension even for line detection.

Generated/refined key: C. The noise plots show fewer votes in the right bin and more spurious votes in wrong bins as measurements become noisy. [6b0bc2554460:p67] [6b0bc2554460:p68]

[6b0bc2554460:p67 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0067.png>)
[6b0bc2554460:p68 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0068.png>)

## Quiz item 7

A circle detector must estimate both center coordinates and an unknown radius. What accumulator parameter space does the lecture require?

A. A 2D accumulator over theta and rho.
B. A 1D accumulator over r, with the center implicit in each edge point.
C. A 2D accumulator over a and b with one fixed global radius.
D. A 3D accumulator over a, b and r.

Generated/refined key: D. Unknown-radius circles require the center coordinates and radius as three parameters, represented by A(a,b,r). [6b0bc2554460:p77]

[6b0bc2554460:p77 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0077.png>)

## Quiz item 8

Additional teaching application: use the lecture convention a=x-r*cos(phi), b=y-r*sin(phi). For (x,y)=(5,3), r=2 and phi=0, which center bin receives the vote?

A. (5,1)
B. (3,1)
C. (3,3)
D. (7,3)

Generated/refined key: C. Using the stated convention gives a=5-2*1=3 and b=3-2*0=3. The other options reverse the sign, swap direction axes, or subtract r from both coordinates. This is a new worked example using the original slide formula. [6b0bc2554460:p78]

[6b0bc2554460:p78 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0078.png>)

## full_lecture_noise

Question: According to the lecture's noise plot, what happens to votes in the correct bin as measurement noise increases? Answer qualitatively without inventing numeric values.

Actual answer: According to the lecture plot showing the number of votes for a line with increasing noise, as measurement noise increases, the maximum number of votes in the right (correct) bin decreases.

Prewritten reference: As measurement noise increases, fewer votes fall in the correct bin; the maximum vote count for the true line decreases.

Judge context track: raw_extracted_text

[6b0bc2554460:p68 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0068.png>)
[6b0bc2554460:p67 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0067.png>)
[6b0bc2554460:p38 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0038.png>)

## suite_edge_voting

Question: According to this lecture, what is the key idea of the Hough transform? State only what edges do for possible models, without extra examples.

Actual answer: According to the lecture, the key idea of the Hough transform is that edges vote for the possible models.

Prewritten reference: Edges vote for the possible models.

Judge context track: raw_extracted_text

[6b0bc2554460:p28 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0028.png>)
[6b0bc2554460:p22 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0022.png>)
[6b0bc2554460:p38 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0038.png>)

## suite_unknown_radius

Question: According to the lecture, how many dimensions does circle Hough space require when the radius is unknown, and what accumulator parameters are used? Keep the answer to that point.

Actual answer: When the radius is unknown, circle Hough space requires 3 dimensions and uses an accumulator array A(a,b,r).

Prewritten reference: An unknown circle radius requires a three-dimensional accumulator over the two center coordinates and the radius, A(a,b,r).

Judge context track: original_text_plus_assistant_source_image_transcription

[6b0bc2554460:p77 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0077.png>)
[6b0bc2554460:p41 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0041.png>)
[6b0bc2554460:p40 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0040.png>)

## suite_gradient_vote

Question: According to the lecture's gradient-information slide, when the circle radius is known and gradient information is used, how many points in the accumulator need to be incremented? Answer without equations or additional derivations.

Actual answer: Only one point in the accumulator needs to be incremented.

Prewritten reference: Only one point in the accumulator needs to be incremented.

Judge context track: raw_extracted_text

[6b0bc2554460:p78 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0078.png>)
[6b0bc2554460:p41 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0041.png>)
[6b0bc2554460:p40 — original page image](<D:/Graduation Project/SmartCampus/vscode/run/cache/d2ed44c68345d2b0/page_0040.png>)
