# Full-lecture study materials

iot lecture for testing.pdf

Processing coverage: 50/50 pages. This is not an accuracy score.

Page notes and transcriptions are model-generated drafts; original page images remain authoritative.

## Section 1: Internet-of-Things (IoT) Course Overview

### Course Introduction and Fundamentals

Week 1 introduces foundational Internet-of-Things (IoT) concepts and practical programming using Python with a Raspberry Pi board in the laboratory.
Sources: 459b7e3bbded:p2

### Smart Objects and Sensing

Week 2 covers smart objects, user interfaces, sensing, and actuation, paired with hands-on lab work on sensor programming, control loops, and digital/analog I/O.
Sources: 459b7e3bbded:p2

### Computer and Wireless Networks

Week 3 explores computer and wireless network fundamentals, including Wi-Fi and Bluetooth networks and practical network measurements.
Sources: 459b7e3bbded:p2

### Sensor and Mesh Networks

Week 4 focuses on sensor networks, mesh networks, routing, and wireless personal area networks (WPANs/WBANs), featuring ZigBee and network measurements.
Sources: 459b7e3bbded:p2

### IoT Cloud, Analytics, and Ecosystems

Week 5 addresses data processing, cloud integration, sensor fusion, analytics, and visualization. Week 6 concludes with security, privacy, ethics, trends, and the final project.
Sources: 459b7e3bbded:p2

#### 459b7e3bbded:p1 (administrative)

Title slide for the Internet-of-Things (IoT) course (CSCI410) at Nile University, School of Information Technology and Computer Science.

CSCI410
Nile University- School of Information Technology and Computer Science
Internet-of-Things (IoT)

#### 459b7e3bbded:p2 (content)

Course overview table outlining lecture and lab topics across six weeks, covering IoT fundamentals, smart objects, wireless networks, sensor networks, cloud processing, and the IoT ecosystem.

Course Overview
Week 1 | Lecture: Fundamentals of IoT, basic concepts, applications | Lab: Basic Python programming, meet your Raspberry Pi
Week 2 | Lecture: Smart objects, user interfaces, sensing, actuation | Lab: Sensor programming, control loops, digital/analog I/O
Week 3 | Lecture: Fundamentals of computer and wireless networks | Lab: Wi-Fi and Bluetooth networks, network measurements
Week 4 | Lecture: Sensor networks, mesh networks, routing, WPANs | Lab: ZigBee, WPANs, WBANs, routing, network measurements
Week 5 | Lecture: Processing, IoT cloud, analytics, visualization | Lab: IoT cloud integration, sensor fusion, analytics, visualization
Week 6 | Lecture: IoT ecosystem, security, privacy, ethics, trends, case studies | Lab: Final project

## Section 3: Computer Network Terminology and Topologies

### Computer Network

A group of computers and associated devices connected together by communication facilities [459b7e3bbded:p3].
Sources: 459b7e3bbded:p3

### Network Scale Classifications

Networks are categorized by geographical scale: Wide Area Network (WAN) for world-wide connections, Metropolitan Area Network (MAN) for city-scale, and Local Area Network (LAN) for laboratory or office-scale [459b7e3bbded:p3].
Sources: 459b7e3bbded:p3

### Wireless Network Types

Wireless networks include WLAN (Wireless LAN via Wi-Fi), WPAN (Wireless Personal Area Network via Bluetooth), and WBAN (Wireless Body Area Network) [459b7e3bbded:p3].
Sources: 459b7e3bbded:p3

### Star and Bus Topologies

A star network topology connects nodes to a central hub or switch linked to the internet, whereas a common bus topology connects computers along a shared communication line [459b7e3bbded:p4].
Sources: 459b7e3bbded:p4

### Mesh and Ring Topologies

Fully connected and mesh network topologies provide multiple inter-node paths for redundancy, while ring topologies connect devices in a circular closed loop [459b7e3bbded:p4].
Sources: 459b7e3bbded:p4

#### 459b7e3bbded:p3 (content)

This slide defines basic computer network terminology, categorizing networks by scale into WAN, MAN, LAN, WLAN, WPAN, and WBAN.

Icons for network, monitor/PC, network cluster, and wireless router accompanying text entries.

#### 459b7e3bbded:p4 (content)

This slide illustrates different network topologies: Fully Connected, Common Bus, Mesh, Star, and Ring Network Topology.

Fully Connected Network Topology, Common Bus Topology, Mesh Network Topology, Star Network Topology, Ring Network Topology.

## Section 5: Network Protocols and Fundamentals

### Network Protocols

Protocols serve as the building blocks of network architecture, establishing formal standards and policies that enable communication across systems [459b7e3bbded:p5].
Sources: 459b7e3bbded:p5

### IEEE Standardization

The Institute of Electrical and Electronics Engineers (IEEE) handles network standardization, exemplified by Project 802 which includes 802.3 for Ethernet, 802.11 for WLAN, and 802.15 for WPAN [459b7e3bbded:p5].
Sources: 459b7e3bbded:p5

### IP Addressing Fundamentals

Part 1 Fundamentals introduces core addressing questions, specifically how to determine the network address and host address when given an IP address [459b7e3bbded:p6].
Sources: 459b7e3bbded:p6

#### 459b7e3bbded:p5 (content)

Overview of network protocols as building blocks of network architecture, formal communication standards, and IEEE standardization examples such as Project 802.3 (Ethernet), 802.11 (WLAN), and 802.15 (WPAN).

Icons for computer, speech bubbles, and router. Text: Network Protocols, building blocks of a network architecture, formal standards and policies enabling communication, IEEE (Institute of Electrical and Electronics Engineers): standardization, Example: Project 802, 802.3: Ethernet, 802.11: WLAN, 802.15: WPAN

#### 459b7e3bbded:p6 (content)

Introduction to Part 1 Fundamentals, featuring an activity question on how to determine the network address and host address given an IP address.

Part 1 (Fundamentals) Link
Activities:
Given an IP address, how can we determine the network address and the host address?

## Section 7: Network Fundamentals and OSI Layers 3-7

### Home Network Setup with a Switch

Investigates whether a functional local network can be created using solely a network switch, and how two PCs communicate over it using protocols such as SSH [459b7e3bbded:p7].
Sources: 459b7e3bbded:p7

### Inter-Network Routing and Gateway IP

Focuses on the mechanism of sending data packets between two distinct networks and how a host determines its network gateway IP address [459b7e3bbded:p7].
Sources: 459b7e3bbded:p7

### OSI Layers 3-7 Network Boundary Detection

Addresses how a host (PC1) determines whether a destination address (PC2) resides outside its local network segment using OSI layer principles [459b7e3bbded:p8].
Sources: 459b7e3bbded:p8

### Internet Routing and Local IP Addresses

Examines how internet routers route packets and handle local private IP addresses when a client communicates with an external internet server [459b7e3bbded:p8].
Sources: 459b7e3bbded:p8

#### 459b7e3bbded:p7 (content)

Covers Part 2 Fundamentals, introducing activities on setting up home networks with switches, PC-to-PC communication using SSH, inter-network packet routing, and identifying network gateway IP addresses.

Part 2 (Fundamentals) Link
Activities:
- Is it possible to set up a home network using only a switch?
  - How can two PCs communicate with each other using Ex:SSH?
- How to send data packet between two different networks? Given
- How to know your network Gateway ip address? Given

#### 459b7e3bbded:p8 (content)

Covers Part 2-2 (OSI Layers 3-7) with activities exploring how a PC determines if a destination address is outside its current local network, and how internet routers handle local IP addresses when communicating with internet servers.

Part 2-2 (OSB Layers 3-7) Link
Activity:
PC1 want sent send data to a destination PC2 how PC1 know that this address is out of my current network? Link
Activity:
- PC1 wants to send data to a server on the internet. Given, If the local IP address of PC1 is included in the packet sent to the server, and the server responds with the source address as PC1's IP, how do the internet routers know the local IP address of PC1? Answer

## Section 9: HTTP Requests and TCP Connections Lecture Section

### HTTP GET Request via Telnet

Demonstrates inspecting and interacting with web servers directly using telnet to connect to a target host on port 80 and issuing a GET command for a specific resource like /index.html.
Sources: 459b7e3bbded:p9

### Network Configuration Diagnostics

Involves using tools like ping and ifconfig to determine network properties such as the IP address, DNS server being used, and routing paths.
Sources: 459b7e3bbded:p9

### TCP Connection Management

Encompasses the lifecycle stages of a TCP connection, specifically noting connection initialization, connection closing, and connection resets.
Sources: 459b7e3bbded:p10

### TCP Flow Control and Window Size

Covers mechanism details such as window size configurations, error handling, and flow control to manage data transmission rates between sender and receiver.
Sources: 459b7e3bbded:p10

#### 459b7e3bbded:p9 (content)

This page covers Part 3, focusing on understanding HTTP GET requests using tools like telnet to connect to www.httpforever.com on port 80, along with network inspection concepts like ping, ifconfig, and SSH examples.

Part 3 (understand HTTP GET request) Link
• Inespect: www.httpforever.com
ping:
• Ifconfig
  o What is the ip address
    what is the dns server used
    what is the rout
• EX: telnet www.httpforever.com 80
  GET /index.html
• Example: of SSH to PC to RP device

Uncertainty: Spelling error 'Inespect' in slide text.

#### 459b7e3bbded:p10 (content)

This page lists various TCP protocol topics including headers, acknowledgments, error handling, window size, flow control, bidirectional transfer, connection initialization, connection close, and connection reset.

oheads and Acq) Link
▪Header data Link
▪Acq Link
▪Error Handling Link
▪Delayed Ack Link
Windows Size: Link
Flow Control: Link
▪Bidirectional transfare: Link
TCP Connection intialization: Link
TCP connection close: LInk
TCP Connection reset: Link

Uncertainty: Spelling errors 'oheads', 'transfare', and 'intialization' in slide text.

## Section 11: UDP vs TCP and TLS/SSL Lecture Section

### TCP vs UDP Comparison

Part 5 introduces a comparison between UDP and TCP, highlighting connection-oriented design, reliability, flow control, and protocol overheads [459b7e3bbded:p11].
Sources: 459b7e3bbded:p11

### TLS/SSL Security Fundamentals

TLS/SSL protocols provide data protection mechanisms including anti-repudiation, non-repudiation, key players management, and certificate authorities [459b7e3bbded:p12].
Sources: 459b7e3bbded:p12

#### 459b7e3bbded:p11 (content)

Overview slide outlining Part 5 comparing UDP and TCP, covering connection-oriented communication, reliability, flow control, overheads, and four common myths.

Part 5 (UDP vs TCP) Link
Connection oriented
Reliable
• Flow Conrol
• Over Heads
• 4 Myths

#### 459b7e3bbded:p12 (content)

Outline slide for TLS/SSL security concepts, covering data protection, anti-replay, non-repudiation, key players, and certificate authorities.

TLS/SSL
Security SSL/TLS Link
Part2 : Link
How do SSL/TLS protect data: Link
Anti-Replay: Link
Non-Repudiation: Link
KeyPlayers: Link
Certificate Authority: LInk

## Section 13: Communication and Protocols Lecture

### Communication Rules

Communication requires structured rules determining initiation, turn order, duration, volume, framing phrases, metadata, and error handling for interruptions or misunderstandings [459b7e3bbded:p13].
Sources: 459b7e3bbded:p13

### Protocols in Communication

Protocols govern how entities exchange messages over time, whether human conversationalists greeting and asking for the time or computers executing TCP connection requests and HTTP file retrievals [459b7e3bbded:p14].
Sources: 459b7e3bbded:p14

#### 459b7e3bbded:p13 (content)

This slide outlines fundamental questions regarding communication rules, such as initiation, turn-taking order, message constraints, formatting, metadata, and handling interruptions or misunderstandings.

Communication
Who initiates communication?
Order of communication?
How long can I talk?
How loud can I speak?
Do I have to say something specific at beginning or end?
Do I have to add meta information?
What do I do if I get interrupted?
What do I do if I was not understood?

#### 459b7e3bbded:p14 (content)

This slide compares human conversation protocols with computer network protocols, illustrating message exchanges over time between humans and between computer systems.

Protocols
Hi
Hi
Got the time?
2:00
TCP connection request
TCP connection response
Get http://www.awl.com/kurose-ross
<file>
time

## Section 15: Client/Server Model

### Client Role in Client/Server Model

The client is described as active because it initiates communication by sending requests to the server [459b7e3bbded:p15].
Sources: 459b7e3bbded:p15

### Server Role in Client/Server Model

The server is described as passive because it listens for incoming communications and responds to client requests [459b7e3bbded:p15].
Sources: 459b7e3bbded:p15

### HTTP Protocol Example

HTTP (Hypertext Transfer Protocol) is presented as a primary example of the client/server model [459b7e3bbded:p16].
Sources: 459b7e3bbded:p16

### DNS Protocol Example

DNS (Domain Name System) serves as an example application utilizing the client/server architecture [459b7e3bbded:p16].
Sources: 459b7e3bbded:p16

#### 459b7e3bbded:p15 (content)

This slide introduces the Client/Server Model, defining the client as active (initiating communication via requests) and the server as passive (listening and responding).

Diagram showing 'Client' sending a dashed arrow labeled 'request' to 'Server', and 'Server' returning a dashed arrow labeled 'response' to 'Client'.

#### 459b7e3bbded:p16 (content)

This slide lists common examples of the Client/Server model arranged in a circular diagram: HTTP, SMTP, SSH, DNS, and NFS/AFS.

Circular segmented diagram with arrows connecting sections for HTTP (Hypertext Transfer Protocol), SMTP (Simple Mail Transfer Protocol), SSH (Secure Shell), DNS (Domain Name System), and NFS/AFS (Network/Andrew File System).

## Section 17: Network Protocols: Protocol Stack, Headers, and Trailers

### OSI Protocol Stack

A conceptual model structuring network architecture into seven distinct layers: Application, Presentation, Session, Transport, Network, Data Link, and Physical, enabling modular communication between systems [459b7e3bbded:p17].
Sources: 459b7e3bbded:p17

### Data Encapsulation

The process where each layer of the protocol stack adds its own control information—such as headers (ah, ph, sh, th, nh, dh) or trailers (dt)—to the data received from the layer above [459b7e3bbded:p18].
Sources: 459b7e3bbded:p18

#### 459b7e3bbded:p17 (content)

This slide illustrates the OSI 7-layer protocol stack architecture showing peer-to-peer communication between two end systems across an intermediate communication network.

Layers from top to bottom: Application Layer, Presentation Layer, Session Layer, Transport Layer, Network Layer, Data Link Layer, Physical Layer. Communication Network label encloses intermediate Network, Data Link, and Physical layers. Figure 2.6 Copyright (c)2000 The McGraw Hill Companies.

#### 459b7e3bbded:p18 (content)

This slide shows how headers and trailers are encapsulated onto data as it descends the protocol stack from Application A to Application B, culminating in a bitstream.

Data encapsulation sequence downwards: data, data+ah, data+ph, data+sh, data+th, data+nh, dt+data+dh, bits.

## Section 19: Layered Design and Open System Interconnection (OSI)

### Benefits of Layered Design

Layered design provides an explicit structure for dealing with complex systems, simplifies the design process, offers modularity that eases maintenance and updating of components, and accommodates incremental changes [459b7e3bbded:p19].
Sources: 459b7e3bbded:p19

### OSI Upper Layers (Layers 5-7)

Layers 5 through 7 of the OSI model comprise the Session Layer (authentication, permissions, session restoration), Presentation Layer (coding into 1s and 0s, encryption, compression), and Application Layer (message format, Human-Machine Interfaces) [459b7e3bbded:p20].
Sources: 459b7e3bbded:p20

### OSI Transport Service Layers (Layers 1-4)

Layers 1 through 4 of the OSI model form the transport service and include the Physical Layer, Data Link Layer, Network Layer, and Transport Layer [459b7e3bbded:p20].
Sources: 459b7e3bbded:p20

#### 459b7e3bbded:p19 (content)

Explains why layered design is used in systems: it provides explicit structure for complexity, simplifies design, eases maintenance and updating through modularity, and accommodates incremental changes.

Icons next to each point: hierarchy tree, document, two gears, checkmark.

#### 459b7e3bbded:p20 (content)

Presents the 7-layer Open System Interconnection (OSI) model, dividing layers 5-7 as UPPER LAYERS and layers 1-4 as TRANSPORT SERVICE.

Layers 7 to 1:
7 Application Layer - Message format, Human-Machine Interfaces
6 Presentation Layer - Coding into 1s and 0s; encryption, compression
5 Session Layer - Authentication, permissions, session restoration
4 Transport Layer - End-to-end error control
3 Network Layer - Network addressing; routing or switching
2 Data Link Layer - Error detection, flow control on physical link
1 Physical Layer - Bit stream: physical medium, method of representing bits
Brackets on left: UPPER LAYERS (7-5), TRANSPORT SERVICE (4-1).

## Section 21: Physical Layer and Wireless Characteristics

### Physical Layer (Layer 1)

The physical layer defines the physical and electrical characteristics of the network, including cable types, lengths, connectors, voltage levels, signal durations, and frequencies for wireless communication [459b7e3bbded:p21].
Sources: 459b7e3bbded:p21

### Binary Data Transmission

Binary data represented as bits are transmitted across the physical medium as electrical or optical signals [459b7e3bbded:p21].
Sources: 459b7e3bbded:p21

### Wavelength and Frequency Relation

Wavelength (lambda) and frequency (f) are inversely related by the equation lambda = c/f, where c is the speed of light, approximately 3x10^8 m/s [459b7e3bbded:p22].
Sources: 459b7e3bbded:p22

### Wireless Frequency Bands

Wireless spectrum bands span from Very Low Frequency (VLF, 300 Hz, 1 Mm) up to Ultra High Frequency (UHF), Super High Frequency (SHF), Extra High Frequency (EHF), infrared, visible light, and Ultraviolet (UV) light [459b7e3bbded:p22].
Sources: 459b7e3bbded:p22

#### 459b7e3bbded:p21 (content)

Overview of the Physical Layer (Layer 1), highlighting physical and electrical characteristics, cable details, binary data representation as electrical/optical signals, and wireless frequencies.

Icons corresponding to warning/electrical, worker with plug, CPU/chip, and wireless signal waves accompanying the text.

#### 459b7e3bbded:p22 (content)

Defines wireless frequency band abbreviations, the relationship between wavelength lambda and frequency f (lambda = c/f), and displays a frequency spectrum allocation chart.

Formula: lambda = c/f. Constants: speed of light c approximately 3x10^8 m/s. Spectrum chart mapping bands from VLF (300 Hz, 1 Mm) to UV.

## Section 23: Frequencies and Propagation Effects for Mobile Communication

### Low Frequencies in Mobile Communication

Low frequencies offer low data rates, travel long distances, follow the Earth's surface, and can penetrate objects and water such as in submarine communication [459b7e3bbded:p23].
Sources: 459b7e3bbded:p23

### High Frequencies and Line of Sight (LOS)

High frequencies provide high data rates over short distances, travel in straight lines, and cannot penetrate objects, requiring Line of Sight (LOS) [459b7e3bbded:p23].
Sources: 459b7e3bbded:p23

### Reflection and Refraction

Reflection occurs at large obstacles, while refraction depends on the varying density of a medium through which the signal travels [459b7e3bbded:p24].
Sources: 459b7e3bbded:p24

### Scattering and Diffraction

Scattering takes place at small obstacles dispersing the wave, whereas diffraction occurs at sharp edges allowing waves to bend around obstacles [459b7e3bbded:p24].
Sources: 459b7e3bbded:p24

#### 459b7e3bbded:p23 (content)

Compares characteristics of low and high frequencies in mobile communication, highlighting differences in data rates, travel distance, and object penetration.

Two antenna towers with a brick wall obstacle between them.

#### 459b7e3bbded:p24 (content)

Lists other signal propagation effects including shadowing, reflection, refraction, scattering, and diffraction, accompanied by illustrative icons.

Icons labeled: shadowing, reflection, refraction, scattering, diffraction.

## Section 25: Multipath Propagation and Real World Examples

### Multipath Propagation

Signal can take many different paths between sender and receiver due to reflection, scattering, and diffraction [459b7e3bbded:p26].
Sources: 459b7e3bbded:p26

### Delay Spread

The dispersion of signal arrival times at the receiver caused by multiple propagation paths (LOS pulses versus multipath pulses) arriving with varying delays [459b7e3bbded:p26].
Sources: 459b7e3bbded:p26

#### 459b7e3bbded:p25 (content)

Visualizations of real-world radio propagation scenarios, including Central Munich, an indoor floor plan layout, and an outdoor terrain profile.

Labels: Central Munich, 20 m, 13.60 m, 123 km, 1450 m

#### 459b7e3bbded:p26 (content)

Illustration of multipath propagation where signals take multiple routes between a sender and receiver due to reflection, scattering, and diffraction, causing delay spread at the receiver.

Labels: signal at sender, STOP, Delay Spread, LOS pulses, multipath pulses, signal at receiver

## Section 27: Digital Modulation and Data Link Layer

### Amplitude Shift Keying (ASK)

A digital modulation scheme that is very simple and has low bandwidth requirements, but is very susceptible to interference.
Sources: 459b7e3bbded:p27

### Frequency Shift Keying (FSK)

A digital modulation technique that requires a larger bandwidth compared to simple ASK methods.
Sources: 459b7e3bbded:p27

### Phase Shift Keying (PSK)

A digital modulation method that is more complex than ASK and FSK, but offers strong robustness against interference.
Sources: 459b7e3bbded:p27

### Data Link Layer (Layer 2)

Defines when and how the medium will be accessed for transmission. Its data units are typically called frames and it handles error detection and correction.
Sources: 459b7e3bbded:p28

### Medium Access Control (MAC) and Multiple Access

Sublayer of Layer 2 including MAC addresses (e.g., 6f:00:2b:23:1f:32) and access techniques like FDMA, TDMA, and CDMA demonstrated via cell phone examples.
Sources: 459b7e3bbded:p28

#### 459b7e3bbded:p27 (content)

Covers digital modulation techniques including Amplitude Shift Keying (ASK), Frequency Shift Keying (FSK), and Phase Shift Keying (PSK), outlining their complexity, bandwidth requirements, and interference susceptibility alongside waveform diagrams.

Waveform diagrams labeled with bit sequences 1, 0, 1 and time axis t for ASK, FSK, and PSK.

#### 459b7e3bbded:p28 (content)

Introduces the Data Link Layer (Layer 2), covering medium access control (MAC), frames, error detection, and multiple access techniques (FDMA, TDMA, CDMA) illustrated with a cell phone example.

Diagrams for FDMA (Frequency Division Multiple Access with f1, f2, f3), TDMA (Time Division Multiple Access with time slots 1, 2, 3), and CDMA (Code Division Multiple Access with spread code 1, 2, 3). MAC address: 6f:00:2b:23:1f:32.

## Section 29: Ethernet and CSMA/CD Protocol

### Ethernet Bus Architecture

Ethernet (802.3) is a popular local area network (LAN) technology that utilizes a bus architecture. It is designed to be inexpensive and easy to install, operating by breaking data down into packets for transmission across shared segments [459b7e3bbded:p29].
Sources: 459b7e3bbded:p29

### Medium Access Control (MAC) in Ethernet

Ethernet relies on a Medium Access Control (MAC) protocol to manage how multiple devices share and access the communication medium without interfering with one another [459b7e3bbded:p30].
Sources: 459b7e3bbded:p30

### CSMA/CD Protocol

The CSMA/CD protocol used in Ethernet stands for Carrier Sense, Multiple Access, and Collision Detection. It allows multiple nodes to access the shared channel while sensing the carrier and detecting any collisions that occur when simultaneous transmissions happen [459b7e3bbded:p30].
Sources: 459b7e3bbded:p30

#### 459b7e3bbded:p29 (content)

Introduction to Ethernet (802.3) as a popular, inexpensive LAN technology that uses a bus architecture and breaks data into packets.

Ethernet bus segment (labeled twice for two segments connected by a device)

#### 459b7e3bbded:p30 (content)

Overview of the Ethernet MAC protocol, specifically CSMA/CD, highlighting carrier sense, multiple access, and collision detection with a diagram showing nodes A, B, C and a collision burst.

Nodes labeled A, B, C connected to a shared bus; arrows showing transmission directions; a jagged red burst labeled 'collision'.

## Section 31: Ethernet and Wi-Fi Networks

### Carrier Sensing in Ethernet

Ethernet nodes listen to the carrier before transmitting. If the channel is sensed as busy, the node waits; if idle, it transmits data [459b7e3bbded:p31].
Sources: 459b7e3bbded:p31

### Collision Detection (CD)

Nodes continue listening while transmitting to detect if a collision occurs. If a collision is detected, transmission stops and the node retries at a later time [459b7e3bbded:p31].
Sources: 459b7e3bbded:p31

### Wi-Fi (802.11) Architecture

Wi-Fi is the most popular wireless local area network architecture, functioning via wireless links between client computers and a central access point, base station, router, or hotspot [459b7e3bbded:p32].
Sources: 459b7e3bbded:p32

#### 459b7e3bbded:p31 (content)

Explains Ethernet carrier sensing and collision detection. Nodes listen before transmitting, wait if busy, transmit if idle, and continue listening to detect collisions for later retries.

Nodes labeled A, B, C connected by a shared bus. Node B has a thought bubble saying 'Don't transmit'. An arrow indicates data flow from node A, and a text box asks 'Can collisions still occur?'

#### 459b7e3bbded:p32 (content)

Introduces Wi-Fi (802.11) as the most popular wireless LAN architecture, featuring computers connected wirelessly to a central access point, base station, or router.

Diagram showing multiple computers connected via wireless lightning-bolt links to a central 'Access Point'. Text labels list: Access point, Wi-Fi router, Base station, Hotspot.

## Section 33: Wi-Fi CSMA/CA Protocol and Network Layer IP Addressing

### CSMA/CA Protocol

Carrier Sense Multiple Access with Collision Avoidance is used in Wi-Fi (802.11) networks. It utilizes channel reservations via Request-to-Send (RTS) and Clear-to-Send (CTS) packets so that neighboring nodes hearing them keep quiet, minimizing collision overhead to small control packets [459b7e3bbded:p33].
Sources: 459b7e3bbded:p33

### Network Layer and IP

Layer 3 handles addressing and routing for sender and receiver IP addresses using the Internet Protocol as its dominant protocol [459b7e3bbded:p34].
Sources: 459b7e3bbded:p34

### IPv4 Hierarchical Addressing

IPv4 uses a 32-bit hierarchical address space spanning 4 bytes with embedded location information structured into a Network ID and a Host ID, typically expressed in dotted-decimal notation such as 128.100.11.56 [459b7e3bbded:p34].
Sources: 459b7e3bbded:p34

#### 459b7e3bbded:p33 (content)

This slide introduces the Wi-Fi (802.11) CSMA/CA protocol, detailing channel reservations using Request-to-Send (RTS) and Clear-to-Send (CTS) packets to avoid collisions, along with a collision diagram involving nodes A, B, and C.

Diagram showing nodes A, B, and C with dashed transmission ranges intersecting, and a 'Collision' burst cloud above node B.

#### 459b7e3bbded:p34 (content)

This slide introduces the Network Layer (Layer 3) and the dominant IP protocol, explaining 32-bit hierarchical address spaces split into Network ID and Host ID across 4 bytes, commonly written in dotted-decimal notation like 128.100.11.56.

A box diagram labeled 'Network ID' and yellow-highlighted 'Host ID', spanning 4 bytes with a double-ended arrow below.

## Section 35: IPv4 and Network Protocols Lecture Section

### CIDR Notation

Classless Inter-Domain Routing (CIDR) notation replaces traditional subnet masks by appending a slash and the number of bits allocated to the network portion (e.g., /24), simplifying IPv4 address representation [459b7e3bbded:p35].
Sources: 459b7e3bbded:p35

### IPv4 Address Classes

IPv4 addresses are historically divided into classes (Class A, B, and C) defined by leading bit patterns, which determine the split between network and host portions as well as their default subnet masks [459b7e3bbded:p35]. Note: the slide diagram contains a slight spelling typo ('Netwok') [459b7e3bbded:p35].
Sources: 459b7e3bbded:p35

### Protocol Stack

The protocol stack organizes communication functions into hierarchical layers—from the physical layer up to the application layer—allowing modular data transmission and peer communication across a network [459b7e3bbded:p36].
Sources: 459b7e3bbded:p36

#### 459b7e3bbded:p35 (content)

This slide explains IPv4 addressing classes (A, B, C) with their subnet masks and introduces CIDR notation as a compact alternative to full subnet masks.

No. Bits: 7, 24, 14, 16, 21, 8. Class A: 0, Network, Host, Host, Host. Subnet Mask Class A: Netwok (255), Host (0), Host (0), Host (0). Class B: 10, Network, Network, Host, Host. Subnet Mask Class B: Netwok (255), Network (255), Host (0), Host (0). Class C: 110, Network, Network, Network, Host. Subnet Mask Class C: Netwok (255), Network (255), Network (255), Host (0). www.smartPCtricks.com

#### 459b7e3bbded:p36 (content)

This slide illustrates the OSI 7-layer network protocol stack architecture, showing peer-to-peer layer communication across a communication network involving intermediate routing nodes.

Network Protocols ("Protocol Stack"). Application Layer, Presentation Layer, Session Layer, Transport Layer, Network Layer, Data Link Layer, Physical Layer. Communication Network. Figure 2.6 Copyright (c) 2000 The McGraw Hill Companies

## Section 37: Network Protocols and Routers

### OSI Model and TCP/IP Protocol Stack

The 7-layer OSI model structures network architecture from physical cabling up to application services, while TCP/IP groups these into corresponding operational layers for internet communications.
Sources: 459b7e3bbded:p37

### Routers and Routing Tables

Routers form the backbone of the Internet, using the IP layer to identify packet sources and destinations and consulting routing tables to determine the appropriate next hop.
Sources: 459b7e3bbded:p38

### Network Diagnostic Commands

Tools like ping, traceroute, and mtr allow administrators to test connectivity, measure round-trip times, and trace the path packets take across multiple routers.
Sources: 459b7e3bbded:p38

### DNS Lookup Utilities

The nslookup command queries DNS servers to translate human-readable domain names like www.google.com into corresponding machine-readable IP addresses.
Sources: 459b7e3bbded:p38

### Resolv Configuration

The active DNS server configuration on Unix-like systems can be queried from configuration files using commands such as grep "nameserver" /etc/resolv.conf.
Sources: 459b7e3bbded:p38

#### 459b7e3bbded:p37 (content)

This slide illustrates the OSI model and TCP/IP protocol stack across 7 layers, mapping functions from physical electrical signals up to application-level communication.

OSI MODEL LAYERS: 7 Application, 6 Presentation, 5 Session, 4 Transport, 3 Network to Network, 2 Station to Station (Ethernet/Wi-Fi), 1 Physical (Signals, cables, antennas). TCP/IP column lists HTTP, SMTP, FTP, TCP, IP.

#### 459b7e3bbded:p38 (content)

This slide covers router functionality in the internet backbone using IP layers and routing tables, along with networking troubleshooting commands such as traceroute, ping, ifconfig, and nslookup.

Diagram showing interconnected Autonomous Systems (AS 1 to AS 5). Routing table mapping Destinations to Next Hops. Commands: Traceroute / mtr, Ping, ifconfig, nslookup www.google.com, grep "nameserver" /etc/resolv.conf

## Section 39: Transport Layer and UDP Protocols

### Transport Layer and UDP

The transport layer provides logical communication between application processes running on different hosts. UDP (User Datagram Protocol) is a connectionless transport protocol that adds port addressing to IP addresses, specifying exact applications on a computer, but remains unreliable because packets may be lost or arrive out of order [459b7e3bbded:p39].
Sources: 459b7e3bbded:p39

### Ports and Addressing

While IP addresses identify specific computers on a network, ports identify specific applications or services on that computer (such as a web server listening on port 80) [459b7e3bbded:p39].
Sources: 459b7e3bbded:p39

### UDP Header Structure

The UDP header structure consists of fields for Source Port, Destination Port, Length, and Checksum, followed immediately by the payload Data [459b7e3bbded:p39].
Sources: 459b7e3bbded:p39

### UDP Transmission Modes

UDP supports different communication patterns including Unicast (One-to-One), Broadcast (One-to-All), and Multicast (One-to-Several), facilitating flexible request-response interactions between senders and receivers [459b7e3bbded:p40].
Sources: 459b7e3bbded:p40

#### 459b7e3bbded:p39 (content)

Introduces Transport Layer 4 protocols, focusing on UDP. Explains that IP addresses identify computers while ports identify applications. Highlights that UDP is unreliable since packets can be lost or out of order, and details the UDP header fields.

UDP Header breakdown: Source Port, Destination Port, Length, Checksum, Data.

#### 459b7e3bbded:p40 (content)

Illustrates how UDP works with sender-receiver communication showing a request and multiple responses, alongside diagrams for Unicast (One-to-One), Broadcast (One-to-All), and Multicast (One-to-Several) transmission modes.

Diagram title: How User Datagram Protocol (UDP) Works. Sender and Receiver interaction showing 'Request', 'Response', 'Response', 'Response'. Transmission types below: Unicast (One-to-One), Broadcast (One-to-All), Multicast (One-to-Several).

## Section 41: Transport Layer Security: UDP Attacks

### UDP Flood Attack

Because UDP lacks a handshake process, an attacker can send numerous spoofed packets to multiple ports on a server without waiting for permission, forcing the server to respond with destination unreachable messages and overwhelming its resources [459b7e3bbded:p41].
Sources: 459b7e3bbded:p41

### DNS Amplification Attack

Datagrams containing spoofed victim IP addresses are sent to open DNS resolvers via botnets, causing resolvers to send much larger, disproportionate replies toward the victim's spoofed IP address, ultimately saturating the victim's network [459b7e3bbded:p42].
Sources: 459b7e3bbded:p42

#### 459b7e3bbded:p41 (content)

Covers UDP security vulnerabilities, focusing on UDP flood attacks where spoofed packets overwhelm a server, triggering destination unreachable messages and denying legitimate traffic.

Diagram titled 'UDP Flood Attack Example' showing an Attacker controlling multiple Bots sending 'Spoofed UDP Packets' to a Server, which sends 'Destination Unreachable Messages' and 'Legitimate Traffic' to a User.

#### 459b7e3bbded:p42 (content)

Describes DNS amplification attacks where bots send spoofed requests with the victim's IP address to open resolvers, saturating the victim's network with disproportionately large responses.

Diagram titled 'DNS Amplification Attack Example' showing an Attacker controlling Bots sending 'Spoofed Requests' to Servers, which send 'Large Responses' to a Victim.

## Section 43: Transport Layer Security and Protocols

### UDP Port Scan

An attacker sends datagrams to a server's ports. A 'Destination unreachable' reply indicates a closed port, whereas no response indicates an open port that can be exploited [459b7e3bbded:p43].
Sources: 459b7e3bbded:p43

### TCP Handshake

A connection establishment process in TCP communication between a sender and receiver involving three sequential message steps: SYN, SYN ACK, and ACK [459b7e3bbded:p44].
Sources: 459b7e3bbded:p44

### UDP Communication

A connectionless transport layer communication method where requests and responses are exchanged directly between a sender and receiver without a preliminary handshake [459b7e3bbded:p44].
Sources: 459b7e3bbded:p44

#### 459b7e3bbded:p43 (content)

This page explains UDP port scanning security risks. Attackers send datagrams to probe open ports; a 'Destination unreachable' reply indicates a closed port, while no response suggests an open, vulnerable port ready for exploitation.

Diagram title: UDP Port Scan. Closed Port section shows Attacker sending Datagram to Server, Server replying with Destination Unreachable. Open Port section shows Attacker sending Datagram, No Response, followed by Attack!

#### 459b7e3bbded:p44 (content)

This page compares TCP vs UDP communication methods. It illustrates the three-way TCP handshake (SYN, SYN ACK, ACK) between a Sender and Receiver compared to UDP message exchange.

Title: TCP vs UDP Communication. Left box: TCP HANDSHAKE showing Sender, Receiver, arrows for SYN, SYN ACK, ACK. Right box: UDP showing Sender, Receiver, REQUEST and RESPONSE arrows.

## Section 45: Transport Layer: TCP and UDP

### Transmission Control Protocol (TCP)

A reliable transport layer protocol that provides in-order packet delivery using sequence numbers, reliable delivery via acknowledgment (ACK) packets, and flow and congestion control [459b7e3bbded:p45].
Sources: 459b7e3bbded:p45

### TCP Reliability and Control

TCP ensures that receivers do not lose data or suffer from out-of-order arrivals by using acknowledgments and sequence numbers, while flow and congestion control allow receivers and the network to slow down the sender [459b7e3bbded:p45].
Sources: 459b7e3bbded:p45

### User Datagram Protocol (UDP)

A faster transport protocol that omits flow and congestion control and retransmissions, making it suitable for real-time traffic where occasional data loss or out-of-order arrival is acceptable [459b7e3bbded:p46].
Sources: 459b7e3bbded:p46

### TCP Application Use Cases

TCP is the typical choice for applications where data loss and out-of-order arrival must be prevented, such as email, web traffic, and financial transactions [459b7e3bbded:p46].
Sources: 459b7e3bbded:p46

### UDP Application Use Cases

UDP is advantageous for real-time traffic like video or audio streams, where missing frames or out-of-order arrival can be handled or tolerated at the application level [459b7e3bbded:p46].
Sources: 459b7e3bbded:p46

#### 459b7e3bbded:p45 (content)

Introduces the TCP transport layer protocol, emphasizing its reliability features such as sequence numbers for in-order delivery, acknowledgement packets, and flow and congestion control mechanisms.

Two blue boxes representing communicating entities with two arrows between them; top arrow labeled 'Packet' pointing right, bottom arrow labeled 'ACK' pointing left.

#### 459b7e3bbded:p46 (content)

Compares TCP and UDP protocols, highlighting that TCP is reliable and used for applications like web traffic, while UDP is faster, lacks flow control and retransmissions, and suits real-time traffic.

Icons above the headers: a server stack icon above 'TCP:' and a microchip/processor icon above 'UDP:'.

## Section 47: Upper Layers of the Network Model

### Session Layer

The session layer (Layer 5) is responsible for the management of sessions between applications, controlling dialogues and connections [459b7e3bbded:p47].
Sources: 459b7e3bbded:p47

### Presentation Layer

The presentation layer (Layer 6) handles data translation, formatting, encryption, and compression to ensure data sent from the application layer of one system can be read by another [459b7e3bbded:p47].
Sources: 459b7e3bbded:p47

### Application Layer

The application layer (Layer 7) serves as the direct interface between user applications and lower network services [459b7e3bbded:p47].
Sources: 459b7e3bbded:p47

### HTTP Client-Server Interaction

An example of upper layer network usage is web servers where an HTTP client sends a request to an HTTP server and receives a response in return [459b7e3bbded:p48].
Sources: 459b7e3bbded:p48

#### 459b7e3bbded:p47 (content)

Overview of the upper layers (Layers 5-7) in networking, defining the Session Layer, Presentation Layer, and Application Layer along with their core management, translation, and interface responsibilities.

Upper Layers (Layers 5-7)
Session Layer
• Management of "sessions"
Presentation Layer
• Data translation, formatting, encryption, compression
Application Layer
• Interface between user applications and lower network services

#### 459b7e3bbded:p48 (content)

An example of web servers illustrating the client-server interaction via HTTP, showing a bidirectional communication line with a Request going right and a Response going left.

Example: Web Servers
HTTP client
HTTP server
Request --->
<--- Response

## Section 49: Web Servers Communication and Encapsulation Example

### Ephemeral Port

An ephemeral port is a short-lived port assigned automatically by the OS to a client application (such as an HTTP client) for establishing a TCP connection [459b7e3bbded:p49].
Sources: 459b7e3bbded:p49

### Port 80

Port 80 is the standard port number conventionally used by web servers to receive HTTP requests from clients [459b7e3bbded:p49].
Sources: 459b7e3bbded:p49

### TCP Header

The TCP header encapsulates segment data and contains source and destination port numbers to manage transport-layer connections [459b7e3bbded:p50].
Sources: 459b7e3bbded:p50

### IP Header

The IP header encapsulates the transport segment, containing source and destination IP addresses along with the transport protocol type for routing [459b7e3bbded:p50].
Sources: 459b7e3bbded:p50

### Ethernet Header and Frame Check Sequence

The Ethernet header contains source and destination physical addresses and network protocol type, while the Frame Check Sequence ensures data integrity at the link layer [459b7e3bbded:p50].
Sources: 459b7e3bbded:p50

#### 459b7e3bbded:p49 (content)

This slide illustrates a web server client-server interaction over TCP, detailing port usage such as Ephemeral Port and Port 80, along with HTTP GET and response status messages.

Example: Web Servers
HTTP client
HTTP server
Ephemeral Port #
Port 80
TCP
GET 80, #
#, 80 STATUS

#### 459b7e3bbded:p50 (content)

This slide breaks down data encapsulation for an HTTP request, showing how it passes through TCP, IP, and Ethernet layers with their respective header contents and frame check sequence.

Example: Web Servers
HTTP Request
TCP Header | Header contains source and destination port numbers
IP Header | Header contains source and destination IP addresses; transport protocol type
Ethernet Header | Header contains source and destination physical addresses; network protocol type | Frame Check Sequence
