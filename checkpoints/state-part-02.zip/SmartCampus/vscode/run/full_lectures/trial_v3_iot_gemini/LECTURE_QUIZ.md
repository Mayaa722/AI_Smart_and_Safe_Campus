# Full-lecture quiz — unreviewed draft

Difficulty labels are uncalibrated. The keyed answer/explanation is shown for instructor review.

## 1. Which network topology features nodes connected to a central hub or switch that links to the internet?

A. Bus topology
B. Star topology
C. Ring topology
D. Mesh topology

Key: B. A star network topology connects nodes to a central hub or switch linked to the internet, whereas a bus topology connects computers along a shared communication line.

Sources: [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>)

## 2. In the client/server model, what primary behavioral characteristic distinguishes the client from the server?

A. The client is passive because it listens for incoming connection requests.
B. The server is active because it initiates communication sessions.
C. The client is active because it initiates communication by sending requests.
D. The server is active because it only sends data without listening.

Key: C. The client is described as active because it initiates communication by sending requests to the server, while the server is passive because it listens for incoming communications and responds.

Sources: [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>)

## 3. Additional teaching: When designing an outdoor wireless sensor link using a high carrier frequency for high data rate streaming, which propagation limitation must engineers primarily account for compared to low-frequency links?

A. High frequencies travel long distances and easily follow the Earth's surface.
B. High frequencies require Line of Sight (LOS) and cannot easily penetrate solid objects.
C. High frequencies are primarily utilized for submarine communication through water.
D. High frequencies rely exclusively on scattering around large obstacles.

Key: B. High frequencies provide high data rates over short distances, travel in straight lines, and cannot penetrate objects, requiring Line of Sight (LOS). Conversely, low frequencies travel long distances and penetrate objects.

Sources: [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>)

## 4. During the process of data encapsulation across the protocol stack, what specific action is performed by each lower layer on the data received from the layer above?

A. It removes all existing headers and trailers to compress the packet size.
B. It translates the binary data exclusively into optical analog waveforms.
C. It adds its own control information, such as headers or trailers.
D. It converts application layer objects directly into physical network cables.

Key: C. Data encapsulation is the process where each layer of the protocol stack adds its own control information—such as headers or trailers—to the data received from the layer above.

Sources: [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>)

## 5. Which digital modulation scheme requires a larger bandwidth compared to simple amplitude shift keying methods while encoding data using discrete frequency changes?

A. Amplitude Shift Keying
B. Frequency Shift Keying
C. Phase Shift Keying
D. Pulse Code Modulation

Key: B. Frequency Shift Keying (FSK) is a digital modulation technique that requires a larger bandwidth compared to simple ASK methods.

Sources: [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>)

## 6. Additional teaching: When configuring an open Wi-Fi network that experiences hidden-node problems and heavy contention among multiple wireless clients, which underlying MAC protocol mechanism is explicitly designed to minimize collision overhead by using small control reservation packets?

A. Carrier Sense Multiple Access with Collision Detection using jam signals
B. Carrier Sense Multiple Access with Collision Avoidance using RTS and CTS packets
C. Dynamic Time Division Multiple Access with slotted frame reservations
D. Token Ring media access control using centralized token passing

Key: B. Wi-Fi (802.11) networks use CSMA/CA, which utilizes channel reservations via Request-to-Send (RTS) and Clear-to-Send (CTS) packets so neighboring nodes keep quiet, minimizing collision overhead to small control packets.

Sources: [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>)

## 7. During a security audit, an administrator tests a server's UDP ports. What does a 'Destination unreachable' reply versus no response indicate about a tested port?

A. No response indicates a closed port, while a 'Destination unreachable' reply indicates an open port.
B. A 'Destination unreachable' reply indicates a closed port, while no response indicates an open port.
C. Both responses indicate that the port is securely filtered by a firewall.
D. Both responses confirm that the UDP three-way handshake was successfully completed.

Key: B. An attacker or administrator sending datagrams to ports receives a 'Destination unreachable' reply for a closed port, whereas no response indicates an open port that can be exploited.

Sources: [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>)

## 8. Which upper network model layer is specifically responsible for data translation, formatting, encryption, and compression to ensure data from one system's application layer can be read by another?

A. Session Layer
B. Presentation Layer
C. Application Layer
D. Transport Layer

Key: B. The presentation layer (Layer 6) handles data translation, formatting, encryption, and compression to ensure data sent from the application layer of one system can be read by another.

Sources: [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>)
