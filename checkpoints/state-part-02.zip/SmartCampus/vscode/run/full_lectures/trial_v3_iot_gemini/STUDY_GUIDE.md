# Comprehensive study guide

# Comprehensive lecture study guide

iot lecture for testing.pdf

This guide follows the full lecture in ordered chapters. Source ambiguities and additional teaching are labelled.

## Whole-lecture connections and quick reference

Follow the source-checked chapters in lecture order:

- Internet-of-Things (IoT) Course Overview [p. 1](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0001.png>) [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>)
- Computer Network Terminology and Topologies [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>) [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>)
- Network Protocols and Fundamentals [p. 5](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0005.png>) [p. 6](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0006.png>)
- Network Fundamentals and OSI Layers 3-7 [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>) [p. 8](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0008.png>)
- HTTP Requests and TCP Connections Lecture Section [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>) [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>)
- UDP vs TCP and TLS/SSL Lecture Section [p. 11](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0011.png>) [p. 12](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0012.png>)
- Communication and Protocols Lecture [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>) [p. 14](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0014.png>)
- Client/Server Model [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>) [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>)
- Network Protocols: Protocol Stack, Headers, and Trailers [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>) [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>)
- Layered Design and Open System Interconnection (OSI) [p. 19](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0019.png>) [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>)
- Physical Layer and Wireless Characteristics [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>) [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>)
- Frequencies and Propagation Effects for Mobile Communication [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>) [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>)
- Multipath Propagation and Real World Examples [p. 25](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0025.png>) [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>)
- Digital Modulation and Data Link Layer [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>) [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>)
- Ethernet and CSMA/CD Protocol [p. 29](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0029.png>) [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>)
- Ethernet and Wi-Fi Networks [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>) [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>)
- Wi-Fi CSMA/CA Protocol and Network Layer IP Addressing [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>) [p. 34](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0034.png>)
- IPv4 and Network Protocols Lecture Section [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>) [p. 36](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0036.png>)
- Network Protocols and Routers [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>) [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>)
- Transport Layer and UDP Protocols [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>) [p. 40](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0040.png>)
- Transport Layer Security: UDP Attacks [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>) [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>)
- Transport Layer Security and Protocols [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>) [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>)
- Transport Layer: TCP and UDP [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>) [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>)
- Upper Layers of the Network Model [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>) [p. 48](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0048.png>)
- Web Servers Communication and Encapsulation Example [p. 49](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0049.png>) [p. 50](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0050.png>)

## Internet-of-Things (IoT) Course Overview

### Course Introduction and Fundamentals

Welcome to CSCI410: Internet-of-Things (IoT) at Nile University, School of Information Technology and Computer Science [p. 1](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0001.png>). This course covers the end-to-end architecture of IoT systems, spanning hardware, communication protocols, cloud processing, and security ecosystems [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).

### Course Overview and Weekly Schedule

The course structure spans six weeks, combining theoretical lectures with practical laboratory sessions [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>):

- **Week 1:** Lecture covers fundamentals of IoT, basic concepts, and applications. The lab focuses on basic Python programming and getting started with the Raspberry Pi [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- **Week 2:** Lecture explores smart objects, user interfaces, sensing, and actuation. Lab work involves sensor programming, control loops, and digital/analog I/O [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- **Week 3:** Lecture addresses fundamentals of computer and wireless networks, while the lab covers Wi-Fi, Bluetooth networks, and network measurements [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- **Week 4:** Lecture examines sensor networks, mesh networks, routing, and wireless personal area networks (WPANs). Lab topics feature ZigBee, WPANs, WBANs, routing, and network measurements [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- **Week 5:** Lecture covers data processing, IoT cloud integration, analytics, and visualization. Lab activities include cloud integration, sensor fusion, analytics, and visualization [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- **Week 6:** Lecture discusses the IoT ecosystem, security, privacy, ethics, trends, and case studies, concluding with the final project in the lab [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).

### Revision Takeaways

- IoT architecture integrates physical sensing and actuation with local processing, wireless networks, and cloud analytics [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- Practical implementation relies heavily on Python programming, single-board computers like the Raspberry Pi, and micro-networking protocols [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).
- Security, privacy, and ecosystem considerations form a critical final component of comprehensive IoT deployments [p. 2](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0002.png>).

## Computer Network Terminology and Topologies

#### Introduction to Computer Networks

A computer network is defined as a group of computers and associated devices that are connected together by communication facilities [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>). Networks can be categorized based on their geographical scale and coverage area [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).

#### Network Scale Classifications

Networks span various physical scales, ranging from worldwide connectivity to localized personal spaces [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>):
- **Wide Area Network (WAN):** Encompasses world-wide connections, best exemplified by the Internet [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).
- **Metropolitan Area Network (MAN):** Operates on a city-scale [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).
- **Local Area Network (LAN):** Serves laboratory or office-scale environments, commonly utilizing Ethernet technology [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).

#### Wireless Network Types

Wireless communication technologies enable specialized network classifications [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>):
- **WLAN:** Wireless Local Area Network operating via Wi-Fi [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).
- **WPAN:** Wireless Personal Area Network operating via Bluetooth [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).
- **WBAN:** Wireless Body Area Network for devices operating on or in close proximity to the human body [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).

#### Network Topologies

Network topology refers to the structural arrangement of various nodes and communication links within a computer network [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>). Different topologies offer distinct routing configurations, cabling layouts, and reliability characteristics [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).

##### Star and Common Bus Topologies
- **Star Network Topology:** Connects individual nodes to a central hub or switch, which in turn links the network to external systems like the Internet [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).
- **Common Bus Topology:** Connects multiple computers along a single shared communication line or backbone [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).

##### Mesh, Fully Connected, and Ring Topologies
- **Fully Connected Network Topology:** Every single node has a direct dedicated communication link to every other node in the network [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).
- **Mesh Network Topology:** Provides multiple inter-node paths, offering redundancy and alternate routes for data traffic without requiring full pairwise connections for every device [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).
- **Ring Network Topology:** Connects devices in a circular closed loop where data travels sequentially from node to node [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).

#### Revision Takeaways
- Networks are classified by geographical scope into WAN, MAN, LAN, WLAN, WPAN, and WBAN [p. 3](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0003.png>).
- Physical layout options include Star, Bus, Ring, Mesh, and Fully Connected topologies, each determining how devices interface with communication paths [p. 4](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0004.png>).

## Network Protocols and Fundamentals Study Chapter

### Network Protocols and Fundamentals

#### Network Protocols Overview

Protocols serve as the fundamental building blocks of any network architecture, establishing formal standards and policies that enable devices to communicate reliably [p. 5](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0005.png>). Standardization is heavily driven by organizations such as the IEEE (Institute of Electrical and Electronics Engineers) [p. 5](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0005.png>). A prominent example of this standardization work is Project 802, which defines key networking categories [p. 5](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0005.png>):

- 802.3: Ethernet (Wired Local Area Networks)
- 802.11: WLAN (Wireless Local Area Networks)
- 802.15: WPAN (Wireless Personal Area Networks)

#### Fundamentals and IP Addressing

Transitioning into Part 1 (Fundamentals), the curriculum introduces core analytical questions regarding network structure [p. 6](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0006.png>). A primary foundational activity asks [p. 6](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0006.png>):

- Given an IP address, how can we determine the network address and the host address?

#### Revision Takeaways

- Network protocols provide the formal standards and policies required for network communication [p. 5](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0005.png>).
- The IEEE manages vital architecture standards via initiatives like Project 802 (Ethernet 802.3, WLAN 802.11, and WPAN 802.15) [p. 5](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0005.png>).
- Foundational tasks require differentiating between network addresses and host addresses given an IP address [p. 6](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0006.png>).

## Network Fundamentals and OSI Layers 3-7

#### Part 2 Fundamentals and Home Networks

Part 2 introduces foundational concepts in local networking and connectivity [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>). A central activity investigates whether it is possible to configure and run a functional home network using exclusively a network switch [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>). Furthermore, it explores how two distinct personal computers can communicate over this setup using protocols such as Secure Shell (SSH) [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>).

Additional topics examine inter-network communication: how data packets traverse boundaries between two different networks, and how a host identifies its local network gateway IP address [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>).

#### OSI Layers 3-7 and Routing Activities

Part 2-2 transitions to upper-layer considerations (OSI Layers 3 through 7) [p. 8](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0008.png>). Note that the source text contains a minor typographic abbreviation ("OSB" instead of OSI) [p. 8](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0008.png>). 

A key activity examines local network boundary detection: when a host PC1 attempts to send data to a destination PC2, how does PC1 determine whether the target address resides outside its current local network segment [p. 8](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0008.png>)?

A subsequent activity addresses internet-scale routing: when PC1 transmits data to an external internet server, and that server replies using PC1's IP address, how do intermediate internet routers manage private local IP addresses across wide-area networks [p. 8](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0008.png>)?

#### Revision Takeaways

- Understand how switches establish local connectivity and how protocols like SSH enable host-to-host communication [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>).
- Recognize the role of gateway IP addresses in forwarding packets across distinct networks [p. 7](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0007.png>).
- Analyze how network nodes determine local versus external network boundaries using OSI layer principles [p. 8](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0008.png>).

## HTTP GET Requests and TCP Connections Study Chapter

### HTTP GET Requests and TCP Connections

#### Network Diagnostics and HTTP Requests

Network inspection involves examining connectivity and interface parameters using common command-line diagnostic tools [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>). When evaluating network configurations, tools help answer key questions regarding host settings and routes [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>):
* What is the IP address [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>)?
* What is the DNS server being used [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>)?
* What is the routing path [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>)?

Commands like ping and ifconfig assist in checking interface status and reachability [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>). Furthermore, interacting with web servers directly can be achieved using telnet [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>). For example, connecting to a web server via telnet on port 80 allows a user to issue an HTTP GET request manually [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>):

```
telnet www.httpforever.com 80
GET /index.html
```

Additional teaching: Remote administration can also be demonstrated via examples such as SSH connecting a personal computer to a remote device (RP device) [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>).

#### TCP Connection Mechanics and Management

Transmission Control Protocol (TCP) covers numerous operational facets governing reliable communication between hosts [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>). Important protocol components include header data formatting and acknowledgments (Acq) [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>). 

Key mechanisms for managing reliability, throughput, and connection lifecycles consist of:
* Error Handling: Managing corrupted or lost segments [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).
* Delayed Acknowledgments (Delayed Ack): Reducing packet counts by waiting briefly before acknowledging received data [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).
* Window Size and Flow Control: Managing buffer allocations and matching transmission rates between sender and receiver to prevent buffer overflows [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).
* Bidirectional Transfer: Supporting simultaneous data exchange in both directions [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).
* Connection Initialization: Establishing the session state safely [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).
* Connection Close: Terminating the session gracefully [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).
* Connection Reset: Abruptly tearing down connections when unrecoverable errors occur [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).

#### Revision Takeaways
* Use telnet on port 80 to manually issue HTTP GET requests like `GET /index.html` [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>).
* Use diagnostic utilities like ifconfig and ping to inspect local IP addresses, DNS servers, and network routes [p. 9](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0009.png>).
* TCP controls transport reliability through headers, acknowledgments, window sizing, flow control, error handling, and structured connection lifecycle management (initialization, close, and reset) [p. 10](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0010.png>).

## UDP vs TCP and TLS/SSL Study Chapter

### UDP vs TCP Overview

Part 5 of the lecture introduces core transport-layer concepts comparing User Datagram Protocol (UDP) and Transmission Control Protocol (TCP) [p. 11](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0011.png>). The discussion covers connection-oriented communication, reliability mechanisms, flow control, protocol overheads, and addresses four common myths [p. 11](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0011.png>).

### TLS/SSL Security Fundamentals

Security protocols such as TLS and SSL protect transmitted data through specific architectural components [p. 12](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0012.png>). Key topics include data protection methods, anti-replay protection, non-repudiation, identification of key players, and the role of certificate authorities [p. 12](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0012.png>).

## Communication and Protocols

#### Communication Rules
Communication depends on a structured set of fundamental questions that govern how participants interact [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>). These rules establish:
- Who initiates communication [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>).
- The order and turn-taking of communication [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>).
- Duration and volume limits, such as how long someone can talk and how loud they can speak [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>).
- Formatting requirements, including specific phrases at the beginning or end and necessary metadata [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>).
- Error-handling procedures for managing interruptions or misunderstandings [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>).

#### Protocols in Communication
A protocol defines the specific format and the order of messages exchanged between communicating entities, as well as the actions taken on the transmission and receipt of a message or other event [p. 14](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0014.png>). Protocols apply to both human interactions and computer networks over time [p. 14](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0014.png>).

The diagram comparison shows:
- **Human Interaction:** One person initiates by greeting with "Hi", the other responds with "Hi", followed by a question ("Got the time?") and a reply ("2:00") [p. 14](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0014.png>).
- **Computer Network Interaction:** A computer system sends a TCP connection request, receives a TCP connection response, requests a file using an HTTP GET command (e.g., Get http://www.awl.com/kurose-ross), and receives the requested file data back over time [p. 14](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0014.png>).

#### Revision Takeaways
- Communication requires explicit rules for initiation, ordering, constraints, metadata, and error handling [p. 13](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0013.png>).
- Protocols govern message exchanges across time for both human conversations and computer networking tasks like TCP connections and HTTP requests [p. 14](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0014.png>).

## Study Chapter: The Client/Server Model

### Introduction to the Client/Server Model

The client/server architecture is a foundational paradigm in distributed systems and networking [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>). In this model, communication is structured around distinct roles assigned to endpoints: clients and servers [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>).

#### Core Roles and Interactions

Communication in this model is directional and event-driven. The interaction can be broken down into two primary actors:

- **Client:** The client is designated as "active" because it initiates communication by sending a request message across the network to a server [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>).
- **Server:** The server is designated as "passive" because it listens for incoming connection requests and processes them by returning a response [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>).

Diagrammatically, this is represented by an active client entity sending a dashed arrow labeled "request" toward a server entity, which in turn returns a dashed arrow labeled "response" back to the client [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>).

#### Practical Examples

Numerous standard networking protocols and distributed services are built upon the client/server model [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>). Common examples include:

- **HTTP (Hypertext Transfer Protocol):** Used for transferring web pages and resources on the World Wide Web [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).
- **SMTP (Simple Mail Transfer Protocol):** Utilized for transmitting electronic mail across networks [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).
- **SSH (Secure Shell):** Provides secure encrypted login and remote command execution [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).
- **DNS (Domain Name System):** Resolves human-readable domain names into machine-useable IP addresses [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).
- **NFS/AFS (Network File System / Andrew File System):** Enables network-attached remote file storage and sharing [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).

These protocols are frequently arranged in circular modular diagrams to illustrate their role as peer applications of the overarching client/server architecture [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).

#### Revision Takeaways

- The client is active because it originates communication requests [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>).
- The server is passive, awaiting requests to listen and respond [p. 15](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0015.png>).
- Essential application-layer protocols like HTTP, SMTP, SSH, DNS, and NFS/AFS rely entirely on this model [p. 16](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0016.png>).

## Network Protocols: Protocol Stack, Headers, and Trailers

#### OSI Protocol Stack

Communication networks utilize structured conceptual models known as protocol stacks to organize and modularize network architecture [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>). The standard model divides communication into seven distinct vertical layers: Application Layer, Presentation Layer, Session Layer, Transport Layer, Network Layer, Data Link Layer, and Physical Layer [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>). 

Each layer communicates peer-to-peer with its corresponding layer on a remote system, while interacting directly with the adjacent layers immediately above and below it [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>). Intermediate communication network devices (such as routers and switches) implement the lower three layers (Network, Data Link, and Physical layers) to handle routing and media transmission across the network topology [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>).

#### Data Encapsulation

As data originates from Application A and travels downward through the protocol stack, it undergoes data encapsulation [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>). At each descending layer, control information in the form of headers or trailers is appended to the payload [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>). 

Starting with raw application data, headers are added sequentially: application header (ah), presentation header (ph), session header (sh), transport header (th), and network header (nh) [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>). At the Data Link layer, both a data trailer (dt) and data header (dh) are attached [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>). Finally, the Physical layer converts the fully encapsulated packet into a stream of bits for physical transmission across the communication medium to Application B [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>).

#### Revision Takeaways

- The protocol stack structures network communication into seven modular layers [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>).
- End systems implement all seven layers, whereas intermediate network nodes implement only the lower three layers [p. 17](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0017.png>).
- Data encapsulation ensures that each layer adds specific headers (or trailers) as data descends toward the physical medium [p. 18](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0018.png>).

## Layered Design and Open System Interconnection (OSI)

#### Why A Layered Design?

Layered design provides an explicit structure for dealing with complex systems [p. 19](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0019.png>). Breaking down a large system into smaller, discrete layers offers several key benefits:

* **Simplifies Design:** It breaks down the overall design process into manageable parts [p. 19](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0019.png>).
* **Modularity:** Modularity of layers makes maintaining and updating system components easier [p. 19](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0019.png>).
* **Flexibility:** It accommodates incremental changes without requiring a redesign of the entire system [p. 19](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0019.png>).

#### Open System Interconnection (OSI)

The Open System Interconnection (OSI) model divides network architecture into seven distinct layers [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>). These layers are broadly grouped into Upper Layers (layers 5 through 7) and Transport Service layers (layers 1 through 4) [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).

##### Upper Layers (Layers 5-7)

* **Layer 7 - Application Layer:** Manages message formats and Human-Machine Interfaces [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).
* **Layer 6 - Presentation Layer:** Handles coding into 1s and 0s, encryption, and compression [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).
* **Layer 5 - Session Layer:** Manages authentication, permissions, and session restoration [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).

##### Transport Service Layers (Layers 1-4)

* **Layer 4 - Transport Layer:** Provides end-to-end error control [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).
* **Layer 3 - Network Layer:** Handles network addressing, routing, or switching [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).
* **Layer 2 - Data Link Layer:** Manages error detection and flow control on the physical link [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).
* **Layer 1 - Physical Layer:** Deals with the bit stream, physical medium, and the method of representing bits [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).

#### Revision Takeaways

* Layered architecture tames complexity via modular separation [p. 19](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0019.png>).
* The OSI model consists of 7 layers, split into Upper Layers (5-7) and Transport Service (1-4) [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).
* Each layer is responsible for specific tasks ranging from physical bit transmission up to application-level human-machine interfaces [p. 20](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0020.png>).

## Physical Layer and Wireless Characteristics

#### Physical Layer Overview

The Physical Layer, designated as Layer 1, is responsible for managing the physical and electrical characteristics of communication channels [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>). It governs physical components and properties such as cable types, cable lengths, physical connectors, voltage levels, and signal durations [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>). At this foundational layer, raw binary data (bits) are translated and transmitted across the physical medium as electrical impulses or optical signals [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>). For wireless systems, Layer 1 handles specific frequencies [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>).

#### Wireless Characteristics and Spectrum Bands

Wireless communication relies on electromagnetic waves spanning a broad frequency spectrum. The fundamental relationship governing wave propagation is expressed by the equation:

lambda = c / f

where lambda represents the wavelength, c is the speed of light (approximately 3 x 10^8 m/s), and f denotes the frequency [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>). Because c is constant, wavelength and frequency are inversely proportional.

The electromagnetic spectrum is categorized into standardized frequency bands [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>):
- VLF (Very Low Frequency): 300 Hz, corresponding to a wavelength of 1 Mm [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- LF (Low Frequency): 30 kHz, corresponding to 10 km [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- MF (Medium Frequency): 3 MHz, corresponding to 100 m [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- HF (High Frequency): corresponding to 1 m at 300 MHz [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- VHF (Very High Frequency) [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- UHF (Ultra High Frequency): 30 GHz corresponding to 10 mm [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- SHF (Super High Frequency): 3 THz corresponding to 100 um [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- EHF (Extra High Frequency): 300 THz corresponding to 1 um [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).
- Higher spectrum ranges include infrared, visible light, and Ultraviolet (UV) light [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).

#### Revision Takeaways
- Layer 1 defines hardware-level attributes including voltage levels, connectors, and cable specifications [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>).
- Bits are physically manifested as optical or electrical signals [p. 21](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0021.png>).
- Wavelength and frequency are inversely related via lambda = c / f, with c equal to 3 x 10^8 m/s [p. 22](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0022.png>).

## Frequencies and Propagation Effects for Mobile Communication

#### Frequencies for Mobile Communication

Wireless communication signals behave differently depending on their operating frequency [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>). Understanding these physical traits helps determine their suitability for specific communication tasks.

##### Low Frequencies

Low frequencies are characterized by the following properties:
* Provide low data rates [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).
* Travel long distances and follow the curvature of the Earth's surface [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).
* Possess strong penetration capabilities through physical objects and water, making them suitable for specialized applications like submarine communication [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).

##### High Frequencies and Line of Sight (LOS)

High frequencies exhibit an alternative set of behaviors:
* Deliver high data rates [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).
* Operate over short distances [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).
* Travel strictly in straight lines and cannot penetrate solid objects, which necessitates an unobstructed Line of Sight (LOS) between transmitter and receiver [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).

#### Other Propagation Effects

As wireless signals travel through real-world environments, they interact with physical structures via several fundamental propagation mechanisms [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>):

* **Shadowing:** Occurs when an opaque obstacle blocks the direct path of a wave, creating a shadowed region behind it [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>).
* **Reflection:** Happens when a wave encounters large obstacles (such as buildings), bouncing off the surface [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>).
* **Refraction:** Involves the bending of a wave as it passes through media of varying densities [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>).
* **Scattering:** Takes place when a wave hits small obstacles, dispersing the signal energy in multiple directions [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>).
* **Diffraction:** Occurs at sharp edges or corners, allowing waves to bend around obstacles and propagate into shadowed zones [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>).

#### Revision Takeaways
* Low frequencies handle long-distance, surface-following, and water-penetrating communication at lower data speeds [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).
* High frequencies provide high data rates over short paths but require uninterrupted line of sight [p. 23](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0023.png>).
* Signal propagation is heavily influenced by environmental interactions including shadowing, reflection, refraction, scattering, and diffraction [p. 24](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0024.png>).

## Multipath Propagation and Real World Examples

### Real World Examples

Radio frequency signal propagation can be examined across diverse real-world topologies [p. 25](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0025.png>). Visualizations demonstrate signal propagation behavior in varied environments, including an urban street grid layout labeled Central Munich, an indoor floor plan with dimensions spanning 20 m by 13.60 m, and an outdoor terrain profile spanning 123 km with a height dimension of 1450 m [p. 25](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0025.png>). These scenarios illustrate how physical environments constrain and shape radio wave propagation [p. 25](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0025.png>).

### Multipath Propagation

A transmitted signal can travel via many different paths between a sender and a receiver due to physical phenomena such as reflection, scattering, and diffraction [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>). 

The multipath propagation diagram illustrates a sender transmitting a signal which encounters obstacles like a building and a stop sign before reaching a receiving vehicle [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>). At the receiver, this results in delay spread, where the originally compact signal pulses are dispersed in time [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>). The resulting signal at the receiver consists of line-of-sight (LOS) pulses arriving earlier alongside delayed multipath pulses arriving at varying later times due to the differing path lengths traveled [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>).

### Revision Takeaways
- Signals propagate through complex environments via reflection, scattering, and diffraction [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>).
- Real-world environments include dense urban layouts, indoor floor plans, and long-range outdoor topographies [p. 25](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0025.png>).
- Multipath propagation causes delay spread at the receiver, separating LOS pulses from subsequent multipath pulses [p. 26](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0026.png>).

## Digital Modulation and Data Link Layer

### Digital Modulation

Digital modulation involves encoding digital data onto carrier signals. Three primary techniques are Amplitude Shift Keying (ASK), Frequency Shift Keying (FSK), and Phase Shift Keying (PSK) [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>). 

* **Amplitude Shift Keying (ASK):** This scheme is very simple to implement and requires low bandwidth [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>). However, it is very susceptible to interference [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>). In the waveform diagram representing bit sequence 1, 0, 1 over time t, carrier oscillations are present for binary 1 and absent for binary 0 [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>).
* **Frequency Shift Keying (FSK):** This method modulates data by shifting the carrier frequency and needs a larger bandwidth than ASK [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>). The waveform diagram shows varying frequency spacing across bits 1, 0, and 1 [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>).
* **Phase Shift Keying (PSK):** This technique alters the phase of the carrier signal [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>). While it is more complex than ASK and FSK, it offers robust resistance against interference [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>). The waveform diagram exhibits sudden phase inversions at bit boundaries for the sequence 1, 0, 1 [p. 27](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0027.png>).

### Data Link Layer (Layer 2)

The Data Link Layer (Layer 2) defines when and how the transmission medium will be accessed [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>). Its data units are typically called frames, and it handles error detection and correction [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>). The layer is divided into sublayers, including Medium Access Control (MAC), which utilizes hardware identifiers such as MAC address 6f:00:2b:23:1f:32 [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>).

Cell phone systems illustrate multiple access methods for sharing communication channels [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>):
* **FDMA (Frequency Division Multiple Access):** Allocates distinct frequency bands (f1, f2, f3) to different transmissions over time [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>).
* **TDMA (Time Division Multiple Access):** Allocates discrete time slots (1, 2, 3) across shared frequency channels [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>).
* **CDMA (Code Division Multiple Access):** Uses distinct spread codes (spread code 1, 2, 3) to allow multiple users to share the same frequency and time resources simultaneously [p. 28](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0028.png>).

## Ethernet and CSMA/CD Protocol Study Chapter

### Ethernet Bus Architecture

Ethernet, standardized as 802.3, represents a widely deployed local area network (LAN) technology configured around a shared bus architecture [p. 29](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0029.png>). The architectural appeal lies in its cost-effectiveness and ease of installation [p. 29](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0029.png>). Rather than transmitting continuous data streams, Ethernet segments data into discrete packets to facilitate transmission across the physical medium [p. 29](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0029.png>). The physical layout, as illustrated in the bus segment diagrams, connects multiple computers, printers, and servers along a common line or set of interconnected segments [p. 29](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0029.png>).

### Medium Access Control (MAC) in Ethernet

Because multiple devices share the same communication channel in a bus topology, managing access becomes essential to prevent chaos. Ethernet relies on a Medium Access Control (MAC) protocol to dictate how nodes share access to the physical transmission medium without corrupting each other's data [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>).

### CSMA/CD Protocol

To coordinate channel sharing, Ethernet implements the Carrier Sense, Multiple Access with Collision Detection (CSMA/CD) protocol [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>). The mechanisms comprising CSMA/CD function as follows:

* Carrier Sense: Nodes listen to the shared medium to determine whether another transmission is currently active before attempting to send data [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>).
* Multiple Access: Any connected node has the capability to access the shared communication channel [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>).
* Collision Detection: If two or more nodes transmit data simultaneously, their signals interfere on the bus [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>). The collision detection mechanism identifies this corruption, allowing nodes to abort and handle the retransmission.

The accompanying diagram depicts nodes A, B, and C connected to a shared bus, showing transmission directions with arrows and highlighting a jagged red burst explicitly labeled "collision" where simultaneous signals interfere [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>).

### Revision Takeaways

* Ethernet (802.3) is an inexpensive, easy-to-install LAN technology utilizing a bus architecture and packet-based data transfer [p. 29](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0029.png>).
* MAC protocols govern medium sharing among multiple nodes [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>).
* CSMA/CD incorporates Carrier Sense, Multiple Access, and Collision Detection to manage shared channel access and handle simultaneous transmission conflicts [p. 30](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0030.png>).

## Ethernet and Wi-Fi Networks

#### Ethernet Carrier Sensing and Collision Detection

Ethernet relies on carrier sensing to manage access to a shared communication medium [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>). Nodes listen to the carrier to determine if any other device is currently transmitting [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>). The operational rules are straightforward:

* If the carrier is sensed as busy, the node waits [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>).
* If the carrier is sensed as idle, the node proceeds to transmit [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>).

The diagram for this mechanism shows nodes A, B, and C connected along a shared bus line [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>). Node B exhibits a thought bubble reading "Don't transmit", while an arrow indicates data transmission originating from node A toward node C [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>). A text box prompts consideration with the question: "Can collisions still occur?" [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>).

To handle situations where simultaneous transmissions interfere, Ethernet employs Collision Detection (CD) [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>). Nodes continue to listen to the channel while they are actively transmitting [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>). If a collision is detected, the transmitting node stops and schedules a retry for a later time [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>).

#### Wi-Fi 802.11 Architecture

Wi-Fi (802.11) stands as the most popular wireless local area network (LAN) architecture [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>). The network topology features multiple client computers connected via wireless links to a central coordinating entity [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>). The central device can be referred to by several interchangeable terms depending on deployment context:

* Access point [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>)
* Wi-Fi router [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>)
* Base station [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>)
* Hotspot [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>)

The accompanying diagram illustrates this star-like wireless topology, showing individual computer icons linked via jagged wireless signal lines to a central access point node [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>).

#### Revision Takeaways
* Ethernet nodes sense the channel before transmitting, waiting if busy and transmitting if idle [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>).
* Collision detection requires nodes to listen while transmitting and retry later if a collision occurs [p. 31](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0031.png>).
* Wi-Fi (802.11) connects multiple client devices through wireless links to a central access point, router, base station, or hotspot [p. 32](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0032.png>).

## Wi-Fi CSMA/CA Protocol and Network Layer IP Addressing

#### Wi-Fi CSMA/CA Protocol

Wireless networks (802.11) manage medium access using the Carrier Sense Multiple Access with Collision Avoidance (CSMA/CA) protocol [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>). To prevent collisions in a shared wireless medium where direct collision detection is difficult, CSMA/CA incorporates explicit channel reservations [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>). 

The reservation mechanism operates as follows:
- The transmitter sends a Request-to-Send (RTS) packet to the receiver [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>).
- The receiver responds with a Clear-to-Send (CTS) packet [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>).

**Diagram Interpretation:** The accompanying slide diagram illustrates nodes A, B, and C with intersecting dashed transmission ranges [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>). A collision burst cloud is shown above node B where transmissions overlap [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>). 

The advantages of this RTS/CTS reservation exchange are twofold: any neighboring nodes hearing the RTS and/or CTS frames keep quiet to avoid interference, and if a collision does occur, only the small RTS or CTS control packets are lost rather than large data payloads [p. 33](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0033.png>).

#### Network Layer and IP Addressing

Moving up the OSI stack, the Network Layer (Layer 3) is responsible for end-to-end packet delivery, encompassing addressing and routing for both sender and receiver IP addresses [p. 34](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0034.png>). The dominant protocol at this layer is the Internet Protocol (IP) [p. 34](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0034.png>).

IPv4 utilizes a 32-bit hierarchical address space spanning 4 bytes, which embeds location information directly within its structure [p. 34](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0034.png>). Structurally, an IPv4 address is divided into a Network ID and a Host ID [p. 34](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0034.png>). These addresses are conventionally expressed in dotted-decimal notation, such as 128.100.11.56, where each byte is represented by its decimal value separated by periods [p. 34](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0034.png>).

## IPv4 and Network Protocols Study Chapter

### IPv4 Addressing and Network Protocols

#### IPv4 Address Classes and CIDR Notation
IPv4 addresses are historically structured into classes (Class A, B, and C) defined by leading bit patterns that determine the split between network and host portions, as well as their default subnet masks [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>). Specifically, Class A uses a leading bit of 0 with 7 network bits and 24 host bits (default subnet mask 255.0.0.0); Class B uses leading bits 10 with 14 network bits and 16 host bits (default subnet mask 255.255.0.0); and Class C uses leading bits 110 with 21 network bits and 8 host bits (default subnet mask 255.255.255.0) [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>). Note that the source diagram contains a minor spelling typo ("Netwok") in the subnet mask labels [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>).

Instead of writing out full traditional subnet masks such as 255.255.255.0, Classless Inter-Domain Routing (CIDR) notation appends a slash and the number of bits allocated to the network portion [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>). For example, the address notation 192.168.1.10/24 specifies that 24 bits are dedicated to the network portion [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>).

#### Network Protocols Protocol Stack
Communication functions are organized into hierarchical layers known as the protocol stack, allowing modular data transmission and peer-to-peer communication across a network containing intermediate routing nodes [p. 36](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0036.png>). As illustrated in the OSI 7-layer architecture diagram, the stack consists of the Application Layer, Presentation Layer, Session Layer, Transport Layer, Network Layer, Data Link Layer, and Physical Layer [p. 36](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0036.png>). Higher layers (Application, Presentation, Session, and Transport) communicate end-to-end between source and destination hosts, whereas lower layers (Network, Data Link, and Physical) handle communication across the underlying communication network and intermediate routers [p. 36](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0036.png>).

#### Revision Takeaways
- CIDR notation provides a compact way to specify network bit lengths using a slash suffix (e.g., /24) instead of full subnet masks [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>).
- IPv4 address classes define historical boundaries between network and host bits via leading bit patterns [p. 35](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0035.png>).
- The protocol stack modularizes network communications across seven hierarchical layers, separating end-to-end transport from node-to-node routing [p. 36](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0036.png>).

## Network Protocols and Routers

### Network Protocols and Protocol Stack

Network architecture is organized hierarchically using the 7-layer OSI model alongside the corresponding TCP/IP protocol stack [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>). These models map communication functions from raw physical transmission up to high-level application services [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).

#### OSI Model and TCP/IP Protocol Stack

The OSI model defines seven distinct layers of abstraction [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>):
- Layer 1 (Physical): Handles raw electrical signals, cabling, and antennas [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).
- Layer 2 (Data Link / Station to Station): Transmits packets node-to-node using station addresses such as Ethernet and Wi-Fi [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).
- Layer 3 (Network / Network to Network): Routes data across different LANs and WANs based on network addressing like IP [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).
- Layer 4 (Transport): Ensures reliable delivery of entire files or messages (e.g., TCP ensures delivery, while UDP delivery is not ensured) [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).
- Layer 5 (Session): Starts, stops, and maintains communication sessions and preserves order [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).
- Layer 6 (Presentation): Handles encryption and data conversion such as ASCII to EBCDIC or BCD to binary [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).
- Layer 7 (Application): Manages types of communication including email, file transfer, and client-server interactions (e.g., HTTP, SMTP, FTP) [p. 37](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0037.png>).

### Routers and Routing Tables

Routers form the backbone of the Internet by connecting multiple Autonomous Systems (AS 1 through AS 5) [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>). They use the IP layer to identify the source and destination of packets [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>). When a packet arrives, a router looks up its internal routing table to determine the appropriate "next hop" IP address based on destination network prefixes [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>). For example, a destination prefix of 147.39.21.X maps to next hop 131.19.18.121, 89.44.X.X maps to 131.19.22.119, and 203.21.X.X maps to 137.18.47.48 [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>).

### Network Diagnostic Commands

Network troubleshooting and diagnostics rely on standard command-line utilities [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>):
- ifconfig: Inspects interface configuration parameters [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>).
- Ping: Tests basic end-to-end connectivity and measures round-trip time [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>).
- Traceroute / mtr: Traces the specific sequence of router hops that packets traverse across the network [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>).

### DNS Lookup Utilities and Configuration

Domain Name System (DNS) utilities resolve human-readable domain names into machine-readable IP addresses [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>):
- nslookup www.google.com: Queries a DNS server to retrieve the corresponding IP address [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>).
- grep "nameserver" /etc/resolv.conf: Queries local Unix-like system configuration files to identify the active local DNS server [p. 38](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0038.png>).

## Transport Layer and UDP Protocols

#### Transport Layer Overview and UDP

The Transport Layer (Layer 4) introduces protocols such as the User Datagram Protocol (UDP) [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>). While an IP address identifies a specific computer on a network, the transport layer adds further addressing through ports to specify which exact application on that computer should handle the data [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>). For example, a web server typically listens to requests on port 80, as seen in an address like http://www.google.com:80 or http://216.58.216.100:80, where the port designation ':80' can be optional [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>).

UDP is an unreliable transport protocol [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>). This means that individual packets can get lost in transit, or they can arrive out of order at the destination [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>).

#### UDP Header Structure

The structure of a UDP packet consists of a UDP header followed immediately by the payload data [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>). The header fields include:
- Source Port [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>)
- Destination Port [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>)
- Length [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>)
- Checksum [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>)

These fields precede the data payload to facilitate basic routing of datagrams to the correct application layer process [p. 39](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0039.png>).

#### UDP Transmission Modes

UDP supports various communication patterns between senders and receivers [p. 40](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0040.png>). The interaction diagram for how UDP works illustrates a sender making a request to receivers, which can yield multiple responses back [p. 40](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0040.png>). Furthermore, UDP supports three distinct transmission modes:
- Unicast (One-to-One): Direct communication between a single sender and a single receiver [p. 40](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0040.png>).
- Broadcast (One-to-All): Transmission from a single sender to every device on the network [p. 40](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0040.png>).
- Multicast (One-to-Several): Transmission from a single sender to a specific group of multiple receivers [p. 40](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0040.png>).

## Transport Layer Security: UDP Attacks

#### UDP Flood Attack

Because the User Datagram Protocol (UDP) does not perform a handshake process prior to data transmission, an attacker can exploit this lack of connection establishment [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>). As illustrated in the UDP Flood Attack Example diagram [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>), an attacker controls multiple bot instances to bombard a single server with a large number of spoofed UDP packets targeting various ports without waiting for communication permission [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>). 

When the server receives these packets, it responds to each one with a Destination Unreachable message [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>). This processing overhead overwhelms the server's computational and network resources, successfully resulting in a denial of service to legitimate traffic trying to reach the user or application [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>).

#### DNS Amplification Attack

Another major security vulnerability involving UDP is the DNS amplification attack [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>). As depicted in the DNS Amplification Attack Example diagram [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>), an attacker coordinates botnets to send numerous datagrams with spoofed IP addresses to open DNS resolvers [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>). These spoofed source IP addresses actually belong to the intended victim [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>).

Upon receiving these requests, the open DNS resolvers generate much larger and disproportionate replies—a phenomenon known as amplification—and direct them toward the spoofed IP address [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>). Consequently, the victim's network is completely saturated with these massive responses, leading to severe network congestion and disruption [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>).

#### Revision Takeaways
- UDP lacks a connection-establishment handshake, permitting unverified packet flooding [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>).
- UDP flood attacks overwhelm server resources via forced Destination Unreachable error responses [p. 41](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0041.png>).
- DNS amplification exploits open resolvers to bounce disproportionately large responses back to a victim's spoofed IP address, saturating their network [p. 42](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0042.png>).

## Transport Layer Security and Protocols

#### Transport Layer Security

The transport layer (Layer 4) handles end-to-end communication across a network. Understanding its security implications is vital for protecting network services [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>).

##### UDP Port Scan

An attacker can probe a server using UDP datagrams to discover which ports are actively listening [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>). The mechanics of this scan rely on the server's response behavior:

- **Closed Port:** When an attacker sends a datagram to a closed port, the server replies with a "Destination unreachable" message. This signals to the attacker that the port is inactive, prompting them to move on to another port [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>).
- **Open Port:** If the server provides no response to the datagram, the port is considered open. The attacker can then exploit this vulnerable port to compromise the target network, server, or service [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>).

#### Transfer Protocols

Different transport protocols establish communication differently. The comparison between TCP and UDP illustrates distinct connection paradigms [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).

##### TCP Handshake

TCP communication uses a connection-oriented model initialized by a three-way handshake between a sender and a receiver [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>). The sequential message exchange consists of:

1. **SYN:** The sender initiates connection request by sending a synchronization packet [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).
2. **SYN ACK:** The receiver acknowledges the synchronization request and sends its own synchronization acknowledgment [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).
3. **ACK:** The sender replies with a final acknowledgment to establish the connection [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).

##### UDP Communication

In contrast, UDP is a connectionless transport method where requests and responses are exchanged directly between a sender and receiver without any preliminary handshake phase [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).

#### Revision Takeaways

- UDP port scans exploit missing responses to identify open, vulnerable ports [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>).
- A "Destination unreachable" response indicates a closed UDP port [p. 43](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0043.png>).
- TCP relies on a three-way handshake (SYN, SYN ACK, ACK) before data transfer [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).
- UDP operates without connection establishment handshakes, directly exchanging requests and responses [p. 44](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0044.png>).

## Transport Layer Protocols: TCP and UDP

### Transport Layer Overview

The transport layer manages host-to-host communication services for applications. Like UDP, TCP adds port numbers to identify application endpoints, but TCP introduces comprehensive reliability, sequencing, and control mechanisms [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>). The diagram on page 45 illustrates two communicating entities passing a Packet to the right and returning an ACK packet to the left [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>).

### Transmission Control Protocol (TCP)

TCP is a reliable transport protocol designed to guarantee that data arrives accurately and in sequence [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>). Its key mechanisms include:

- In-Order Delivery: Utilizes sequence numbers to ensure packets are reassembled in the correct order at the destination [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>).
- Reliable Delivery: Employs acknowledgment (ACK) packets to confirm successful receipt of data [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>).
- Flow and Congestion Control: Enables the receiver and the network infrastructure to slow down the sender when congestion or receiver bottlenecks occur [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>).

TCP is the typical choice for applications where data loss, corruption, or out-of-order delivery is unacceptable, such as email, web traffic, and financial transactions [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>).

### User Datagram Protocol (UDP)

UDP offers a faster alternative by stripping away control overhead [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>). Its characteristics include:

- No flow or congestion control slowing down traffic [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>).
- No retransmissions of lost data [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>).
- Out-of-order arrival and data loss can be managed or tolerated at the application level (for instance, missing frames in an audio or video stream) [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>).

UDP is well-suited for real-time traffic where speed is prioritized over absolute reliability [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>).

### Protocol Comparison

| Protocol | Reliability | Flow/Congestion Control | Retransmissions | Typical Use Cases |
| --- | --- | --- | --- | --- |
| TCP | Reliable (sequence numbers & ACKs) [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>) | Yes (allows receiver/network to slow sender) [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>) | Yes [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>) | Email, web traffic, financial transactions [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>) |
| UDP | Unreliable (loss/out-of-order acceptable) [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>) | None [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>) | None [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>) | Real-time traffic, video/audio streams [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>) |

### Revision Takeaways

- TCP prioritizes data integrity, ordering, and congestion management via sequence numbers and ACKs [p. 45](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0045.png>).
- UDP prioritizes speed and low overhead, making it ideal for real-time applications that tolerate minor data loss [p. 46](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0046.png>).

## Upper Layers of the Network Model

#### Upper Layers Overview

The upper layers of the network architecture correspond to Layers 5 through 7 [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>). These layers deal directly with application-level communication, data formatting, and session coordination before passing information down to the transport and lower network services [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).

##### Session Layer

The Session Layer (Layer 5) is responsible for the management of sessions [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>). It coordinates communication dialogues and maintains connection states between applications running on different hosts [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).

##### Presentation Layer

The Presentation Layer (Layer 6) handles data translation, formatting, encryption, and compression [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>). By standardizing how data is represented, this layer ensures that information sent from the application layer of one system can be successfully interpreted by another system [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).

##### Application Layer

The Application Layer (Layer 7) provides the direct interface between user applications and lower network services [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>). It is the topmost layer where network-aware software applications access underlying communication infrastructure [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).

#### Web Server Example

A practical illustration of upper layer network communication involves web servers using the Hypertext Transfer Protocol (HTTP) [p. 48](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0048.png>). As depicted in the client-server interaction diagram, an HTTP client sends an HTTP request across the network to an HTTP server [p. 48](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0048.png>). The HTTP server processes the request and returns an HTTP response back to the client over a bidirectional communication channel [p. 48](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0048.png>).

#### Revision Takeaways

- Layer 5 (Session Layer) manages sessions and application dialogues [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).
- Layer 6 (Presentation Layer) handles translation, formatting, encryption, and compression [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).
- Layer 7 (Application Layer) acts as the user application interface to lower network services [p. 47](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0047.png>).
- HTTP client-server communication demonstrates upper layer request and response interactions [p. 48](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0048.png>).

## Web Servers Communication and Encapsulation Example

#### Client-Server Interaction and Port Usage

The interaction between a web client and a web server relies on transport-layer mechanisms to route data correctly [p. 49](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0049.png>). When an HTTP client sends a request, it uses an ephemeral port, which is a short-lived port assigned automatically by the operating system [p. 49](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0049.png>). Conversely, the web server listens on Port 80, which is the standard port number conventionally used to receive HTTP requests [p. 49](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0049.png>). Communication packets flow between the client's TCP layer and the server's TCP layer, carrying messages such as an HTTP GET request with destination port 80 and source ephemeral port, and returning a status response [p. 49](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0049.png>).

#### Data Encapsulation Layers

As an HTTP request descends through the network stack, it undergoes successive layers of encapsulation, where control headers and trailers are appended at each layer [p. 50](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0050.png>):

* **TCP Header**: Encapsulates the segment data, containing the source and destination port numbers to manage transport-layer multiplexing [p. 50](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0050.png>).
* **IP Header**: Encapsulates the TCP segment, containing the source and destination IP addresses along with the transport protocol type for network routing [p. 50](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0050.png>).
* **Ethernet Header and Frame Check Sequence**: Encapsulates the IP packet with an Ethernet header containing source and destination physical (MAC) addresses and the network protocol type, while the Frame Check Sequence ensures link-layer data integrity [p. 50](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0050.png>).

#### Revision Takeaways

* Clients communicate with web servers using ephemeral source ports and destination Port 80 [p. 49](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0049.png>).
* Data encapsulation wraps application payloads successively with TCP headers, IP headers, Ethernet headers, and a Frame Check Sequence [p. 50](<run/uploads/410d9ece9cc62917d08e59f6da5f7e78/459b7e3bbded864e84f4ab7cc56b7afbbfacae4e5b39430324bf32c9aadf0701/quality_v1/page_0050.png>).
