# Full-lecture study materials

iot lecture for testing.pdf

Processing coverage: 40/50 pages. This is not an accuracy score.

Page notes and transcriptions are model-generated drafts; original page images remain authoritative.

## Section 1: Internet-of-Things (IoT) Course Overview

### Course Identification

The course is titled Internet-of-Things (IoT) and is designated as CSCI410. It is offered by the School of Information Technology and Computer Science at Nile University.
Sources: 459b7e3bbded:p1

### Six-Week Structure

The curriculum is structured into six weeks, each pairing a lecture topic with a corresponding lab activity. The progression moves from basic concepts to advanced topics like security and final projects.
Sources: 459b7e3bbded:p2

### Networking Focus

Weeks 3 and 4 focus on networking, covering computer and wireless networks, Wi-Fi, Bluetooth, sensor networks, mesh networks, and routing protocols like ZigBee.
Sources: 459b7e3bbded:p2

### Cloud and Ecosystem

Week 5 covers the IoT cloud, analytics, and visualization, including sensor fusion. Week 6 addresses the broader IoT ecosystem, security, privacy, ethics, and trends.
Sources: 459b7e3bbded:p2

### Hardware and Software Integration

The course integrates hardware and software, starting with Raspberry Pi and Python in Week 1, moving to sensor programming and I/O in Week 2, and culminating in a final project.
Sources: 459b7e3bbded:p2

#### 459b7e3bbded:p1 (administrative)

Title slide for the Internet-of-Things (IoT) course (CSCI410) at Nile University, featuring a blue signal icon.

CSCI410
Nile University- School of Information Technology and Computer Science
Internet-of-Things (IoT)

#### 459b7e3bbded:p2 (content)

Course overview table listing lecture and lab topics for a six-week IoT curriculum, highlighting weeks 3 and 4 in orange.

Course Overview
Table columns: Week, Lecture, Lab.
Week 1: Fundamentals of IoT, basic concepts, applications | Basic Python programming, meet your Raspberry Pi
Week 2: Smart objects, user interfaces, sensing, actuation | Sensor programming, control loops, digital/analog I/O
Week 3: Fundamentals of computer and wireless networks | Wi-Fi and Bluetooth networks, network measurements
Week 4: Sensor networks, mesh networks, routing, WPANs | ZigBee, WPANs, WBANs, routing, network measurements
Week

## Section 3: Computer Network Terminology and Topologies

### Network Scale and Terminology

A network is defined as a group of computers and associated devices connected by communication facilities. The slide categorizes these by scale, ranging from world-wide WANs to city-scale MANs and laboratory-scale LANs.
Sources: 459b7e3bbded:p3

### Wireless Network Classifications

The slide distinguishes between wired and wireless network types. It identifies WLAN (Wi-Fi) as a wireless LAN, WPAN (Bluetooth) as a personal area network, and WBAN as a body area network.
Sources: 459b7e3bbded:p3

### Fully Connected Topology

The diagram illustrates a topology where every node is directly connected to every other node. This configuration provides high redundancy but requires a significant number of physical links between devices.
Sources: 459b7e3bbded:p4

### Star Network Topology

The diagram shows a central hub or switch connecting to multiple peripheral nodes. In this configuration, all communication between nodes typically passes through the central device, which is also linked to the Internet.
Sources: 459b7e3bbded:p4

### Ring Network Topology

The diagram depicts a topology where nodes are connected in a closed loop. Data travels in one direction from node to node until it reaches its destination, forming a circular path.
Sources: 459b7e3bbded:p4

#### 459b7e3bbded:p3 (content)

Defines computer network terminology, categorizing networks by scale (WAN, MAN, LAN) and listing wireless variants (WLAN, WPAN, WBAN).

Network: group of computers and associated devices that are connected by communication facilities. Wide Area Network (WAN): world-wide (Internet). Metropolitan Area Network (MAN): city-scale. Local Area Network (LAN): laboratory/office-scale (Ethernet). WLAN: wireless LAN (Wi-Fi). WPAN: wireless personal area network (Bluetooth). WBAN: wireless body area network.

#### 459b7e3bbded:p4 (content)

Illustrates five different network topologies: Fully Connected, Mesh, Common Bus, Star, and Ring, showing how nodes are physically or logically arranged.

Fully Connected Network Topology; Mesh Network Topology; Common Bus Topology; Star Network Topology (with Internet cloud); Ring; Ring Network Topology.

## Section 5: Network Protocols and IP Addressing

### Role of Protocols

Protocols are defined as the building blocks of a network architecture, serving as formal standards and policies that enable communication between network entities.
Sources: 459b7e3bbded:p5

### IEEE Standardization

The IEEE (Institute of Electrical and Electronics Engineers) is identified as a key standardization body. Project 802 is cited as an example, including 802.3 (Ethernet), 802.11 (WLAN), and 802.15 (WPAN).
Sources: 459b7e3bbded:p5

### IP Addressing Fundamentals

The slide introduces a fundamental activity: determining the network address and the host address from a given IP address, which is a core concept in IP addressing.
Sources: 459b7e3bbded:p6

#### 459b7e3bbded:p5 (content)

Introduces network protocols as building blocks of architecture and lists IEEE Project 802 standards for Ethernet, WLAN, and WPAN.

Protocols are the building blocks of a network architecture. Formal standards and policies enabling communication. IEEE (Institute of Electrical and Electronics Engineers): standardization. Example: Project 802: 802.3: Ethernet, 802.11: WLAN, 802.15: WPAN.

#### 459b7e3bbded:p6 (content)

Lists Part 1 (Fundamentals) and an activity asking how to determine network and host addresses from an IP address.

Part 1 (Fundamentals) Link. Activities: Given an IP address, how can we determine the network address and the host address?

## Section 7: Network Fundamentals and OSB Layers 3-7 Activities

### Switch-Only Network Topology

The slide poses a fundamental question regarding network topology: whether a home network can be constructed using only a switch. This implies an investigation into Layer 2 switching capabilities versus the need for routing or gateway functions.
Sources: 459b7e3bbded:p7

### Local PC Communication

This activity explores the mechanics of communication between two PCs, specifically using SSH as an example. It likely involves understanding local network discovery, ARP, and the establishment of a secure shell connection.
Sources: 459b7e3bbded:p7

### Gateway IP Discovery

The slide asks how to determine the network Gateway IP address. This is a critical concept for understanding how a local network connects to external networks and how default routes are configured.
Sources: 459b7e3bbded:p7

### Network Boundary Detection

This activity focuses on how a host (PC1) determines if a destination address (PC2) is outside its current network. This involves comparing the destination IP against the local subnet mask to decide whether to use the gateway.
Sources: 459b7e3bbded:p8

### Internet Routing and NAT

The slide presents a scenario where a local IP is included in a packet sent to a server. It asks how internet routers handle this, likely leading to a discussion on Network Address Translation (NAT) and how public vs. private addresses are managed.
Sources: 459b7e3bbded:p8

#### 459b7e3bbded:p7 (content)

Lists activities for Part 2 (Fundamentals), including questions about switch-only networks, PC communication via SSH, and identifying gateway IP addresses.

Part 2 (Fundamentals) Link
Activities:
Is it possible to set up a home network using only a switch?
How can two PCs communicate with each other using Ex:SSH?
How to send data packet between two different networks? Given
How to know your network Gateway ip address? Given

#### 459b7e3bbded:p8 (content)

Covers Part 2-2 (OSB Layers 3-7) activities, focusing on how a PC identifies out-of-network addresses and how internet routers handle local IP addresses.

Part 2-2 (OSB Layers 3-7) Link
Activity:
PC1 want sent send data to a destination PC2 how PC1 know that this address is out of my current network? Link
Activity:
PC1 wants to send data to a server on the internet. Given, If the local IP address of PC1 is included in the packet sent to the server, and the server responds with the source address as PC1's IP, how do the internet routers know the local IP address of PC1?Answer

## Section 9: Network Diagnostics and TCP Concepts

### HTTP GET Inspection

The slide outlines a practical method for understanding HTTP GET requests by inspecting a specific website (www.httpforever.com). It suggests using standard network diagnostic tools like ping and ifconfig to verify IP addresses, DNS servers, and routing paths.
Sources: 459b7e3bbded:p9

### Telnet HTTP Simulation

The text provides a specific command-line example using telnet to connect to a host on port 80. It demonstrates the manual entry of the HTTP request line 'GET /index.html' to simulate a browser request.
Sources: 459b7e3bbded:p9

### TCP Flow Control

The slide lists 'Delayed Ack' and 'Windows Size' alongside 'Flow Control'. This indicates that the lecture covers how TCP manages data flow and acknowledgment timing to optimize network performance and prevent congestion.
Sources: 459b7e3bbded:p10

### TCP Connection Lifecycle

The slide explicitly lists 'TCP Connection initialization', 'close', and 'reset'. These represent the fundamental state transitions of the TCP protocol, covering the setup, termination, and error-handling phases of a network connection.
Sources: 459b7e3bbded:p10

### Bidirectional Data Transfer

The slide mentions 'Bidirectional transfare' (sic) and 'Header data'. This highlights that TCP is a full-duplex protocol where data flows in both directions, and that the header contains essential metadata for managing the connection.
Sources: 459b7e3bbded:p10

#### 459b7e3bbded:p9 (content)

Part 3 of the lecture focuses on understanding HTTP GET requests by inspecting a website using ping, ifconfig, and telnet commands.

Part 3 (understand HTTP GET request) Link
Inspect: www.httpforever.com
ping:
Ifconfig
What is the ip address
what is the dns server used
what is the rout
EX: telnet www.httpforever.com 80
GET /index.html
Example: of SSH to PC to RP device

Uncertainty: The specific IP address or DNS server details are not provided in the text, only the questions to ask.

#### 459b7e3bbded:p10 (content)

A list of TCP/IP concepts including headers, acknowledgments, error handling, flow control, and the various states of a TCP connection.

heads and Acq) Link
Header data Link
Acq Link
Error Handling Link
Delayed Ack Link
Windows Size: Link
Flow Control: Link
Bidirectional transfare: Link
TCP Connection intialization: Link
TCP connection close: Link
TCP Connection reset: Link

Uncertainty: The term 'Acq' is likely a typo for 'Ack' (Acknowledgment).; The term 'transfare' is a typo for 'transfer'.

## Section 11: Network Protocols: TCP/UDP and TLS/SSL

### TCP vs UDP Comparison

The lecture outlines a comparison between UDP and TCP, specifically focusing on TCP's characteristics as a connection-oriented and reliable protocol. It also lists flow control, overheads, and common myths as key discussion points.
Sources: 459b7e3bbded:p11

### TLS/SSL Security Overview

This section introduces the Transport Layer Security (TLS) and Secure Sockets Layer (SSL) protocols. It covers how these protocols protect data and the roles of key players, including Certificate Authorities.
Sources: 459b7e3bbded:p12

### Security Properties

The slide lists specific security properties provided by SSL/TLS, including anti-replay mechanisms to prevent message duplication and non-repudiation to ensure senders cannot deny their actions.
Sources: 459b7e3bbded:p12

#### 459b7e3bbded:p11 (content)

A slide listing topics for Part 5 of a lecture, focusing on the comparison between UDP and TCP protocols.

Part 5 (UDP vs TCP) Link
Connection oriented
Reliable
 Flow Control
 Over Heads
 4 Myths

#### 459b7e3bbded:p12 (content)

A slide titled TLS/SSL listing various sub-topics related to security protocols, including data protection and certificate authorities.

TLS/SSL
Security SSL/TLS Link
Part2 : Link
How do SSL/TLS protect data: Link
Anti-Replay: Link
Non-Repudiation: Link
KeyPlayers: Link
Certificate Authority: Link

## Section 13: Communication and Protocols

### Protocol Design Questions

The slide lists fundamental questions defining a communication protocol, such as who initiates the exchange, the order of messages, and how interruptions or misunderstandings are handled.
Sources: 459b7e3bbded:p13

### Protocol Analogy

The slide illustrates that protocols are not limited to digital networks; a simple conversation follows a protocol with specific message sequences and responses.
Sources: 459b7e3bbded:p14

### TCP and HTTP Interaction

The diagram shows a client-server interaction where a TCP connection is established before an HTTP request is sent to retrieve a specific file.
Sources: 459b7e3bbded:p14

#### 459b7e3bbded:p13 (content)

A list of eight questions addressing the fundamental rules and behaviors required for effective communication between parties.

Who initiates communication?
Order of communication?
How long can I talk?
How loud can I speak?
Do I have to say something specific at beginning or end?
Do I have to add meta information?
What do I do if I get interrupted?
What do I do if I was not understood?

#### 459b7e3bbded:p14 (content)

A comparison between a human conversation and a computer network exchange, showing the sequence of messages over time.

Left: Hi, Hi, Got the time?, 2:00. Right: TCP connection request, TCP connection response, Get http://www.awl.com/kurose-ross, <file>. Vertical axis: time.

## Section 15: Client/Server Model

### Active Client Role

The client is defined as the 'active' entity that initiates communication. It sends a request to the server, which then processes it and sends a response back.
Sources: 459b7e3bbded:p15

### Passive Server Role

The server is defined as the 'passive' entity. It does not initiate contact but instead listens for incoming requests and responds to them when they arrive.
Sources: 459b7e3bbded:p15

### Request-Response Cycle

The interaction follows a specific sequence: the client sends a 'request' to the server, and the server returns a 'response' to the client, as shown by the dashed arrows.
Sources: 459b7e3bbded:p15

### Protocol Examples

The model is illustrated with five specific protocols: HTTP, SMTP, SSH, DNS, and NFS/AFS. These examples demonstrate the model's application across web, mail, and file systems.
Sources: 459b7e3bbded:p16

### Visual Representation

The slide uses a five-segment pie chart to visually represent the different protocols. Each segment is color-coded and labeled with the protocol's acronym and full name.
Sources: 459b7e3bbded:p16

#### 459b7e3bbded:p15 (content)

Defines the Client/Server Model, identifying the client as the active initiator and the server as the passive listener.

Diagram: 'Client' (rounded rectangle) and 'Server' (circle). Dashed arrow labeled 'request' points from Client to Server. Dashed arrow labeled 'response' points from Server to Client.

#### 459b7e3bbded:p16 (content)

Lists five examples of the Client/Server Model: HTTP, SMTP, SSH, DNS, and NFS/AFS, displayed in a pie chart.

Pie chart segments: HTTP (Hypertext Transfer Protocol), SMTP (Simple Mail Transfer Protocol), SSH (Secure Shell), DNS (Domain Name System), NFS/AFS (Network/Andrew File System).

## Section 17: Network Protocols: Protocol Stack and Encapsulation

### Protocol Stack Hierarchy

The protocol stack is a hierarchical model of network communication. It consists of seven distinct layers: Application, Presentation, Session, Transport, Network, Data Link, and Physical. Each layer provides services to the layer above it.
Sources: 459b7e3bbded:p17

### Network Layer Scope

The diagram illustrates that communication networks typically operate at the lower three layers of the stack: Network, Data Link, and Physical. The upper layers (Transport, Session, Presentation, Application) are generally handled by the end systems.
Sources: 459b7e3bbded:p17

### Encapsulation Process

As data moves down the protocol stack from the sender, each layer adds its own header (and sometimes trailer) to the data. This process is known as encapsulation. The headers are labeled ah, ph, sh, th, nh, and dh.
Sources: 459b7e3bbded:p18

### Data Link Layer Framing

The Data Link layer is unique in the diagram because it adds both a header (dh) and a trailer (dt) to the data unit. This is a common convention for framing data at the data link level.
Sources: 459b7e3bbded:p18

### Physical Layer Transmission

At the Physical layer, the final encapsulated data unit is converted into a stream of bits for transmission over the physical medium. This is the lowest level of the protocol stack.
Sources: 459b7e3bbded:p18

#### 459b7e3bbded:p17 (content)

Figure 2.6 illustrates the seven-layer protocol stack, showing how end systems communicate over a network that only implements the lower three layers.

Figure 2.6: Protocol Stack. Left and right stacks show Application, Presentation, Session, Transport, Network, Data Link, Physical layers. A central 'Communication Network' box contains Network, Data Link, and Physical layers. Dotted lines connect corresponding layers between the end systems and the network.

#### 459b7e3bbded:p18 (content)

The diagram shows the encapsulation process where headers (ah, ph, sh, th, nh, dh) and a trailer (dt) are added as data moves down the stack to bits.

Network Protocols (Headers/Trailers). Application A sends 'data'. As it passes down the stack, headers are added: ah (Application), ph (Presentation), sh (Session), th (Transport), nh (Network), dh (Data Link). A trailer 'dt' is also added at the Data Link layer. The final output is 'bits' at the Physical layer.

## Section 19: Layered Design and OSI Model

### Layered Design Benefits

Layered design provides an explicit structure for complex systems, simplifying the design process. It eases maintenance and updating of components through modularity and accommodates incremental changes.
Sources: 459b7e3bbded:p19

### OSI Model Structure

The OSI model is a seven-layer framework. Layers 7-5 are 'Upper Layers' (Application, Presentation, Session), while Layers 4-1 are 'Transport Service' (Transport, Network, Data Link, Physical).
Sources: 459b7e3bbded:p20

### Upper Layers Functions

The Application layer handles message formats and human-machine interfaces. The Presentation layer manages coding into 1s and 0s, encryption, and compression. The Session layer handles authentication, permissions, and session restoration.
Sources: 459b7e3bbded:p20

### Transport Service Functions

The Transport layer provides end-to-end error control. The Network layer handles network addressing, routing, or switching. The Data Link layer performs error detection and flow control on the physical link.
Sources: 459b7e3bbded:p20

### Physical Layer Function

The Physical layer (Layer 1) deals with the bit stream, the physical medium, and the method of representing bits.
Sources: 459b7e3bbded:p20

#### 459b7e3bbded:p19 (content)

Explains the rationale for layered design, highlighting its role in simplifying complex systems, easing maintenance through modularity, and accommodating incremental changes.

Title: Why A Layered Design?
1. An explicit structure for dealing with a complex system
2. Simplifies the design process
3. Modularity of layers eases maintenance and updating of system components
4. Accommodates incremental changes

#### 459b7e3bbded:p20 (content)

Presents the Open System Interconnection (OSI) model, detailing the seven layers from Application (7) to Physical (1) and their primary functions.

Title: Open System Interconnection (OSI)
7 Application Layer: Message format, Human-Machine Interfaces
6 Presentation Layer: Coding into 1s and 0s, encryption, compression
5 Session Layer: Authentication, permissions, session restoration
4 Transport Layer: End-to-end error control
3 Network Layer: Network addressing, routing or switching
2 Data Link Layer: Error detection, flow control on physical link
1 Physical Layer: Bit stream: physical medium, method of representing bits
Left labels: 7-

## Section 21: Physical Layer and Wireless Characteristics

### Physical Layer (Layer 1)

The physical layer (Layer 1) defines the hardware and electrical specifications for data transmission. It encompasses physical characteristics like cable types, connectors, voltage levels, and signal durations, as well as the conversion of binary data into electrical or optical signals.
Sources: 459b7e3bbded:p21

### Wireless Frequency Bands

The slide categorizes the electromagnetic spectrum into bands such as VLF, LF, MF, HF, VHF, UHF, SHF, and EHF, extending to infrared, visible light, and UV. It illustrates the inverse relationship between frequency and wavelength using the formula lambda = c/f.
Sources: 459b7e3bbded:p22

### Wavelength and Frequency Relationship

The relationship between wavelength (lambda), the speed of light (c), and frequency (f) is defined by the formula lambda = c/f. The speed of light is approximated as 3x10^8 m/s. The diagram shows how wavelength decreases as frequency increases across the spectrum.
Sources: 459b7e3bbded:p22

#### 459b7e3bbded:p21 (content)

Overview of the Physical Layer (Layer 1), detailing physical/electrical characteristics, binary data representation, and wireless frequencies.

Physical Layer (Layer 1)
Physical/electrical characteristics
Cable type, length, connectors, voltage levels, signal durations, ...
Binary data (bits) as electrical or optical signals
Frequencies (wireless)

#### 459b7e3bbded:p22 (content)

Defines wireless frequency bands (VLF to UV) and illustrates the relationship between wavelength and frequency using a spectrum diagram.

Wireless Characteristics
VLF = Very Low Frequency, LF = Low Frequency, MF = Medium Frequency, HF = High Frequency, VHF = Very High Frequency, UHF = Ultra High Frequency, SHF = Super High Frequency, EHF = Extra High Frequency, UV = Ultraviolet Light
Frequency and wave length
lambda = c/f
wave length lambda, speed of light c approx 3x10^8 m/s, frequency f
Diagram: 1 Mm (300 Hz) to 1 um (300 THz)

## Section 23: Frequencies and Propagation Effects in Mobile Communication

### Low Frequency Characteristics

Low frequencies enable long-distance travel, follow the Earth's surface, and penetrate objects and water, supporting submarine communication. However, they are characterized by low data rates.
Sources: 459b7e3bbded:p23

### High Frequency Characteristics

High frequencies support high data rates but travel in straight lines over short distances. They cannot penetrate objects, requiring a clear Line of Sight (LOS) for effective communication.
Sources: 459b7e3bbded:p23

### Shadowing

Shadowing occurs when a signal is blocked by a large obstacle, creating a region of reduced signal strength behind it.
Sources: 459b7e3bbded:p24

### Reflection and Refraction

Reflection happens when a signal bounces off a large obstacle, while refraction occurs when the signal bends due to changes in the density of the medium it travels through.
Sources: 459b7e3bbded:p24

### Scattering and Diffraction

Scattering is the dispersion of a signal by small obstacles, whereas diffraction is the bending of a signal around the edges of an obstacle.
Sources: 459b7e3bbded:p24

#### 459b7e3bbded:p23 (content)

Compares low and high frequencies for mobile communication, highlighting their respective data rates, travel distances, and penetration capabilities.

Two large blue arrows point in opposite directions. The left arrow (Low Frequencies) lists: low data rates, travel long distances, follow Earth's surface, penetrate objects and water (submarine communication). The right arrow (High Frequencies) lists: high data rates, short distances, straight lines, cannot penetrate objects ("Line of Sight" or LOS). Icons of a radio tower and a brick wall are shown between the arrows.

#### 459b7e3bbded:p24 (content)

Describes five other propagation effects: shadowing, reflection, refraction, scattering, and diffraction, with corresponding illustrative icons.

A list of five propagation effects: Shadowing, Reflection at large obstacles, Refraction depending on the density of a medium, Scattering at small obstacles, Diffraction at edges. Below the list are five icons: a brick wall (shadowing), a building (reflection), a signal bending through a medium (refraction), a stop sign (scattering), and a mountain (diffraction).

## Section 25: Real World Examples and Multipath Propagation

### Multipath Propagation

Signals travel via multiple routes due to reflection, scattering, and diffraction. This causes the received signal to be a superposition of delayed and attenuated versions of the transmitted signal.
Sources: 459b7e3bbded:p26

### Delay Spread

The time difference between the arrival of the first (Line-of-Sight) pulse and the last multipath pulse. It represents the temporal spread of the signal at the receiver.
Sources: 459b7e3bbded:p26

### Real-World Propagation Maps

The slide presents heatmaps of signal propagation in urban environments, showing how signal strength varies across different scales, from 20m to 123km.
Sources: 459b7e3bbded:p25

#### 459b7e3bbded:p25 (content)

Displays three heatmaps of real-world signal propagation in urban environments at different scales, ranging from 20 meters to 123 kilometers.

Three heatmaps showing signal propagation. Left: Urban grid, 20m scale. Middle: Urban grid, 1560m scale. Right: Wide area, 123km x 1460m scale. Credit: Central Munich.

Uncertainty: Specific signal metric (e.g., RSSI, path loss) is not labeled on the heatmaps.

#### 459b7e3bbded:p26 (content)

Illustrates multipath propagation where a signal takes multiple paths via reflection and diffraction, resulting in a spread of pulses at the receiver.

Diagram showing a signal at sender (pulse) traveling to a receiver (car) via a direct path and paths reflecting off a building and diffracting around a stop sign. The receiver shows 'LOS pulses' and 'multipath pulses' with a 'Delay Spread' label.

## Section 27: Digital Modulation and Data Link Layer

### Amplitude Shift Keying (ASK)

ASK is described as very simple with low bandwidth requirements but is very susceptible to interference. The diagram shows amplitude variations representing bits 1 and 0.
Sources: 459b7e3bbded:p27

### Frequency Shift Keying (FSK)

FSK requires a larger bandwidth than ASK. The diagram illustrates frequency changes to represent bits 1 and 0.
Sources: 459b7e3bbded:p27

### Phase Shift Keying (PSK)

PSK is noted as more complex but robust against interference. The diagram shows phase shifts in the carrier wave to represent bits 1 and 0.
Sources: 459b7e3bbded:p27

### Data Link Layer (Layer 2)

Layer 2 defines medium access and uses frames for error detection. It includes the MAC sublayer, which uses a 48-bit address (e.g., 6f:00:2b:23:1f:32).
Sources: 459b7e3bbded:p28

### Multiple Access Techniques

The slide illustrates FDMA (frequency division), TDMA (time division), and CDMA (code division) as methods for multiple access in communication systems.
Sources: 459b7e3bbded:p28

#### 459b7e3bbded:p27 (content)

Overview of digital modulation techniques including ASK, FSK, and PSK, detailing their complexity, bandwidth, and interference characteristics.

Three waveforms plotted against time (t) for bits 1, 0, 1. ASK shows amplitude changes; FSK shows frequency changes; PSK shows phase changes.

#### 459b7e3bbded:p28 (content)

Introduction to the Data Link Layer (Layer 2), covering frames, MAC sublayer, and multiple access techniques like FDMA, TDMA, and CDMA.

Diagram showing FDMA (Frequency vs Time), TDMA (Time slots 1, 2, 3), and CDMA (Spread code 1, Code 3).

## Section 29: Ethernet and CSMA/CD Protocol

### Ethernet (802.3) Overview

Ethernet (802.3) is described as the most popular LAN technology. It utilizes a bus architecture, which is characterized as easy to install and inexpensive. Data transmission involves breaking information into packets.
Sources: 459b7e3bbded:p29

### MAC Protocol

The Medium Access Control (MAC) protocol is the mechanism used to manage access to the network medium. It is specifically implemented in Ethernet using the CSMA/CD protocol.
Sources: 459b7e3bbded:p30

### CSMA/CD Protocol

CSMA/CD is a protocol consisting of three main components: Carrier Sense (listening to the medium), Multiple Access (shared medium usage), and Collision Detection (identifying signal interference).
Sources: 459b7e3bbded:p30

### Collision Detection

The diagram illustrates a collision occurring on the bus. Node A transmits a signal (blue arrow) while Node B transmits a signal (purple arrow). These signals meet at Node C, resulting in a collision.
Sources: 459b7e3bbded:p30

#### 459b7e3bbded:p29 (content)

Introduces Ethernet (802.3) as a popular, inexpensive LAN technology using a bus architecture where data is broken into packets.

Diagram shows two horizontal lines labeled 'Ethernet bus segment' connected by a central box. Each segment connects to multiple computer icons.

#### 459b7e3bbded:p30 (content)

Details the Medium Access Control (MAC) protocol and the CSMA/CD protocol, specifically Carrier Sense, Multiple Access, and Collision Detection.

Diagram shows nodes A, B, and C on a line. A blue arrow points from A to C, and a purple arrow points from B to C. A red starburst labeled 'collision' is at C.

## Section 31: Ethernet and Wi-Fi

### Carrier Sense

A node listens to the medium to determine if it is busy or idle. If idle, it transmits; if busy, it waits. This is the first step in the Carrier Sense Multiple Access (CSMA) protocol.
Sources: 459b7e3bbded:p31

### Collision Detection

While transmitting, the node continues to listen to the medium. If a collision is detected, the node stops transmitting and retries at a later time.
Sources: 459b7e3bbded:p31

### Ethernet Topology

The diagram shows a shared medium where a signal from node A travels toward node C. Node B, located in the middle, is shown with a thought bubble saying "Don't transmit," indicating it senses the carrier.
Sources: 459b7e3bbded:p31

### Wi-Fi Topology

The diagram illustrates a central access point connected to multiple computers via wireless links. This is the most popular wireless LAN architecture.
Sources: 459b7e3bbded:p32

### Wi-Fi Terminology

The slide lists several terms that are synonymous with the central device in a Wi-Fi network: Access point, Wi-Fi router, Base station, and Hotspot.
Sources: 459b7e3bbded:p32

#### 459b7e3bbded:p31 (content)

Describes Ethernet's carrier sense mechanism, where nodes listen before transmitting and detect collisions during transmission.

Diagram shows nodes A, B, and C on a shared medium. A signal from A travels toward C. Node B has a thought bubble: "Don't transmit". A label asks: "Can collisions still occur?"

#### 459b7e3bbded:p32 (content)

Introduces Wi-Fi (802.11) as the most popular wireless LAN architecture, showing a central access point connected to multiple computers.

Diagram shows a central "Access Point" connected to five "Computer" icons via wireless links. Text lists: Access point, Wi-Fi router, Base station, Hotspot.

## Section 33: Wi-Fi CSMA/CA and Network Layer IP

### CSMA/CA Protocol

CSMA/CA is a Wi-Fi protocol using carrier sense and collision avoidance. It reserves the channel via RTS/CTS handshakes, ensuring nodes hearing these signals remain quiet to prevent data loss.
Sources: 459b7e3bbded:p33

### Hidden Node Collision

The diagram illustrates a collision scenario where nodes A and C transmit to B simultaneously. This visualizes the need for collision avoidance mechanisms in shared media networks.
Sources: 459b7e3bbded:p33

### Internet Protocol (IP)

IP is the dominant Layer 3 protocol responsible for addressing and routing. It utilizes a 32-bit hierarchical address space where location information is embedded in the structure.
Sources: 459b7e3bbded:p34

### IPv4 Addressing

IPv4 addresses are 4-byte identifiers split into Network ID and Host ID. They are typically represented in dotted-decimal notation, such as 128.100.11.56, to facilitate human readability.
Sources: 459b7e3bbded:p34

#### 459b7e3bbded:p33 (content)

Describes the CSMA/CA protocol for Wi-Fi, detailing carrier sense, collision avoidance, and the RTS/CTS channel reservation mechanism with a collision diagram.

Diagram shows nodes A, B, and C. Dashed circles indicate transmission ranges. Arrows point from A to B and C to B, meeting at a 'Collision' starburst.

#### 459b7e3bbded:p34 (content)

Introduces the Network Layer (Layer 3) and the Internet Protocol (IP), explaining its role in addressing, routing, and the 32-bit hierarchical address structure.

Box diagram labeled 'Network ID' and 'Host ID' with a bracket below indicating '4 bytes'. Example address: 128.100.11.56.

## Section 35: IPv4 and Network Protocols

### CIDR Notation

CIDR notation (e.g., 192.168.1.10/24) specifies the number of bits used for the network portion, replacing fixed subnet masks like 255.255.255.0.
Sources: 459b7e3bbded:p35

### Classful Addressing

IPv4 addresses are divided into network and host portions. Class A uses 8 network bits, Class B uses 16, and Class C uses 24.
Sources: 459b7e3bbded:p35

### Protocol Stack

The protocol stack organizes communication into layers: Application, Presentation, Session, Transport, Network, Data Link, and Physical.
Sources: 459b7e3bbded:p36

### Communication Network

The communication network consists of intermediate nodes that handle the Network, Data Link, and Physical layers, while end systems handle all seven layers.
Sources: 459b7e3bbded:p36

### Subnet Masks

Subnet masks define the boundary between network and host bits. For example, Class A uses 255.0.0.0, Class B uses 255.255.0.0, and Class C uses 255.255.255.0.
Sources: 459b7e3bbded:p35

#### 459b7e3bbded:p35 (content)

Explains IPv4 CIDR notation and classful addressing with subnet masks for Classes A, B, and C.

Class A: 8 network bits, 24 host bits, mask 255.0.0.0. Class B: 16 network bits, 16 host bits, mask 255.255.0.0. Class C: 24 network bits, 8 host bits, mask 255.255.255.0.

#### 459b7e3bbded:p36 (content)

Illustrates the network protocol stack, showing layers in end systems and the communication network.

End systems have Application, Presentation, Session, Transport, Network, Data Link, and Physical layers. The communication network has Network, Data Link, and Physical layers.

## Section 37: Network Protocols and Routers

### Protocol Stacks

The OSI model defines seven layers (Physical to Application) for network communication. The TCP/IP model maps these into four layers, grouping OSI layers 1-2 into Network Access and 3-4 into Internet/Transport.
Sources: 459b7e3bbded:p37

### Transport Layer

The Transport layer (OSI 4) ensures reliable delivery of entire files or messages. TCP provides delivery assurance, while UDP does not, prioritizing speed over reliability.
Sources: 459b7e3bbded:p37

### Network Layer

The Network layer (OSI 3) routes data to different LANs and WANs based on network addresses. It handles logical addressing and path selection across different networks.
Sources: 459b7e3bbded:p37

### Router Function

Routers form the Internet's backbone. They use the IP layer to identify packet source and destination, then consult routing tables to determine the 'next hop' for forwarding.
Sources: 459b7e3bbded:p38

### Routing Tables

A routing table maps destination IP prefixes to specific next-hop addresses. For example, traffic destined for 147.39.21.X is forwarded to the next hop at 131.19.18.121.
Sources: 459b7e3bbded:p38

#### 459b7e3bbded:p37 (content)

Compares the 7-layer OSI model with the 4-layer TCP/IP model, detailing the function of each layer and associated protocols.

OSI Model: 7 Application (E-mail, file transfer), 6 Presentation (Encryption, data conversion), 5 Session (Starts, stops session), 4 Transport (Reliable delivery), 3 Network (Routes data), 2 Data Link (Transmits packets), 1 Physical (Electrical signals). TCP/IP: Application (FTP, Telnet, HTTP, SMTP, SNMP, DNS, OSPF, RIP, Ping, Traceroute), Transport (TCP, UDP), Network (IP, ICMP, IGMP, ARP, RARP), Link (Ethernet/Wi-Fi).

#### 459b7e3bbded:p38 (content)

Explains that routers form the Internet backbone, using IP layers and routing tables to determine the next hop for packets.

Diagram shows Autonomous Systems (AS 1-5) connected by routers. Routing Table: Destination 147.39.21.X -> Next Hop 131.19.18.121; 89.44.X.X -> 131.19.22.119; 203.21.X.X -> 137.18.47.48. Commands: Traceroute/mtr, Ping, ifconfig, nslookup www.google.com, grep "nameserver" /etc/resolv.conf.

## Section 39: Transport Layer (Layer 4) Transfrare Protocols

### Port Addressing

The Transport Layer (Layer 4) uses ports to identify specific applications on a computer, complementing the IP address which identifies the computer itself. For example, a web server listens on port 80.
Sources: 459b7e3bbded:p39

### UDP Header Structure

The UDP header consists of four fields: Source Port, Destination Port, Length, and Checksum. This header is prepended to the data payload to form a UDP datagram.
Sources: 459b7e3bbded:p39

### UDP Unreliability

UDP is an unreliable transport protocol. It does not guarantee delivery or ordering; packets can be lost during transmission or arrive at the destination out of their original sequence.
Sources: 459b7e3bbded:p39

### Communication Modes

The diagram illustrates three communication modes: Unicast (one-to-one), Broadcast (one-to-all), and Multicast (one-to-several). These describe how a sender can transmit data to different sets of receivers.
Sources: 459b7e3bbded:p40

### UDP Request/Response

The slide depicts a basic interaction where a sender transmits a request to a receiver, which then sends back multiple responses. This illustrates the fundamental data exchange process in UDP.
Sources: 459b7e3bbded:p40

#### 459b7e3bbded:p39 (content)

Introduces UDP, explaining port addressing and the unreliable nature of the protocol. Includes a diagram of the UDP header structure.

UDP Header: [Source Port] [Destination Port] [Length] [Checksum] [Data]

#### 459b7e3bbded:p40 (content)

Illustrates how UDP works with a request/response diagram and defines unicast, broadcast, and multicast communication modes.

Sender -> Receiver (Request/Response). Unicast (One-to-One), Broadcast (One-to-All), Multicast (One-to-Several).
