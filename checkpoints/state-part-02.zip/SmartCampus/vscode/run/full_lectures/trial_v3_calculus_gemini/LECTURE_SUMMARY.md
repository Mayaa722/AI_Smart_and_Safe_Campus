# Lecture Overview: Hyperbolic Functions

## Introduction and Definitions

Hyperbolic functions are analogues of ordinary trigonometric functions, defined in terms of exponential functions [p. 3](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0003.png>). The fundamental definitions for the hyperbolic sine (sinh), hyperbolic cosine (cosh), and hyperbolic tangent (tanh) are given by:

- sinh(x) = (e^x - e^(-x)) / 2 [p. 3](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0003.png>)
- cosh(x) = (e^x + e^(-x)) / 2 [p. 3](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0003.png>)
- tanh(x) = sinh(x) / cosh(x) = (e^x - e^(-x)) / (e^x + e^(-x)) [p. 3](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0003.png>)

In addition to the primary three, reciprocal hyperbolic functions are defined with specific domain restrictions [p. 4](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0004.png>):

- Cothangent: coth(x) = cosh(x) / sinh(x) = (e^x + e^(-x)) / (e^x - e^(-x)), for x != 0 [p. 4](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0004.png>)
- Secant: sech(x) = 1 / cosh(x) = 2 / (e^x + e^(-x)) [p. 4](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0004.png>)
- Cosecant: csch(x) = 1 / sinh(x) = 2 / (e^x - e^(-x)), for x != 0 [p. 4](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0004.png>)

## Identities and Symmetry

Hyperbolic functions satisfy various identities derived directly from their exponential definitions [p. 9](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0009.png>). Key foundational relationships include:

- cosh(x) + sinh(x) = e^x [p. 5](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0005.png>)
- cosh(x) - sinh(x) = e^(-x) [p. 6](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0006.png>)
- cosh^2(x) - sinh^2(x) = 1 [p. 9](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0009.png>)

Dividing the fundamental pythagorean-like identity by cosh^2(x) or sinh^2(x) yields secondary identities such as 1 - tanh^2(x) = sech^2(x) and coth^2(x) - 1 = csch^2(x) [p. 9](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0009.png>). Regarding symmetry, cosh(x) is an even function (cosh(-x) = cosh(x)), whereas sinh(x) and tanh(x) are odd functions (sinh(-x) = -sinh(x) and tanh(-x) = -tanh(x)) [p. 7](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0007.png>) [p. 8](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0008.png>). Sum-and-difference formulas as well as double-angle formulas also parallel standard trigonometry with minor sign adjustments [p. 11](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0011.png>) [p. 12](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0012.png>).

## Derivatives of Hyperbolic Functions

The derivatives of the six basic hyperbolic functions follow systematic rules that can be proved using exponential definitions or quotient rules [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>) [p. 16](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0016.png>) [p. 18](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0018.png>):

- d/dx (sinh x) = cosh(x) [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>)
- d/dx (cosh x) = sinh(x) [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>)
- d/dx (tanh x) = sech^2(x) [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>)
- d/dx (coth x) = -csch^2(x) [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>)
- d/dx (sech x) = -sech(x)tanh(x) [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>) [p. 18](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0018.png>)
- d/dx (csch x) = -csch(x)coth(x) [p. 15](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0015.png>)

When combined with composite functions, the chain rule applies directly to these derivative formulas [p. 19](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0019.png>).

## Graphs and Applications

Visualizing the graphs of hyperbolic functions highlights their asymptotic behavior and ranges [p. 29](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0029.png>). For instance, tanh(x) features horizontal asymptotes at y = 1 and y = -1 as x approaches positive and negative infinity [p. 26](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0026.png>). Real-world applications of hyperbolic functions include modeling physical structures like hanging chains and power lines, which form curves known as catenaries [p. 30](<run/uploads/c566826f7762438a6ba47d3bf824ea3d/5c422a3cc4fa1f36ea3946707d85a1a22acb326e3365ef97d793fe5f7b117634/quality_v1/page_0030.png>).
