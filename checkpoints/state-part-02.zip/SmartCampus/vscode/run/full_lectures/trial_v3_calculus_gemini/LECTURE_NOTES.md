# Full-lecture study materials

calculus for testing.pdf

Processing coverage: 33/33 pages. This is not an accuracy score.

Page notes and transcriptions are model-generated drafts; original page images remain authoritative.

## Section 1: Analytical Geometry and Calculus I Lecture 4

### Hyperbolic Functions Outline

The lecture introduces hyperbolic functions, focusing on their formal definitions, fundamental identities, derivative rules, and graphical representations.
Sources: 5c422a3cc4fa:p2

#### 5c422a3cc4fa:p1 (administrative)

Title slide for Lecture (4) of Analytical Geometry & Calculus I (MATH 111i) at Nile University.

Lecture (4) 1 Nile University Analytical Geometry & Calculus I MATH 111i

#### 5c422a3cc4fa:p2 (content)

Outline slide introducing Hyperbolic Functions, covering their definitions, identities, derivatives, and graphs.

Outline 2 Hyperbolic Functions Definition of Hyperbolic Functions Identities of Hyperbolic Functions Derivatives of Hyperbolic Functions Graphs of Hyperbolic Functions

## Section 3: Definition of Hyperbolic Functions

### Hyperbolic Sine

Hyperbolic sine, denoted as sinh(x), is defined as (e^x - e^(-x)) / 2 [5c422a3cc4fa:p3].
Sources: 5c422a3cc4fa:p3

### Hyperbolic Cosine

Hyperbolic cosine, denoted as cosh(x), is defined as (e^x + e^(-x)) / 2 [5c422a3cc4fa:p3].
Sources: 5c422a3cc4fa:p3

### Hyperbolic Tangent

Hyperbolic tangent, denoted as tanh(x), is defined as the ratio of sinh(x) to cosh(x), resulting in (e^x - e^(-x)) / (e^x + e^(-x)) [5c422a3cc4fa:p3].
Sources: 5c422a3cc4fa:p3

### Hyperbolic Cotangent

Hyperbolic cotangent, denoted as coth(x), is the reciprocal of tanh(x), defined as cosh(x) / sinh(x) for x != 0 [5c422a3cc4fa:p4].
Sources: 5c422a3cc4fa:p4

### Hyperbolic Secant and Cosecant

Hyperbolic secant sech(x) and cosecant csch(x) are reciprocals of cosh(x) and sinh(x) respectively, with csch(x) restricted to x != 0 [5c422a3cc4fa:p4].
Sources: 5c422a3cc4fa:p4

#### 5c422a3cc4fa:p3 (content)

This slide defines the basic hyperbolic functions: hyperbolic sine (sinh), hyperbolic cosine (cosh), and hyperbolic tan (tanh) in terms of exponential functions.

Hyperbolic Sine: sinh(x) = (e^x - e^(-x)) / 2
Hyperbolic Cosine: cosh(x) = (e^x + e^(-x)) / 2
Hyperbolic Tan: tanh(x) = sinh(x) / cosh(x) = (e^x - e^(-x)) / (e^x + e^(-x))

#### 5c422a3cc4fa:p4 (content)

This slide defines the reciprocal hyperbolic functions: hyperbolic cotangent (coth), hyperbolic secant (sech), and hyperbolic cosecant (csch), along with their domain restrictions.

Hyperbolic Cot: coth(x) = cosh(x) / sinh(x) = (e^x + e^(-x)) / (e^x - e^(-x)), x != 0
Hyperbolic Sec: sech(x) = 1 / cosh(x) = 2 / (e^x + e^(-x))
Hyperbolic Cosec: csch(x) = 1 / sinh(x) = 2 / (e^x - e^(-x)), x != 0

## Section 5: Identities of Hyperbolic Functions

### Hyperbolic Identity Addition

The sum of the hyperbolic cosine and hyperbolic sine functions equals e^x, proven by substituting their exponential definitions and simplifying the numerator.
Sources: 5c422a3cc4fa:p5

### Hyperbolic Identity Subtraction

The difference between the hyperbolic cosine and hyperbolic sine functions equals e^-x, proven by substituting their exponential definitions and combining terms.
Sources: 5c422a3cc4fa:p6

### Definition-Based Proofs

Proofs involving hyperbolic functions require utilizing their foundational exponential definitions to substitute and algebraically manipulate terms.
Sources: 5c422a3cc4fa:p5, 5c422a3cc4fa:p6

#### 5c422a3cc4fa:p5 (content)

Demonstrates the proof for the hyperbolic identity cosh x + sinh x = e^x by substituting the exponential definitions of cosh x and sinh x and simplifying.

cosh x + sinh x = (e^x + e^-x)/2 + (e^x - e^-x)/2 = (e^x + e^-x + e^x - e^-x)/2 = 2e^x/2 = e^x

#### 5c422a3cc4fa:p6 (content)

Demonstrates the proof for the hyperbolic identity cosh x - sinh x = e^-x by substituting the exponential definitions of cosh x and sinh x and simplifying.

cosh x - sinh x = (e^x + e^-x)/2 - (e^x - e^-x)/2 = (e^x + e^-x - e^x + e^-x)/2 = 2e^-x/2 = e^-x

## Section 7: Identities of Hyperbolic Functions

### Hyperbolic Cosine Even Identity

The hyperbolic cosine function satisfies cosh(-x) = cosh(x), making it an even function. This is proven directly using its exponential definition (e^x + e^(-x))/2 [5c422a3cc4fa:p7].
Sources: 5c422a3cc4fa:p7

### Hyperbolic Sine and Tangent Odd Identities

The hyperbolic sine and tangent functions satisfy sinh(-x) = -sinh(x) and tanh(-x) = -tanh(x), respectively, making them odd functions [5c422a3cc4fa:p7].
Sources: 5c422a3cc4fa:p7

#### 5c422a3cc4fa:p7 (content)

This slide outlines identities of hyperbolic functions, stating that cosh is an even function while sinh and tanh are odd functions, and demonstrates the proof that cosh(-x) = cosh(x) using exponential definitions.

Identities of Hyperbolic Functions
Prove that
cosh(-x) = cosh(x) ( even )
sinh(-x) = -sinh(x) ( odd )
tanh(-x) = -tanh(x) ( odd )
Proof
cosh(x) = (e^x + e^(-x)) / 2
cosh(-x) = (e^(-x) + e^(-(-x))) / 2 = (e^(-x) + e^x) / 2 = cosh(x)
Even function

## Section 8: Identities of Hyperbolic Functions

### Hyperbolic Sine Odd Function Identity

The hyperbolic sine function satisfies sinh(-x) = -sinh(x), making it an odd function. This can be proven using its exponential definition sinh(x) = (e^x - e^(-x)) / 2 [5c422a3cc4fa:p8].
Sources: 5c422a3cc4fa:p8

### Hyperbolic Cosine Even Function Identity

The hyperbolic cosine function satisfies cosh(-x) = cosh(x), making it an even function [5c422a3cc4fa:p8].
Sources: 5c422a3cc4fa:p8

### Hyperbolic Tangent Odd Function Identity

The hyperbolic tangent function satisfies tanh(-x) = -tanh(x), making it an odd function [5c422a3cc4fa:p8].
Sources: 5c422a3cc4fa:p8

#### 5c422a3cc4fa:p8 (content)

This slide states the identities for hyperbolic functions showing cosh(-x) is even, while sinh(-x) and tanh(-x) are odd. It provides an exponential definition proof for sinh(-x) = -sinh(x).

Identities of Hyperbolic Functions
cosh(-x) = cosh(x) ( even )
sinh(-x) = -sinh(x) ( odd )
tanh(-x) = -tanh(x) ( odd )
Proof
sinh(x) = (e^x - e^(-x)) / 2
sinh(-x) = (e^(-x) - e^(-(-x))) / 2 = (e^(-x) - e^x) / 2 = -sinh(x)
Odd function

## Section 9: Identities of Hyperbolic Functions

### Pythagorean Hyperbolic Identity

The fundamental hyperbolic identity states that cosh^2(x) - sinh^2(x) = 1. This can be proven algebraically by expressing hyperbolic cosine and sine in terms of exponential definitions: ((e^x + e^(-x))/2)^2 - ((e^x - e^(-x))/2)^2 = 1.
Sources: 5c422a3cc4fa:p9

### Derived Hyperbolic Identities

Dividing the principal Pythagorean hyperbolic identity cosh^2(x) - sinh^2(x) = 1 by cosh^2(x) yields 1 - tanh^2(x) = sech^2(x). Dividing instead by sinh^2(x) yields coth^2(x) - 1 = csch^2(x).
Sources: 5c422a3cc4fa:p9

### Hyperbolic Identity Proof via Quotients

Hyperbolic identities involving tanh(x) can be proven by expressing tanh(x) as the quotient sinh(x) / cosh(x), combining terms into a single fraction, and utilizing sum/difference definitions to simplify expressions like (cosh x - sinh x) / (cosh x + sinh x) into exponentials.
Sources: 5c422a3cc4fa:p10

#### 5c422a3cc4fa:p9 (content)

This page introduces hyperbolic identities, specifically establishing that cosh^2(x) - sinh^2(x) = 1, alongside derived identities like 1 - tanh^2(x) = sech^2(x) and coth^2(x) - 1 = csch^2(x), and provides an exponential proof for cosh^2(x) - sinh^2(x) = 1.

(3) cosh^2 x - sinh^2 x = 1
1 - tanh^2 x = sech^2 x , coth^2 x - 1 = csch^2 x
Proof cosh^2 x - sinh^2 x = 1
((e^x + e^(-x)) / 2)^2 - ((e^x - e^(-x)) / 2)^2 = (e^(2x) + 2 + e^(-2x)) / 4 - (e^(2x) - 2 + e^(-2x)) / 4 = 4 / 4 = 1

#### 5c422a3cc4fa:p10 (content)

This page demonstrates an example proof for the hyperbolic identity (1 - tanh(x)) / (1 + tanh(x)) = e^(-2x) by rewriting tanh(x) in terms of sinh(x) and cosh(x), simplifying fractions, and converting to exponential form.

Example Prove that (1 - tanh x) / (1 + tanh x) = e^(-2x)
(1 - tanh x) / (1 + tanh x) = (1 - (sinh x / cosh x)) / (1 + (sinh x / cosh x))
= (cosh x - sinh x) / (cosh x + sinh x) = e^(-x) / e^x = e^(-2x)

## Section 11: Identities of Hyperbolic Functions

### Hyperbolic Double-Angle Sine Identity

The double-angle identity for hyperbolic sine states that sinh 2x equals 2 sinh x cosh x.
Sources: 5c422a3cc4fa:p11

### Hyperbolic Double-Angle Cosine Identity

The double-angle identity for hyperbolic cosine states that cosh 2x equals cosh^2 x plus sinh^2 x.
Sources: 5c422a3cc4fa:p11

### Hyperbolic Half-Angle Cosine Identity

The half-angle identity for cosh^2 x is expressed as one-half times the quantity cosh 2x plus 1.
Sources: 5c422a3cc4fa:p11

### Hyperbolic Half-Angle Sine Identity

The half-angle identity for sinh^2 x is expressed as one-half times the quantity cosh 2x minus 1.
Sources: 5c422a3cc4fa:p11

#### 5c422a3cc4fa:p11 (content)

This lecture slide lists double-angle and half-angle identities of hyperbolic functions for students to prove.

Identities of Hyperbolic Functions
11
Prove that
sinh 2x = 2 sinh x cosh x
cosh 2x = cosh^2 x + sinh^2 x
cosh^2 x = (1/2)(cosh 2x + 1)
sinh^2 x = (1/2)(cosh 2x - 1)
Try

## Section 12: Identities of Hyperbolic Functions

### Hyperbolic Sine Addition/Subtraction Identity

The identity states that sinh(x +/- y) equals sinh(x) cosh(y) +/- cosh(x) sinh(y).
Sources: 5c422a3cc4fa:p12

### Hyperbolic Cosine Addition/Subtraction Identity

The identity states that cosh(x +/- y) equals cosh(x) cosh(y) +/- sinh(x) sinh(y).
Sources: 5c422a3cc4fa:p12

### Hyperbolic Tangent Addition/Subtraction Identity

The identity states that tanh(x +/- y) is given by the fraction (tanh(x) +/- tanh(y)) / (1 +/- tanh(x) tanh(y)).
Sources: 5c422a3cc4fa:p12

#### 5c422a3cc4fa:p12 (content)

This lecture slide lists addition and subtraction sum-and-difference identities for hyperbolic sine, cosine, and tangent functions.

(4) sinh(x +/- y) = sinh(x) cosh(y) +/- cosh(x) sinh(y), cosh(x +/- y) = cosh(x) cosh(y) +/- sinh(x) sinh(y), tanh(x +/- y) = (tanh(x) +/- tanh(y)) / (1 +/- tanh(x) tanh(y))

## Section 13: Identities of Hyperbolic Functions

### Hyperbolic Function Identity Proof

The slide demonstrates the logarithmic identity for hyperbolic functions by simplifying ln(cosh nx + sinh nx) to ln(e^(nx)), which evaluates to nx.
Sources: 5c422a3cc4fa:p13

#### 5c422a3cc4fa:p13 (content)

This slide presents an example proving a hyperbolic function identity involving the natural logarithm of the sum of cosh nx and sinh nx.

Identities of Hyperbolic Functions
Example () Prove that ln(cosh nx + sinh nx)
ln(cosh nx + sinh nx) = ln e^(nx) = nx

## Section 14: Identities of Hyperbolic Functions

### Hyperbolic Cosine Definition

The hyperbolic cosine function is defined in terms of exponential functions as cosh(x) = (e^x + e^(-x)) / 2.
Sources: 5c422a3cc4fa:p14

### Hyperbolic Function Identity Proof

To prove identities involving hyperbolic functions and logarithms, express the hyperbolic function using exponentials, apply logarithm rules like e^(ln x) = x and e^(-ln x) = e^(ln(1/x)) = 1/x, and simplify the algebraic fractions.
Sources: 5c422a3cc4fa:p14

#### 5c422a3cc4fa:p14 (content)

This slide demonstrates an example proof involving hyperbolic functions, specifically showing that cosh(ln x) equals (x^2 + 1) / (2x) by applying the exponential definition of cosh and logarithmic properties.

Identities of Hyperbolic Functions (14) Example () Prove that cosh(ln x) = (x^2 + 1) / (2x)

## Section 15: Derivatives of Hyperbolic Functions

### Derivative of sinh(x)

The derivative of sinh(x) with respect to x is cosh(x), which can be proven by expressing sinh(x) in terms of exponential functions and taking the derivative.
Sources: 5c422a3cc4fa:p15, 5c422a3cc4fa:p16

### Derivative of cosh(x)

The derivative of cosh(x) with respect to x is equal to sinh(x).
Sources: 5c422a3cc4fa:p15

### Derivative of tanh(x)

The derivative of tanh(x) with respect to x is given as sec h^2(x).
Sources: 5c422a3cc4fa:p15

### Derivative of coth(x)

The derivative of coth(x) with respect to x is given as negative csch^2(x).
Sources: 5c422a3cc4fa:p15

### Derivative of sec h(x) and csch(x)

The derivative of sech(x) is -sech(x)tanh(x) and the derivative of csch(x) is -csch(x)coth(x).
Sources: 5c422a3cc4fa:p15

#### 5c422a3cc4fa:p15 (content)

This slide lists the derivatives for the six fundamental hyperbolic functions: sinh, cosh, tanh, coth, sech, and csch.

d/dx(sinh x) = cosh x, d/dx(cosh x) = sinh x, d/dx(tanh x) = sec h^2 x, d/dx(coth x) = -cs c h^2 x, d/dx(sec hx) = -sec h x tanh x, d/dx(cs c hx) = -cs c h x coth x

#### 5c422a3cc4fa:p16 (content)

This slide shows a proof for the derivative of the hyperbolic sine function using its exponential definition.

[sinh x]' = [(e^x - e^-x) / 2]' = (e^x + e^-x) / 2 = cosh x

## Section 17: Derivatives of Hyperbolic Functions

### Derivative of Hyperbolic Tangent

The derivative of tanh(x) is derived by expressing it as sinh(x) divided by cosh(x) and applying the quotient rule, resulting in sech^2(x).
Sources: 5c422a3cc4fa:p17

### Hyperbolic Identity

The fundamental hyperbolic identity cosh^2(x) - sinh^2(x) = 1 is used to simplify the numerator during the derivation of the derivative of tanh(x).
Sources: 5c422a3cc4fa:p17

#### 5c422a3cc4fa:p17 (content)

This slide presents the proof for the derivative of the hyperbolic tangent function using the quotient rule and fundamental hyperbolic identities.

Proofs
[tanh x]' = [sinh x / cosh x]'
= [cosh x (cosh x) - sinh x (sinh x)] / cosh^2 x
= [cosh^2 x - sinh^2 x] / cosh^2 x
= 1 / cosh^2 x = sech^2 x

## Section 18: Derivatives of Hyperbolic Functions

### Derivative of Hyperbolic Secant

The derivative of sech(x) with respect to x is proven by rewriting it as 1/cosh(x) and applying the quotient rule, resulting in -sech(x)tanh(x).
Sources: 5c422a3cc4fa:p18

#### 5c422a3cc4fa:p18 (content)

This slide provides a step-by-step mathematical proof for the derivative of the hyperbolic secant function, showing that the derivative of sech(x) equals -sech(x)tanh(x) using the quotient rule.

Proofs
[sech x]' = [1 / (cosh x)]'
= (0 - sinh x) / (cosh^2 x)
= - (1 / (cosh x)) * (sinh x / (cosh x))
= - sech x tanh x

## Section 19: Derivatives of Hyperbolic Functions

### Derivative of sinh u

The derivative of sinh u with respect to x is cosh u multiplied by du/dx according to the chain rule.
Sources: 5c422a3cc4fa:p19

### Derivative of cosh u

The derivative of cosh u with respect to x is sinh u multiplied by du/dx.
Sources: 5c422a3cc4fa:p19

### Derivative of tanh u

The derivative of tanh u with respect to x is sech^2 u multiplied by du/dx.
Sources: 5c422a3cc4fa:p19

### Derivative of sech u

The derivative of sech u with respect to x is -sech u tanh u multiplied by du/dx.
Sources: 5c422a3cc4fa:p19

### Application of Hyperbolic Derivatives in Calculus

Derivatives of hyperbolic functions are combined with standard rules like product, quotient, and chain rules to differentiate complex expressions containing hyperbolic terms.
Sources: 5c422a3cc4fa:p20

#### 5c422a3cc4fa:p19 (content)

This slide presents the formulas for the derivatives of the six basic hyperbolic functions incorporating the chain rule.

d/dx(sinh u) = cosh u (du/dx), d/dx(cosh u) = sinh u (du/dx), d/dx(tanh u) = sech^2 u (du/dx), d/dx(coth u) = -csch^2 u (du/dx), d/dx(sech u) = -sech u tanh u (du/dx), d/dx(csch u) = -csch u coth u (du/dx)

#### 5c422a3cc4fa:p20 (content)

This slide demonstrates an example problem applying the derivative rules of hyperbolic functions along with the product, quotient, and chain rules.

Example Find y' if y = sqrt(x) tanh x + 1 / (1 + sech 3x). y' = (1 / (2 sqrt(x))) tanh x + sqrt(x) sech^2 x + (0 - (-sech 3x tanh 3x)(3)) / (1 + sech 3x)^2 = (tanh x / (2 sqrt(x))) + sqrt(x) sech^2 x + (3sech 3x tanh 3x) / (1 + sech 3x)^2

## Section 21: Derivatives of Hyperbolic Functions

### Derivative of Logarithmic Hyperbolic Functions

To differentiate terms like ln(cosh x), apply the chain rule where the derivative of ln(u) is 1/u times u' and the derivative of cosh x is sinh x, yielding sinh x / cosh x [5c422a3cc4fa:p21].
Sources: 5c422a3cc4fa:p21

### Chain Rule with Exponential and Hyperbolic Functions

Differentiating expressions like e^(sinh(x^3)) requires applying the exponential derivative rule combined with multiple nested chain rule applications for sinh and x^3 [5c422a3cc4fa:p21].
Sources: 5c422a3cc4fa:p21

### Logarithmic Differentiation

Logarithmic differentiation simplifies the derivative of complex multiplicative or quotient functions by taking the natural logarithm of both sides before differentiating implicitly with respect to x [5c422a3cc4fa:p22].
Sources: 5c422a3cc4fa:p22

### Derivative of Cosecant Hyperbolic Functions

When differentiating terms involving ln(csch x), the logarithmic derivative and the derivative of csch x (which is -csch x coth x) are combined [5c422a3cc4fa:p22].
Sources: 5c422a3cc4fa:p22

#### 5c422a3cc4fa:p21 (content)

This slide demonstrates finding the derivative of a function involving natural logarithm and hyperbolic functions using the chain rule.

Example () Find y' if y = ln(cosh x) - e^(sinh(x^3)) 
 y' = (sinh x)/(cosh x) - e^(sinh(x^3)) cosh(x^3) (3x^2)

#### 5c422a3cc4fa:p22 (content)

This slide covers logarithmic differentiation applied to a complex quotient of algebraic, trigonometric, and hyperbolic functions, leaving an exercise problem.

Example () Find y' if y = ((4 - x^2) * sin^3 x)/(6^(cosh x) * sqrt(csch x)) 
 ln y = ln(4 - x^2) + 3 ln(sin x) - cosh x ln 6 - (1/2) ln(csch x) 
 y'/y = (-2x)/(4 - x^2) + 3(cos x)/(sin x) - (ln 6) sinh x - (1/2) * (-csch x coth x)/(csch x) 
 y' = y [(-2x)/(4 - x^2) + 3 cot x - (ln 6) sinh x + (1/2) coth x] 
 Find y' if y = x^x tanh x (try to solve)

## Section 23: Graphs of Hyperbolic Functions

### Hyperbolic Cosine Definition

The hyperbolic cosine function is defined as cosh(x) = (e^x + e^(-x)) / 2, or equivalently as (e^x)/2 + (e^(-x))/2.
Sources: 5c422a3cc4fa:p23

### Hyperbolic Cosine Properties

The hyperbolic cosine function has a domain of R, a range of [1, infinity), and is an even function.
Sources: 5c422a3cc4fa:p23

### Hyperbolic Sine Definition

The hyperbolic sine function is defined as sinh(x) = (e^x - e^(-x)) / 2, or equivalently as (e^x)/2 - (e^(-x))/2.
Sources: 5c422a3cc4fa:p24

### Hyperbolic Sine Properties

The hyperbolic sine function has a domain of R, a range of R, and is an odd function.
Sources: 5c422a3cc4fa:p24

#### 5c422a3cc4fa:p23 (content)

Covers the definition, exponential components, domain, range, symmetry, and graph of the hyperbolic cosine function (cosh x).

Upper right plot shows curves labeled (e^x)/2 and (e^(-x))/2 with axis labels y, x and tick values 1, 0.5. Lower right plot shows cosh x curve.

#### 5c422a3cc4fa:p24 (content)

Covers the definition, exponential components, domain, range, symmetry, and graph of the hyperbolic sine function (sinh x).

Upper right plot shows curves labeled (e^x)/2 and (e^(-x))/2. Lower right plot shows sinh x curve with axis labels y, x.

## Section 25: Graphs of Hyperbolic Functions

### Hyperbolic Tangent Definition

The hyperbolic tangent function is defined as tanh(x) = sinh(x) / cosh(x), which evaluates to (e^x - e^(-x)) / (e^x + e^(-x)).
Sources: 5c422a3cc4fa:p25, 5c422a3cc4fa:p26

### Limits of Tanh at Infinity

As x approaches positive infinity, the limit of tanh(x) is 1. As x approaches negative infinity, the limit of tanh(x) is -1.
Sources: 5c422a3cc4fa:p25

### Domain and Range of Tanh

The domain of the hyperbolic tangent function is all real numbers (R), while its range is the open interval (-1, 1).
Sources: 5c422a3cc4fa:p26

### Symmetry of Tanh

The hyperbolic tangent function is classified as an odd function, meaning it satisfies the symmetry property with respect to the origin.
Sources: 5c422a3cc4fa:p26

#### 5c422a3cc4fa:p25 (content)

This slide introduces the hyperbolic tangent function definition, signs for positive and negative x, inequality relationship between sinh x and cosh x, and limits as x approaches positive and negative infinity with corresponding graphs.

tanh(x) = sinh(x) / cosh(x) = (e^x - e^(-x)) / (e^x + e^(-x)); If x > 0, tanh(x) is positive; If x < 0, tanh(x) is negative; If x=0 tanh(x)=0; |sinh x| < cosh x => |tanh x| < 1; lim(x->inf) (e^x - e^(-x)) / (e^x + e^(-x)) = 1; lim(x->-inf) (e^x - e^(-x)) / (e^x + e^(-x)) = -1

#### 5c422a3cc4fa:p26 (content)

This slide summarizes properties of the hyperbolic tangent function including its definition, domain, range, symmetry as an odd function, and visual graph with horizontal asymptotes at y = 1 and y = -1.

tanh(x) = sinh(x) / cosh(x) = (e^x - e^(-x)) / (e^x + e^(-x)); Domain = R; Range = (-1,1); Odd function

## Section 27: Graphs of Hyperbolic Functions

### Hyperbolic Secant Definition

The hyperbolic secant function is defined as sech(x) = 1 / cosh(x), which expands to 2 / (e^x + e^(-x)). Its domain is R and its range is (0, 1].
Sources: 5c422a3cc4fa:p27

### Even Function Property of Sech

The hyperbolic secant sech(x) is an even function, meaning sech(-x) = sech(x), which is reflected in its symmetric graph about the y-axis.
Sources: 5c422a3cc4fa:p27

### Hyperbolic Cosecant Definition

The hyperbolic cosecant function is defined as csch(x) = 1 / sinh(x), expanding to 2 / (e^x - e^(-x)). Its domain and range are both R except for zero.
Sources: 5c422a3cc4fa:p28

### Odd Function Property of Csch

The hyperbolic cosecant csch(x) is an odd function, meaning csch(-x) = -csch(x), resulting in point symmetry about the origin in its graph.
Sources: 5c422a3cc4fa:p28

#### 5c422a3cc4fa:p27 (content)

This page covers the definition, reciprocal nature, domain, range, symmetry, and graph of the hyperbolic secant function sech(x).

sech(x) = 1 / cosh(x) = 2 / (e^x + e^(-x))

#### 5c422a3cc4fa:p28 (content)

This page covers the definition, reciprocal nature, domain, range, symmetry, and graph of the hyperbolic cosecant function csch(x).

csch(x) = 1 / sinh(x) = 2 / (e^x - e^(-x))

## Section 29: Graphs and Applications of Hyperbolic Functions

### Hyperbolic Sine (sinh x)

The hyperbolic sine function has domain R and range R. Its graph passes through the origin and grows unboundedly, bounded below asymptotically by the exponential curve e^(-x).
Sources: 5c422a3cc4fa:p29

### Hyperbolic Cosine (cosh x)

The hyperbolic cosine function has domain R and range [1, infinity). It is an even function symmetric about the y-axis, representing shapes like hanging chains.
Sources: 5c422a3cc4fa:p29, 5c422a3cc4fa:p30

### Hyperbolic Tangent (tanh x)

The hyperbolic tangent function has domain R and range (-1, 1). Its graph is bounded strictly between horizontal asymptotes at y = 1 and y = -1.
Sources: 5c422a3cc4fa:p29

### Hyperbolic Cosecant (csch x)

The hyperbolic cosecant function has domain R minus {0} and range R minus {0}. It features vertical asymptotes at x = 0 and horizontal asymptotes as x approaches infinity.
Sources: 5c422a3cc4fa:p29

### Hyperbolic Secant (sech x)

The hyperbolic secant function has domain R and range (0, 1]. It is symmetric about the y-axis with a maximum value of 1 at x = 0.
Sources: 5c422a3cc4fa:p29

#### 5c422a3cc4fa:p29 (content)

The slide displays the graphs, domains, and ranges for the six basic hyperbolic functions: sinh x, cosh x, tanh x, csch x, sech x, and coth x.

sinh x, D: R, R: R. cosh x, D: R, R: [1, infinity). tanh x, D: R, R: (-1, 1). csch x, D: R - {0}, R: R - {0}. sech x, D: R, R: (0, 1]. coth x, D: R - {0}, R: R - [-1, 1].

#### 5c422a3cc4fa:p30 (content)

This slide introduces section 11.2, Applications of Hyperbolic Functions, showing photographs of physical phenomena like power lines and hanging chains that form catenary curves.

11.2 Applications of Hyperbolic Functions

## Section 31: Identities of Hyperbolic Functions

### Hyperbolic Sine Addition Identity Proof

The identity sinh(x + y) = sinh x cosh y + cosh x sinh y is proved by substituting the exponential definitions of hyperbolic sine and cosine into the right-hand side, expanding the products, combining fractions, and simplifying to yield sinh(x + y).
Sources: 5c422a3cc4fa:p32

#### 5c422a3cc4fa:p31 (administrative)

Concluding slide with a graphic of a child packing a school bag, a speech bubble saying FINISH, and the text See you next week.

FINISH See you next week

#### 5c422a3cc4fa:p32 (content)

Slide demonstrating the hyperbolic identity proof for sinh(x + y) using exponential definitions of sinh and cosh.

Identities of Hyperbolic Functions 32 Prove that sinh(x + y) = sinh x cosh y + cosh x sinh y R.H.S = ((e^x - e^(-x))/2)((e^y + e^(-y))/2) + ((e^x + e^(-x))/2)((e^y - e^(-y))/2) = (e^(x+y) + e^(x-y) - e^(-x+y) - e^(-x-y))/4 + (e^(x+y) - e^(x-y) + e^(-x+y) - e^(-x-y))/4 = (2e^(x+y) - 2e^(-x-y))/4 = (e^(x+y) - e^(-(x+y)))/2 = sinh(x + y)

## Section 33: Derivatives of Hyperbolic Functions

### Implicit Differentiation with Hyperbolic Functions

To find y' for an implicitly defined relation like y coth(3x) = 4x + y^6, differentiate both sides with respect to x using the product rule and chain rule, then isolate y'.
Sources: 5c422a3cc4fa:p33

### Derivative of Hyperbolic Cotangent

The derivative of coth(3x) with respect to x involves the hyperbolic cosecant squared function, specifically -3 csch^2(3x) when applying the chain rule.
Sources: 5c422a3cc4fa:p33

#### 5c422a3cc4fa:p33 (content)

This slide provides an example demonstrating implicit differentiation involving hyperbolic functions, specifically solving for y' given the equation y coth(3x) = 4x + y^6.

Example () Find y' if y coth 3x = 4x + y^6
y' coth 3x + y(-3 csch^2 3x) = 4 + 6y^5 y'
(coth 3x - 6y^5)y' = 4 + 3y csch^2 3x
y' = (4 + 3y csch^2 3x) / (coth 3x - 6y^5)
