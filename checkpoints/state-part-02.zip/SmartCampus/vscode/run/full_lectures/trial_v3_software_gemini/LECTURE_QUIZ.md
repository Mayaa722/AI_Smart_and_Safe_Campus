# Full-lecture quiz — unreviewed draft

Difficulty labels are uncalibrated. The keyed answer/explanation is shown for instructor review.

## 1. Why must requirements be defined abstractly when letting a contract for a large software project?

A. To ensure that solutions are pre-defined by the client before contractors bid
B. To prevent multiple contractors from submitting competing development approaches
C. To avoid pre-defining solutions and allow multiple contractors to bid with different approaches
D. To guarantee that the final system definition can never be modified by the contractor

Key: C. Needs must be defined abstractly when letting a contract for a large software project so solutions are not pre-defined, allowing multiple contractors to bid with different approaches [p. 5](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0005.png>).

Sources: [p. 5](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0005.png>)

## 2. How is a high-level usability goal transformed into a testable non-functional requirement?

A. By leaving the intention open to interpretation so developers can choose any metric
B. By formulating it using an objective, quantifiable measure that can be explicitly tested
C. By restricting all user interaction to a fixed set of standardized text commands
D. By replacing quantitative thresholds with general statements about user satisfaction

Key: B. A verifiable non-functional requirement is a statement using some measure that can be objectively tested, whereas a goal is a general intention such as ease of use [p. 18](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0018.png>). For example, a general goal stating that user errors should be minimized can be made testable by specifying that the average number of errors shall not exceed two per hour after four hours of training [p. 19](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0019.png>).

Sources: [p. 18](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0018.png>) [p. 19](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0019.png>)

## 3. What characterizes domain requirements in a software engineering project?

A. They originate from the operational domain of the system and reflect domain-specific rules or calculations
B. They are exclusively focused on mandating particular IDEs and programming languages
C. They always describe high-level user intentions that are impossible to verify
D. They are solely derived from general customer billing policies and marketing strategies

Key: A. Domain requirements are constraints placed on the software system originating from the specific application domain of operation, reflecting domain-specific rules and characteristics [p. 8](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0008.png>).

Sources: [p. 8](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0008.png>) [p. 21](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0021.png>)

## 4. Additional teaching: If an engineering team specifies that a real-time embedded monitoring system must process transactions within a strict response time limit of 50 milliseconds, which classification of requirement does this primarily represent?

A. An organizational requirement governing employee identification cards
B. A product requirement specifying execution speed and performance behavior
C. A domain requirement defining railway deceleration computations
D. A functional user requirement stating high-level clinic appointment lists

Key: B. Product requirements specify or constrain the behavior of the software product, including sub-categories like efficiency, performance, and speed metrics such as event response time [p. 14](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0014.png>) [p. 20](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0020.png>).

Sources: [p. 14](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0014.png>) [p. 20](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0020.png>)

## 5. What is a primary reason why domain requirements often pose significant problems during software development?

A. They are expressed in specialized application domain language not easily understood by developers.
B. They exclusively focus on internal hardware architectures rather than user needs.
C. They must always be written using formal mathematical set theory.
D. They are strictly prohibited in agile software development processes.

Key: A. Domain requirements are typically stated in the specialized language of the application domain, which software engineers frequently fail to understand [p. 23](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0023.png>).

Sources: [p. 23](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0023.png>)

## 6. Which section of a requirements document details fundamental assumptions and anticipated changes from hardware evolution to help designers avoid constraining future modifications?

A. The Glossary
B. The System Evolution section
C. The Preface
D. The User Requirements Definition

Key: B. The system evolution section details fundamental assumptions and anticipated changes to help designers avoid constraining future modifications [p. 29](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0029.png>).

Sources: [p. 29](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0029.png>)

## 7. When writing requirements in natural language, which modal verb convention should be consistently used to designate mandatory requirements?

A. Should
B. Might
C. Shall
D. Could

Key: C. Consistent language should be used when writing requirements, specifically using 'shall' for mandatory requirements and 'should' for desirable requirements [p. 31](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0031.png>).

Sources: [p. 31](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0031.png>)

## 8. Additional teaching: If an engineering team defines a scenario starting condition that requires a receptionist to create a patient record and a nurse to be logged into the system before proceeding with data collection, what aspect of scenario-based elicitation does this represent?

A. Exception handling and error recovery
B. Initial assumption or precondition
C. Concurrent background activity
D. System completion state and database logging

Key: B. Defining starting situations and required preconditions before a scenario can begin corresponds to initial assumptions in scenarios [p. 43](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0043.png>).

Sources: [p. 43](<run/uploads/866857921ed1ef5cb8dcaf625dc93c59/acc50e4530dbcebe258c0e130bfacba5c82e2a4451480c944300c361db201c71/quality_v1/page_0043.png>)
