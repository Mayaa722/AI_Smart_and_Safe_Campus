# Full-lecture study materials

software for testing.pdf

Processing coverage: 46/46 pages. This is not an accuracy score.

Page notes and transcriptions are model-generated drafts; original page images remain authoritative.

## Section 1: Chapter 4 Requirements Engineering Lecture 3

### Functional and Non-Functional Requirements

Topics covered include distinguishing between functional requirements and non-functional requirements in software engineering systems [acc50e4530db:p2].
Sources: acc50e4530db:p2

### Requirements Engineering Processes

The structured processes involved in requirements engineering, including elicitation, analysis, specification, validation, and management [acc50e4530db:p2].
Sources: acc50e4530db:p2

### Software Requirements Document

The official document containing the software requirements specifications and documentation details [acc50e4530db:p2].
Sources: acc50e4530db:p2

### Requirements Validation and Management

Processes dedicated to validating requirements against stakeholder needs and managing changes throughout the software lifecycle [acc50e4530db:p2].
Sources: acc50e4530db:p2

#### acc50e4530db:p1 (administrative)

Title slide for Chapter 4 on Requirements Engineering, Lecture 3.

Chapter 4 - Requirements Engineering Lecture 3 Chapter 4 Requirements engineering 1

#### acc50e4530db:p2 (content)

Overview of topics covered in the lecture, including functional and non-functional requirements, documentation, specification, processes, elicitation and analysis, validation, and management.

Topics covered Functional and non-functional requirements The software requirements document Requirements specification Requirements engineering processes Requirements elicitation and analysis Requirements validation Requirements management Chapter 4 Requirements engineering 2

## Section 3: Requirements Engineering Overview

### Requirements Engineering Process

The process of establishing the services that the customer requires from a system and the constraints under which it operates and is developed.
Sources: acc50e4530db:p3

### Definition of Requirements

Requirements are the descriptions of the system services and constraints that are generated during the requirements engineering process.
Sources: acc50e4530db:p3

### Scope of Requirements

Requirements may range from a high-level abstract statement of a service or of a system constraint to a detailed mathematical functional specification.
Sources: acc50e4530db:p4

### Dual Function of Requirements for Bids

Requirements may serve as the basis for a bid for a contract and therefore must be open to interpretation.
Sources: acc50e4530db:p4

### Dual Function of Requirements for Contracts

Requirements may serve as the basis for the contract itself and therefore must be defined in detail.
Sources: acc50e4530db:p4

#### acc50e4530db:p3 (content)

This slide defines requirements engineering as the process of establishing required system services and operational constraints, and defines requirements as the generated descriptions of those services and constraints.

Chapter 4 Requirements engineering 3

#### acc50e4530db:p4 (content)

This slide explains that requirements range from high-level abstract statements to detailed mathematical specifications, fulfilling a dual function as a basis for contract bids or the contract itself.

Chapter 4 Requirements engineering 4

## Section 5: Requirements Abstraction

### Requirements Abstraction

Needs must be defined abstractly when letting a contract for a large software project so solutions are not pre-defined, allowing multiple contractors to bid with different approaches [acc50e4530db:p5].
Sources: acc50e4530db:p5

### System Definition

After a contract is awarded, the contractor writes a detailed system definition for the client to understand and validate what the software will do [acc50e4530db:p5].
Sources: acc50e4530db:p5

#### acc50e4530db:p5 (content)

This page discusses requirements abstraction according to Davis, explaining how needs must be defined abstractly for contractor bidding before a detailed system definition is written for validation.

Requirements abstraction (Davis)

"If a company wishes to let a contract for a large software development project, it must define its needs in a sufficiently abstract way that a solution is not pre-defined. The requirements must be written so that several contractors can bid for the contract, offering, perhaps, different ways of meeting the client organization's needs. Once a contract has been awarded, the contractor must write a system definition for the client in more detail so that the client understands and can validate what the software will do. Both of these documents may be called the requirements document for the system."

Chapter 4 Requirements engineering
5

## Section 6: Types of Requirement

### User Requirements

Statements written in natural language along with diagrams that describe the services a system provides and its operational constraints, primarily intended for customers [acc50e4530db:p6].
Sources: acc50e4530db:p6

### System Requirements

A structured document providing detailed descriptions of a system's functions, services, and operational constraints, defining what should be implemented and potentially forming part of a contract between a client and a contractor [acc50e4530db:p6].
Sources: acc50e4530db:p6

#### acc50e4530db:p6 (content)

This slide distinguishes between user requirements, written in natural language with diagrams for customers, and system requirements, detailed structured documents defining what should be implemented that may form part of a client-contractor contract.

Types of requirement
User requirements
- Statements in natural language plus diagrams of the services the system provides and its operational constraints. Written for customers.
System requirements
- A structured document setting out detailed descriptions of the system's functions, services and operational constraints. Defines what should be implemented so may be part of a contract between client and contractor.
Chapter 4 Requirements engineering
6

## Section 7: Requirements Engineering: User, System, and Functional Requirements

### User Requirement Definition

High-level statements written for customers and users, defining what services the system is expected to provide and its operational constraints using natural language and diagrams.
Sources: acc50e4530db:p7

### System Requirements Specification

Detailed descriptions of the system's functions, services, and operational constraints, often serving as the contract between the system buyer and software developer.
Sources: acc50e4530db:p7

### Functional Requirements

Statements detailing the services a system should provide, how it should react to specific inputs, how it should behave in particular situations, or what it should not do.
Sources: acc50e4530db:p8

### Non-Functional Requirements

Constraints on the services or functions offered by the system, covering timing constraints, development process constraints, and standards that usually apply to the system as a whole.
Sources: acc50e4530db:p8

### Domain Requirements

Constraints placed on the software system originating from the specific application domain of operation, reflecting domain-specific rules and characteristics.
Sources: acc50e4530db:p8

#### acc50e4530db:p7 (content)

Illustrates user and system requirements definitions using an MHC-PMS example, contrasting high-level user needs with detailed system specifications.

User requirement definition:
1. The MHC-PMS shall generate monthly management reports showing the cost of drugs prescribed by each clinic during that month.

System requirements specification:
1.1 On the last working day of each month, a summary of the drugs prescribed, their cost and the prescribing clinics shall be generated.
1.2 The system shall automatically generate the report for printing after 17.30 on the last working day of the month.
1.3 A report shall be created for each clinic and shall list the individual drug names, the total number of prescriptions, the number of doses prescribed and the total cost of the prescribed drugs.
1.4 If drugs are available in different dose units (e.g. 10mg, 20 mg, etc.) separate reports shall be created for each dose unit.
1.5 Access to all cost reports shall be restricted to authorized users listed on a management access control list.

#### acc50e4530db:p8 (content)

Defines functional, non-functional, and domain requirements, detailing how they describe system services, constraints, and operational environment boundaries.

Functional requirements
- Statements of services the system should provide, how the system should react to particular inputs and how the system should behave in particular situations.
- May state what the system should not do.
Non-functional requirements
- Constraints on the services or functions offered by the system such as timing constraints, constraints on the development process, standards, etc.
- Often apply to the system as a whole rather than individual features or services.
Domain requirements
- Constraints on the system from the domain of operation

## Section 9: Requirements Engineering: Functional Requirements

### Functional Requirements

Functional requirements describe the functionality or system services that a software system should provide. They depend on the software type, expected users, and the specific system environment [acc50e4530db:p9].
Sources: acc50e4530db:p9

### Functional User Requirements

Functional user requirements are high-level statements detailing what the system should accomplish for its users [acc50e4530db:p9].
Sources: acc50e4530db:p9

### Functional System Requirements

Functional system requirements describe the specific services, features, and operational details of the system in depth [acc50e4530db:p9].
Sources: acc50e4530db:p9

### MHC-PMS Functional Examples

Examples for the Mental Health Care Patient Management System include allowing users to search clinic appointment lists, generating daily patient attendance lists per clinic, and uniquely identifying staff members using 8-digit employee numbers [acc50e4530db:p10].
Sources: acc50e4530db:p10

#### acc50e4530db:p9 (content)

Defines functional requirements, explaining that they describe functionality or system services, depend on software type, expected users, and system context, separating high-level user requirements from detailed system requirements.

Functional requirements
- Describe functionality or system services.
- Depend on the type of software, expected users and the type of system where the software is used.
- Functional user requirements may be high-level statements of what the system should do.
- Functional system requirements should describe the system services in detail.
Chapter 4 Requirements engineering
10

#### acc50e4530db:p10 (content)

Presents concrete functional requirements for the Mental Health Care Patient Management System (MHC-PMS), covering appointment searches, daily patient lists generation, and unique staff identification via 8-digit employee numbers.

Functional requirements for the MHC-PMS
- A user shall be able to search the appointments lists for all clinics.
- The system shall generate each day, for each clinic, a list of patients who are expected to attend appointments that day.
- Each staff member using the system shall be uniquely identified by his or her 8-digit employee number.
Chapter 4 Requirements engineering
11

## Section 11: Requirements Engineering: Imprecision, Completeness, and Consistency

### Requirements Imprecision

Problems arise when requirements are not precisely stated, leading to ambiguous interpretations where developers and users understand terms differently, such as differing scopes for a search function [acc50e4530db:p11].
Sources: acc50e4530db:p11

### Requirements Completeness

In principle, a complete set of requirements should include descriptions of all facilities required by the system, though achieving this is practically impossible [acc50e4530db:p12].
Sources: acc50e4530db:p12

### Requirements Consistency

Consistent requirements contain no conflicts or contradictions in the descriptions of the system facilities, though producing such a document in practice is impossible [acc50e4530db:p12].
Sources: acc50e4530db:p12

#### acc50e4530db:p11 (content)

Discusses problems caused by requirement imprecision, illustrating how ambiguous terms like 'search' lead to differing interpretations between users and developers.

Requirements imprecision
Problems arise when requirements are not precisely stated.
Ambiguous requirements may be interpreted in different ways by developers and users.
Consider the term 'search' in requirement 1
- User intention - search for a patient name across all appointments in all clinics;
- Developer interpretation - search for a patient name in an individual clinic. User chooses clinic then search.

#### acc50e4530db:p12 (content)

Outlines the principles of requirement completeness and consistency, noting that complete requirements include all facility descriptions while consistent ones have no conflicts, though both are practically impossible to achieve.

Requirements completeness and consistency
In principle, requirements should be both complete and consistent.
Complete
- They should include descriptions of all facilities required.
Consistent
- There should be no conflicts or contradictions in the descriptions of the system facilities.
In practice, it is impossible to produce a complete and consistent requirements document.

## Section 13: Non-functional Requirements

### Non-functional Requirements

Non-functional requirements define system properties and constraints such as reliability, response time, and storage requirements, as well as I/O device capability and system representations [acc50e4530db:p13].
Sources: acc50e4530db:p13

### Process Requirements

Process requirements are a category of requirements that may specify or mandate a particular IDE, programming language, or development method for the project [acc50e4530db:p13].
Sources: acc50e4530db:p13

### Criticality of Non-functional Requirements

Non-functional requirements can sometimes be more critical than functional requirements; if these requirements are not met, the entire system may be rendered useless [acc50e4530db:p13].
Sources: acc50e4530db:p13

#### acc50e4530db:p13 (content)

Defines non-functional requirements as system properties and constraints (like reliability and storage), process constraints (like specific IDEs), and notes they can be more critical than functional requirements.

Non-functional requirements
Chapter 4 Requirements engineering
14

## Section 14: Types of Non-functional Requirement

### Non-functional Requirements Classification

Non-functional requirements are categorized hierarchically into product requirements, organizational requirements, and external requirements [acc50e4530db:p14].
Sources: acc50e4530db:p14

### Product Requirements

Product requirements specify or constrain the behavior of the software product, including sub-categories like efficiency, dependability, security, usability, performance, and space requirements [acc50e4530db:p14].
Sources: acc50e4530db:p14

### Organizational Requirements

Organizational requirements are broad system requirements derived from policies and procedures in the customer's and developer's organization, including environmental, operational, and development requirements [acc50e4530db:p14].
Sources: acc50e4530db:p14

### External Requirements

External requirements cover all requirements that arise from factors external to the system and its development process, encompassing regulatory, ethical, and legislative requirements such as accounting and safety/security standards [acc50e4530db:p14].
Sources: acc50e4530db:p14

#### acc50e4530db:p14 (content)

This slide illustrates a hierarchical classification tree of non-functional requirements in requirements engineering, categorizing them into product requirements, organizational requirements, and external requirements.

Non-functional requirements split into Product requirements (Efficiency requirements [Usability requirements, Performance requirements, Space requirements], Dependability requirements, Security requirements), Organizational requirements (Environmental requirements, Operational requirements, Development requirements), and External requirements (Regulatory requirements, Ethical requirements, Legislative requirements [Accounting requirements, Safety/security requirements]).

## Section 15: Non-functional Requirements Implementation and Classifications

### Non-functional Requirements System Architecture Impact

Non-functional requirements can affect the overall architecture of a system rather than just individual components, such as organizing a system to minimize component communications to satisfy performance requirements [acc50e4530db:p15].
Sources: acc50e4530db:p15

### Generation of Functional Requirements

A single non-functional requirement, such as security, may generate multiple related functional requirements that define necessary system services or restrict existing requirements [acc50e4530db:p15].
Sources: acc50e4530db:p15

### Product Requirements

Product requirements specify that the delivered product must behave in a particular way, with examples including execution speed and reliability [acc50e4530db:p16].
Sources: acc50e4530db:p16

### Organisational Requirements

Organisational requirements are consequences of organisational policies and procedures, including process standards used and implementation requirements [acc50e4530db:p16].
Sources: acc50e4530db:p16

### External Requirements

External requirements arise from factors external to the system and its development process, such as interoperability and legislative requirements [acc50e4530db:p16].
Sources: acc50e4530db:p16

#### acc50e4530db:p15 (content)

This slide explains how non-functional requirements affect overall system architecture rather than individual components, and discusses how a single non-functional requirement can generate related functional services or restrict existing ones.

Chapter 4 Requirements engineering 16

#### acc50e4530db:p16 (content)

This slide categorizes non-functional requirements into three types: product requirements, organisational requirements, and external requirements, providing examples for each classification.

Chapter 4 Requirements engineering 17

## Section 17: Non-functional Requirements and Goals

### Product Requirement

A product-level non-functional constraint specifying behavioral limits, such as system availability during working hours and strict daily downtime thresholds [acc50e4530db:p17].
Sources: acc50e4530db:p17

### Organizational Requirement

A requirement derived from organizational policies and procedures, such as mandating specific identity cards for user authentication [acc50e4530db:p17].
Sources: acc50e4530db:p17

### External Requirement

A requirement arising from external factors and standards, such as compliance with specific governmental patient privacy provisions [acc50e4530db:p17].
Sources: acc50e4530db:p17

### Goal

A general user intention, such as ease of use, which can be difficult to verify precisely but helps convey user intentions to developers [acc50e4530db:p18].
Sources: acc50e4530db:p18

### Verifiable Non-Functional Requirement

A non-functional requirement formulated using an objective measure so that it can be tested explicitly, addressing the challenge of imprecise specifications [acc50e4530db:p18].
Sources: acc50e4530db:p18

#### acc50e4530db:p17 (content)

This page provides concrete examples of nonfunctional requirements in the MHC-PMS, categorized into product requirements, organizational requirements, and external requirements.

Examples of nonfunctional requirements in the MHC-PMS
Product requirement
The MHC-PMS shall be available to all clinics during normal working hours (Mon-Fri, 0830-17.30). Downtime within normal working hours shall not exceed five seconds in any one day.
Organizational requirement
Users of the MHC-PMS system shall authenticate themselves using their health authority identity card.
External requirement
The system shall implement patient privacy provisions as set out in HStan-03-2006-priv.

#### acc50e4530db:p18 (content)

This page discusses goals and verifiable non-functional requirements, noting that non-functional requirements can be hard to state precisely and goals express general user intentions like ease of use.

Goals and requirements
- Non-functional requirements may be very difficult to state precisely and imprecise requirements may be difficult to verify.
- Goal: A general intention of the user such as ease of use.
- Verifiable non-functional requirement: A statement using some measure that can be objectively tested.
- Goals are helpful to developers as they convey the intentions of the system users.

## Section 19: Usability Requirements

### Usability Goal

A general intention or high-level objective for a system, such as ensuring it is easy to use and minimizes user errors, which cannot be directly verified by a specific quantitative test [acc50e4530db:p19].
Sources: acc50e4530db:p19

### Testable Non-Functional Requirement

A specific, quantifiable requirement derived from a goal, allowing objective verification. For example, specifying that experienced users shall not make more than two errors per hour of system use after four hours of training [acc50e4530db:p19].
Sources: acc50e4530db:p19

#### acc50e4530db:p19 (content)

This slide distinguishes between a general usability goal and a testable non-functional requirement using a medical staff system example.

Usability requirements
The system should be easy to use by medical staff and should be organized in such a way that user errors are minimized. (Goal)
Medical staff shall be able to use all the system functions after four hours of training. After this training, the average number of errors made by experienced users shall not exceed two per hour of system use. (Testable non-functional requirement)
Chapter 4 Requirements engineering 20

## Section 20: Metrics for Specifying Nonfunctional Requirements

### Speed Metrics

Speed nonfunctional requirements can be measured using metrics such as processed transactions per second, user or event response time, and screen refresh time [acc50e4530db:p20].
Sources: acc50e4530db:p20

### Size Metrics

Size requirements are quantified using physical or memory measures such as Mbytes and the number of ROM chips [acc50e4530db:p20].
Sources: acc50e4530db:p20

### Reliability and Robustness Metrics

Reliability is measured via mean time to failure, probability of unavailability, rate of failure occurrence, and availability. Robustness measures include restart time, failure event percentages, and data corruption probability [acc50e4530db:p20].
Sources: acc50e4530db:p20

### Ease of Use Metrics

Ease of use is specified using usability metrics like training time and the number of help frames [acc50e4530db:p20].
Sources: acc50e4530db:p20

### Portability Metrics

Portability requirements are evaluated by calculating the percentage of target-dependent statements and counting the number of target systems [acc50e4530db:p20].
Sources: acc50e4530db:p20

#### acc50e4530db:p20 (content)

This slide presents a table mapping nonfunctional property types (Speed, Size, Ease of use, Reliability, Robustness, Portability) to quantitative metrics and measures used to specify them in requirements engineering.

Property: Speed | Measure: Processed transactions/second, User/event response time, Screen refresh time
Property: Size | Measure: Mbytes, Number of ROM chips
Property: Ease of use | Measure: Training time, Number of help frames
Property: Reliability | Measure: Mean time to failure, Probability of unavailability, Rate of failure occurrence, Availability
Property: Robustness | Measure: Time to restart after failure, Percentage of events causing failure, Probability of data corruption on failure
Property: Portability | Measure: Percentage of target dependent statements, Number of target systems

## Section 21: Domain Requirements in Requirements Engineering

### Domain Requirements

Requirements that come from the system's operational domain rather than specific customer needs. They can represent new functional requirements, constraints, or specific computations. If unsatisfied, the system may be unworkable [acc50e4530db:p21].
Sources: acc50e4530db:p21

### Train Control System Domain Example

An operational domain example where a train control system must account for braking characteristics under different weather conditions [acc50e4530db:p21].
Sources: acc50e4530db:p21

### Train Deceleration Computation Formula

In a train protection system domain requirement, train deceleration is computed as Dtrain = Dcontrol + Dgradient, where Dgradient equals 9.81ms2 * compensated gradient/alpha, and values of 9.81ms2 /alpha vary by train type [acc50e4530db:p22].
Sources: acc50e4530db:p22

### Non-specialist Understanding Challenges

Domain requirements are often difficult for non-specialists to understand regarding their implications and how they interact with other requirements [acc50e4530db:p22].
Sources: acc50e4530db:p22

#### acc50e4530db:p21 (content)

Explanation of domain requirements imposed by an operational domain, noting they can be new functional requirements, constraints, or specific computations, and unworkability if unsatisfied.

Chapter 4 Requirements engineering 22

#### acc50e4530db:p22 (content)

Detailed train protection system domain requirement showing deceleration computation formulas and highlighting difficulties for non-specialists to understand requirements interaction.

Chapter 4 Requirements engineering 23

## Section 23: Domain Requirements Problems

### Understandability in Domain Requirements

Domain requirements are typically expressed in the specialized language of the application domain, which is frequently not understood by the software engineers developing the system [acc50e4530db:p23].
Sources: acc50e4530db:p23

### Implicitness in Domain Requirements

Domain specialists understand their area of expertise so thoroughly that they often fail to think about making the underlying domain requirements explicit for developers [acc50e4530db:p23].
Sources: acc50e4530db:p23

#### acc50e4530db:p23 (content)

Discusses problems associated with domain requirements, specifically focusing on understandability issues between domain language and software engineers, and the implicitness of domain knowledge among specialists.

Domain requirements problems
Understandability
- Requirements are expressed in the language of the application domain;
- This is often not understood by software engineers developing the system.
Implicitness
- Domain specialists understand the area so well that they do not think of making the domain requirements explicit.

#### acc50e4530db:p24 (administrative)

Indicates a break in the lecture for Chapter 4 Requirements Engineering.

Break

## Section 25: Software Requirements Document and Agile Methods

### Software Requirements Document

The official statement of what is required of system developers, incorporating user requirements and system specifications without acting as a design document.
Sources: acc50e4530db:p25

### User vs System Requirements

A requirements document includes both a definition of user requirements and a formal specification of the system requirements.
Sources: acc50e4530db:p25

### What vs How Distinction

The requirements document should focus on what the system should do rather than how it should do it, avoiding design specifics.
Sources: acc50e4530db:p25

### Agile Incremental Requirements

Agile methods use incremental requirements engineering and user stories instead of traditional documents because requirements change rapidly.
Sources: acc50e4530db:p26

### Agile Limitations for Critical Systems

While practical for business systems, agile approaches are problematic for systems needing extensive pre-delivery analysis, such as critical systems or multi-team projects.
Sources: acc50e4530db:p26

#### acc50e4530db:p25 (content)

Defines the software requirements document as the official statement of developer requirements, combining user requirements and system specifications while focusing on what the system should do rather than how.

The software requirements document
- The software requirements document is the official statement of what is required of the system developers.
- Should include both a definition of user requirements and a specification of the system requirements.
- It is NOT a design document. As far as possible, it should set of WHAT the system should do rather than HOW it should do it.
Chapter 4 Requirements engineering
26

#### acc50e4530db:p26 (content)

Explains agile perspectives on requirements documents, noting that agile methods use incremental engineering and user stories because documents quickly become outdated, though this is problematic for critical systems.

Agile methods and requirements
- Many agile methods argue that producing a requirements document is a waste of time as requirements change so quickly.
- The document is therefore always out of date.
- Agile Methods use incremental requirements engineering and express requirements as 'user stories' (discussed in Chapter 3).
- This is practical for business systems but problematic for systems that require a lot of pre-delivery analysis (e.g. critical systems) or systems developed by several teams.
Chapter 4 Requirements engineering
27

## Section 27: Requirements Document Variability

### Requirements Document Variability

The information contained within a requirements document depends heavily on the type of system being built and the chosen development approach [acc50e4530db:p27].
Sources: acc50e4530db:p27

### Incremental Development and Requirements Detail

Systems developed incrementally typically contain less detail in their requirements documents compared to traditional sequential approaches [acc50e4530db:p27].
Sources: acc50e4530db:p27

### Requirements Document Standards

Formal requirements document standards, such as the IEEE standard, have been designed primarily for applicability to large systems engineering projects [acc50e4530db:p27].
Sources: acc50e4530db:p27

#### acc50e4530db:p27 (content)

Discusses how requirements document information varies based on system type and development approach, noting that incremental systems typically have less detail, while standards like IEEE standards apply mostly to large systems engineering projects.

Chapter 4 Requirements engineering
29

## Section 28: The Structure of a Requirements Document

### Preface

Defines the expected readership of the requirements document and describes its version history, including version creation rationales and summary of changes [acc50e4530db:p28].
Sources: acc50e4530db:p28

### Introduction

Describes the system's need, functions, integration with other systems, and how it aligns with the organization's overall business or strategic objectives [acc50e4530db:p28].
Sources: acc50e4530db:p28

### Glossary

Defines technical terms used throughout the document without making assumptions about the reader's experience or expertise [acc50e4530db:p28].
Sources: acc50e4530db:p28

### User Requirements Definition

Describes services provided for the user and nonfunctional system requirements using customer-understandable notations, while specifying applicable product and process standards [acc50e4530db:p28].
Sources: acc50e4530db:p28

### System Architecture

Presents a high-level overview of the anticipated system architecture, showing function distribution across modules and highlighting reused components [acc50e4530db:p28].
Sources: acc50e4530db:p28

#### acc50e4530db:p28 (content)

This page outlines the structure of a requirements document, detailing the contents of chapters including the preface, introduction, glossary, user requirements definition, and system architecture.

Table listing Chapter and Description for Preface, Introduction, Glossary, User requirements definition, and System architecture.

## Section 29: Requirements Document Structure and Specification Notations

### System Requirements Specification Structure

A requirements document structure includes system requirements specifications, graphical system models, system evolution assumptions, application-specific appendices, and multiple document indexes [acc50e4530db:p29].
Sources: acc50e4530db:p29

### System Evolution Section

The system evolution section details fundamental assumptions and anticipated changes from hardware evolution or user needs to help designers avoid constraining future modifications [acc50e4530db:p29].
Sources: acc50e4530db:p29

### Natural Language Requirements

Requirements can be written using numbered sentences in natural language where each sentence expresses a single requirement [acc50e4530db:p30].
Sources: acc50e4530db:p30

### Structured Natural Language Specifications

Requirements are written in natural language on a standard form or template where each field provides information about a specific requirement aspect [acc50e4530db:p30].
Sources: acc50e4530db:p30

### Mathematical Specifications

These notations use mathematical concepts like finite-state machines or sets to reduce ambiguity, though customers often struggle to understand or accept them as contracts [acc50e4530db:p30].
Sources: acc50e4530db:p30

#### acc50e4530db:p29 (content)

This page outlines the typical structure of a requirements document, detailing sections such as system requirements specification, system models, system evolution, appendices, and document indexes.

Chapter: System requirements specification, System models, System evolution, Appendices, Index.

#### acc50e4530db:p30 (content)

This page explains various notations used for writing system requirements specifications, including natural language, structured natural language, design description languages, graphical notations, and mathematical specifications.

Notation: Natural language, Structured natural language, Design description languages, Graphical notations, Mathematical specifications.

## Section 31: Guidelines and Problems in Requirements Writing

### Mandatory vs Desirable Requirements Language

Consistent language should be used when writing requirements, specifically using 'shall' to designate mandatory requirements and 'should' for desirable requirements [acc50e4530db:p31].
Sources: acc50e4530db:p31

### Requirement Formatting Guidelines

Writers should invent and use a standard format for all requirements, employ text highlighting to identify key parts, and avoid the use of computer jargon [acc50e4530db:p31].
Sources: acc50e4530db:p31

### Lack of Clarity in Natural Language

Using natural language leads to a lack of clarity because achieving precision often makes the document difficult to read [acc50e4530db:p32].
Sources: acc50e4530db:p32

### Requirements Confusion

Natural language specifications often suffer from requirements confusion, where functional and non-functional requirements tend to be mixed up [acc50e4530db:p32].
Sources: acc50e4530db:p32

### Requirements Amalgamation

Requirements amalgamation occurs when several different requirements are expressed together as a single mixed statement in natural language documents [acc50e4530db:p32].
Sources: acc50e4530db:p32

#### acc50e4530db:p31 (content)

The slide outlines guidelines for writing software requirements, emphasizing standard formatting, consistent language use like shall and should, text highlighting, and avoiding computer jargon.

Guidelines for writing requirements

#### acc50e4530db:p32 (content)

This slide details problems associated with natural language requirements, highlighting issues with clarity, requirements confusion between functional and non-functional types, and requirements amalgamation.

Problems with natural language

## Section 33: Requirements Engineering: Insulin Pump Examples and Structured Specifications

### Insulin Pump Software Requirements

Specific timing requirements dictate that an insulin pump system must measure blood sugar and deliver insulin every 10 minutes, balancing slow physiological changes against the risk of high sugar levels [acc50e4530db:p33]. Additionally, a self-test routine must run every minute to discover hardware and software problems [acc50e4530db:p33].
Sources: acc50e4530db:p33

### Structured Specifications

Structured specifications limit the freedom of requirements writers by mandating standard formats for writing requirements [acc50e4530db:p34]. While effective for embedded control systems, this approach can be overly rigid when applied to business system requirements [acc50e4530db:p34].
Sources: acc50e4530db:p34

#### acc50e4530db:p33 (content)

Example requirements for an insulin pump software system detailing blood sugar measurement frequency and self-test routine execution.

Example requirements for the insulin pump software system
3.2 The system shall measure the blood sugar and deliver insulin, if required, every 10 minutes.
3.6 The system shall run a self-test routine every minute with the conditions to be tested and the associated actions defined in Table 1.

#### acc50e4530db:p34 (content)

Definition of structured specifications as an approach limiting writer freedom to standard formats, working well for embedded systems but potentially too rigid for business systems.

Structured specifications
- An approach to writing requirements where the freedom of the requirements writer is limited and requirements are written in a standard way.
- This works well for some types of requirements e.g. requirements for embedded control system but is sometimes too rigid for writing business system requirements.

## Section 35: Form-Based Specifications and Insulin Pump Example

### Form-Based Specifications

Form-based specifications define a function or entity through structured fields that describe inputs, sources, outputs, destinations, required computation information, actions, pre/post-conditions, and side effects [acc50e4530db:p35].
Sources: acc50e4530db:p35

### Insulin Pump Requirement Specification

An example of a structured specification demonstrates computing an insulin dose when sugar levels are between 3 and 7 units, taking current and previous sensor readings as inputs and returning the delivered dose to the main control loop [acc50e4530db:p36].
Sources: acc50e4530db:p36

#### acc50e4530db:p35 (content)

This slide outlines the components of form-based specifications, including function definitions, inputs, outputs, required information, actions, pre/post-conditions, and side effects.

Form-based specifications
Definition of the function or entity.
Description of inputs and where they come from.
Description of outputs and where they go to.
Information about the information needed for the computation and other entities used.
Description of the action to be taken.
Pre and post conditions (if appropriate).
The side effects (if any) of the function.

#### acc50e4530db:p36 (content)

This slide presents a structured requirement specification for an insulin pump, detailing the function, description, inputs, source, outputs, and destination.

A structured specification of a requirement for an insulin pump
Insulin Pump/Control Software/SRS/3.3.2
Function Compute insulin dose: safe sugar level.
Description Computes the dose of insulin to be delivered when the current measured sugar level is in the safe zone between 3 and 7 units.
Inputs Current sugar reading (r2); the previous two readings (r0 and r1).
Source Current sugar reading from sensor. Other readings from memory.
Outputs CompDose-the dose in insulin to be delivered.
Destination Main control loop.
Chapter 4 Requirements engineering 41

## Section 37: Insulin Pump Structured and Tabular Specifications

### Structured Requirement Specification

A structured specification defines software requirements systematically using specific headings such as Action, Requirements, Pre-condition, Post-condition, and Side effects, as illustrated by the insulin pump example [acc50e4530db:p37].
Sources: acc50e4530db:p37

### Tabular Specification

Tabular specifications supplement natural language and are especially useful when defining multiple alternative courses of action, such as calculating insulin requirements based on blood sugar rate of change scenarios [acc50e4530db:p38].
Sources: acc50e4530db:p38

#### acc50e4530db:p37 (content)

Shows a structured requirement specification for an insulin pump detailing actions, requirements, pre-conditions, post-conditions, and side effects.

Action
CompDose is zero if the sugar level is stable or falling or if the level is increasing but the rate of increase is decreasing. If the level is increasing and the rate of increase is increasing, then CompDose is computed by dividing the difference between the current sugar level and the previous level by 4 and rounding the result. If the result, is rounded to zero then CompDose is set to the minimum dose that can be delivered.
Requirements
Two previous readings so that the rate of change of sugar level can be computed.
Pre-condition
The insulin reservoir contains at least the maximum allowed single dose of insulin.
Post-condition r0 is replaced by r1 then r1 is replaced by r2.
Side effects None.
Chapter 4 Requirements engineering 42

#### acc50e4530db:p38 (content)

Describes tabular specifications, explaining that they supplement natural language and are useful for defining multiple alternative courses of action such as insulin pump computations based on blood sugar levels.

Tabular specification
Used to supplement natural language.
Particularly useful when you have to define a number of possible alternative courses of action.
For example, the insulin pump systems bases its computations on the rate of change of blood sugar level and the tabular specification explains how to calculate the insulin requirement for different scenarios.

## Section 39: Lecture Section: Insulin Pump Computation and Requirements Engineering Processes

### Insulin Pump Computation Specification

A tabular specification defines computed insulin dosage (CompDose) conditional on current and past sugar level readings r0, r1, and r2, applying a rounded rate calculation or a minimum dose when conditions dictate [acc50e4530db:p39].
Sources: acc50e4530db:p39

### Generic Requirements Engineering Activities

Requirements engineering processes consist of four generic activities common across application domains: requirements elicitation, requirements analysis, requirements validation, and requirements management [acc50e4530db:p40].
Sources: acc50e4530db:p40

### Iterative Nature of Requirements Engineering

In practical software engineering, requirements engineering is not strictly linear; it is an iterative activity in which elicitation, analysis, validation, and management processes are interleaved [acc50e4530db:p40].
Sources: acc50e4530db:p40

#### acc50e4530db:p39 (content)

This slide specifies tabular computation rules for an insulin pump based on sugar level trends and rates of change.

Tabular specification of computation for an insulin pump
Condition | Action
Sugar level falling (r2 < r1) | CompDose = 0
Sugar level stable (r2 = r1) | CompDose = 0
Sugar level increasing and rate of increase decreasing ((r2 - r1) < (r1 - r0)) | CompDose = 0
Sugar level increasing and rate of increase stable or increasing ((r2 - r1) >= (r1 - r0)) | CompDose = round ((r2 - r1)/4)
If rounded result = 0 then CompDose = MinimumDose

#### acc50e4530db:p40 (content)

This slide outlines the generic activities and iterative nature of requirements engineering processes across different domains.

Requirements engineering processes
- Requirements elicitation;
- Requirements analysis;
- Requirements validation;
- Requirements management.
In practice, RE is an iterative activity in which these processes are interleaved.

## Section 41: Requirements Elicitation, Analysis, and Scenarios

### Requirements Elicitation and Analysis

Also known as requirements discovery, this process involves technical staff working with customers and other stakeholders to determine the application domain, necessary system services, and operational constraints [acc50e4530db:p41].
Sources: acc50e4530db:p41

### Stakeholders

Individuals or groups who may be involved in or affected by requirements elicitation, including end-users, managers, maintenance engineers, domain experts, and trade unions [acc50e4530db:p41].
Sources: acc50e4530db:p41

### Scenarios

Real-life examples of how a system can be used, which describe starting situations, normal event flows, potential errors, concurrent activities, and ending states [acc50e4530db:p42].
Sources: acc50e4530db:p42

#### acc50e4530db:p41 (content)

Covers requirements elicitation and analysis, detailing how technical staff work with stakeholders to discover application domains, services, and operational constraints.

Requirements elicitation and analysis
Sometimes called requirements elicitation or requirements discovery.
Involves technical staff working with customers to find out about the application domain, the services that the system should provide and the system's operational constraints.
May involve end-users, managers, engineers involved in maintenance, domain experts, trade unions, etc. These are called stakeholders.
Chapter 4 Requirements engineering 47

#### acc50e4530db:p42 (content)

Introduces scenarios as real-life examples of system usage, listing key components such as starting situations, normal event flows, exceptions, concurrent activities, and finishing states.

Scenarios
Scenarios are real-life examples of how a system can be used.
They should include
- A description of the starting situation;
- A description of the normal flow of events;
- A description of what can go wrong;
- Information about other concurrent activities;
- A description of the state when the scenario finishes.

## Section 43: Scenario for collecting medical history in MHC-PMS

### Initial Assumption in Scenarios

Defines the preconditions required before a scenario can begin, such as a receptionist creating a patient record and a nurse being logged into the system.
Sources: acc50e4530db:p43

### Normal Workflow

Specifies the expected sequence of interactions and data entry steps during routine operation, including patient identification and menu navigation.
Sources: acc50e4530db:p43

### Exception Handling (What can go wrong)

Identifies potential failure modes or exceptional situations during a scenario and prescribes alternative behaviors or fallback procedures for the system and user.
Sources: acc50e4530db:p44

### Concurrent Activities

Describes other processes or constraints that may occur simultaneously, such as staff being able to consult a record while it is being edited.
Sources: acc50e4530db:p44

### System State on Completion

Defines the post-conditions and database changes resulting from a completed scenario, including transaction logging and session tracking.
Sources: acc50e4530db:p44

#### acc50e4530db:p43 (content)

This page outlines the initial assumption and normal workflow for collecting a patient's medical history in the MHC-PMS system, detailing how a nurse identifies a patient and records consultations, conditions, medication, allergies, and home life.

Initial assumption: The patient has seen a medical receptionist who has created a record in the system and collected the patient's personal information (name, address, age, etc.). A nurse is logged on to the system and is collecting medical history.
Normal: The nurse searches for the patient by family name. If there is more than one patient with the same surname, the given name (first name in English) and date of birth are used to identify the patient.
The nurse chooses the menu option to add medical history.
The nurse then follows a series of prompts from the system to enter information about consultations elsewhere on mental health problems (free text input), existing medical conditions (nurse selects conditions from menu), medication currently taken (selected from menu), allergies (free text), and home life (form).

#### acc50e4530db:p44 (content)

This page continues the MHC-PMS medical history collection scenario by describing exception handling ('what can go wrong'), related activities, and the final system state upon completion.

What can go wrong: The patient's record does not exist or cannot be found. The nurse should create a new record and record personal information.
Patient conditions or medication are not entered in the menu. The nurse should choose the 'other' option and enter free text describing the condition/medication.
Patient cannot/will not provide information on medical history. The nurse should enter free text recording the patient's inability/unwillingness to provide information. The system should print the standard exclusion form stating that the lack of information may mean that treatment will be limited or delayed. This should be signed and handed to the patient.
Other activities: Record may be consulted but not edited by other staff while information is being entering.
System state on completion: User is logged on. The patient record including medical history is entered in the database, a record is added to the system log showing the start and end time of the session and the nurse involved.

## Section 45: Use Cases and Requirements Engineering

### Use-Cases in UML

Use-cases are scenario-based techniques in UML that identify the actors in an interaction and describe the interaction itself, aiming to cover all possible system interactions through high-level graphical models and detailed tabular descriptions.
Sources: acc50e4530db:p45

### Sequence Diagrams

Sequence diagrams can be used to add detail to use-cases by demonstrating the specific sequence of event processing within the system.
Sources: acc50e4530db:p45

### MHC-PMS Use Cases

The Mental Health Care Patient Management System (MHC-PMS) use case model defines specific interactions between system actors—such as medical receptionists, nurses, doctors, and managers—and system functions like registering patients, editing records, and generating reports.
Sources: acc50e4530db:p46

#### acc50e4530db:p45 (content)

This slide introduces use-cases as a UML scenario-based technique for identifying actors and interactions, describing all possible system interactions through high-level graphical models and tabular descriptions, with sequence diagrams providing further detail.

Use cases
- Use-cases are a scenario based technique in the UML which identify the actors in an interaction and which describe the interaction itself.
- A set of use cases should describe all possible interactions with the system.
  - High-level graphical model supplemented by more detailed tabular description (see Chapter 5).
- Sequence diagrams may be used to add detail to use-cases by showing the sequence of event processing in the system.
Chapter 4 Requirements engineering 56

#### acc50e4530db:p46 (content)

This slide illustrates a use case diagram for the MHC-PMS system, showing four actor types (Medical receptionist, Nurse, Manager, Doctor) interacting with various use cases such as Register patient, View personal info, View record, Edit record, Setup consultation, Export statistics, and Generate report.

Use cases for the MHC-PMS
Actors: Medical receptionist, Nurse, Manager, Doctor
Use cases: Register patient, View personal info, View record, Edit record, Setup consultation, Export statistics, Generate report
Chapter 4 Requirements engineering 57
